import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

let db: Database | null = null;
const DB_FILE = path.join(process.cwd(), 'edujourney.sqlite');

export async function getDb(): Promise<Database> {
  if (db) return db;

  const SQL = await initSqlJs();
  
  if (fs.existsSync(DB_FILE)) {
    try {
      const fileBuffer = fs.readFileSync(DB_FILE);
      db = new SQL.Database(fileBuffer);
    } catch (e) {
      console.warn("Failed to load existing DB file, creating new database in memory");
      db = new SQL.Database();
    }
  } else {
    db = new SQL.Database();
  }

  initSchema(db);
  seedInitialData(db);
  saveDb();
  return db;
}

export function saveDb() {
  if (!db) return;
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_FILE, buffer);
  } catch (e) {
    console.error("Failed to save database to disk:", e);
  }
}

function initSchema(database: Database) {
  const schemaDDL = `
    CREATE TABLE IF NOT EXISTS Regions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      country TEXT NOT NULL DEFAULT 'Namibia',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS Schools (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      region TEXT NOT NULL,
      town TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'Secondary',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS Subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      category TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS Interests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      category TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS Users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'student',
      status TEXT NOT NULL DEFAULT 'active',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS Student_Profile (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      full_name TEXT NOT NULL,
      gender TEXT NOT NULL,
      date_of_birth TEXT NOT NULL,
      region TEXT NOT NULL,
      town TEXT NOT NULL,
      school TEXT NOT NULL,
      grade TEXT NOT NULL,
      subjects TEXT NOT NULL,
      interests TEXT NOT NULL,
      profile_picture TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS User_Settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      theme TEXT NOT NULL DEFAULT 'system',
      notifications_email BOOLEAN NOT NULL DEFAULT 1,
      notifications_sms BOOLEAN NOT NULL DEFAULT 0,
      language TEXT NOT NULL DEFAULT 'en',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Authentication (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      verification_token TEXT,
      is_email_verified BOOLEAN NOT NULL DEFAULT 0,
      reset_token TEXT,
      reset_token_expires DATETIME,
      last_login_ip TEXT,
      last_login_at DATETIME,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      token TEXT UNIQUE NOT NULL,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Onboarding_Progress (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      current_step INTEGER NOT NULL DEFAULT 1,
      is_completed BOOLEAN NOT NULL DEFAULT 0,
      last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Student_Academic (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      favourite_subject TEXT,
      difficult_subject TEXT,
      academic_goals TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Learning_Preferences (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      learning_styles TEXT,
      study_frequency TEXT,
      session_length TEXT,
      reminder_time TEXT,
      custom_reminder_time TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Career_Dreams (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      career_dreams TEXT,
      custom_careers TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Edu_Buddy_Profile (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      ai_name TEXT NOT NULL DEFAULT 'Edu Buddy',
      ai_avatar TEXT NOT NULL DEFAULT 'robot-1',
      voice_preference TEXT NOT NULL DEFAULT 'default',
      conversation_style TEXT NOT NULL DEFAULT 'Friendly',
      accent_color TEXT NOT NULL DEFAULT 'emerald',
      greeting_style TEXT NOT NULL DEFAULT 'Ready to learn today?',
      custom_greeting TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Notification_Preferences (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      study_reminders BOOLEAN NOT NULL DEFAULT 1,
      assignment_reminders BOOLEAN NOT NULL DEFAULT 1,
      learning_streaks BOOLEAN NOT NULL DEFAULT 1,
      motivational_messages BOOLEAN NOT NULL DEFAULT 1,
      school_announcements BOOLEAN NOT NULL DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Privacy_Settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      profile_visibility TEXT NOT NULL DEFAULT 'Friends Only',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Dashboard_Preferences (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      layout_order TEXT,
      active_widgets TEXT,
      theme_preference TEXT DEFAULT 'default',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'welcome',
      is_read BOOLEAN NOT NULL DEFAULT 0,
      link TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Learning_Streak (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      current_streak INTEGER NOT NULL DEFAULT 7,
      longest_streak INTEGER NOT NULL DEFAULT 12,
      last_activity_date TEXT,
      xp_total INTEGER NOT NULL DEFAULT 2450,
      badges TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Recent_Activity (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      activity_type TEXT NOT NULL,
      title TEXT NOT NULL,
      subtitle TEXT NOT NULL,
      xp_earned INTEGER DEFAULT 0,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Dashboard_Widgets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      widget_id TEXT NOT NULL,
      title TEXT NOT NULL,
      is_enabled BOOLEAN NOT NULL DEFAULT 1,
      position INTEGER NOT NULL DEFAULT 1,
      settings TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Assignments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      subject TEXT NOT NULL,
      teacher TEXT NOT NULL,
      due_date TEXT NOT NULL,
      priority TEXT NOT NULL DEFAULT 'Medium',
      status TEXT NOT NULL DEFAULT 'Not Started',
      progress INTEGER NOT NULL DEFAULT 0,
      estimated_time INTEGER NOT NULL DEFAULT 60,
      difficulty TEXT NOT NULL DEFAULT 'Medium',
      instructions TEXT,
      teacher_notes TEXT,
      resources TEXT,
      attachments TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Assignment_Progress (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      assignment_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      progress_percentage INTEGER NOT NULL DEFAULT 0,
      current_status TEXT NOT NULL,
      time_spent_minutes INTEGER NOT NULL DEFAULT 0,
      last_worked_on DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (assignment_id) REFERENCES Assignments(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Assignment_Notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      assignment_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      content TEXT NOT NULL,
      note_type TEXT NOT NULL DEFAULT 'student',
      is_pinned BOOLEAN NOT NULL DEFAULT 0,
      is_bookmarked BOOLEAN NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (assignment_id) REFERENCES Assignments(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Assignment_Checklist (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      assignment_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      is_completed BOOLEAN NOT NULL DEFAULT 0,
      item_order INTEGER NOT NULL DEFAULT 1,
      checklist_type TEXT NOT NULL DEFAULT 'todo',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (assignment_id) REFERENCES Assignments(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Study_Plans (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      plan_type TEXT NOT NULL,
      target_date TEXT NOT NULL,
      subjects_included TEXT,
      daily_hours REAL NOT NULL DEFAULT 2,
      schedule_json TEXT,
      ai_generated BOOLEAN NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Study_Sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      assignment_id INTEGER,
      title TEXT NOT NULL,
      subject TEXT NOT NULL,
      duration_minutes INTEGER NOT NULL DEFAULT 25,
      time_spent_seconds INTEGER NOT NULL DEFAULT 0,
      mode TEXT NOT NULL DEFAULT 'pomodoro',
      status TEXT NOT NULL DEFAULT 'completed',
      started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      completed_at DATETIME,
      xp_earned INTEGER NOT NULL DEFAULT 50,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Calendar_Events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      event_type TEXT NOT NULL,
      subject TEXT NOT NULL,
      event_date TEXT NOT NULL,
      start_time TEXT NOT NULL,
      end_time TEXT NOT NULL,
      description TEXT,
      color TEXT NOT NULL DEFAULT 'emerald',
      assignment_id INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Student_Goals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      goal_type TEXT NOT NULL DEFAULT 'Daily Goal',
      target_value INTEGER NOT NULL DEFAULT 1,
      current_value INTEGER NOT NULL DEFAULT 0,
      is_completed BOOLEAN NOT NULL DEFAULT 0,
      target_date TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Learning_Streaks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      consecutive_days INTEGER NOT NULL DEFAULT 7,
      assignments_completed INTEGER NOT NULL DEFAULT 15,
      hours_studied REAL NOT NULL DEFAULT 42.5,
      goals_achieved INTEGER NOT NULL DEFAULT 8,
      xp_total INTEGER NOT NULL DEFAULT 2450,
      last_activity_date TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Reminder_Settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      upcoming_assignment BOOLEAN NOT NULL DEFAULT 1,
      tomorrow_deadline BOOLEAN NOT NULL DEFAULT 1,
      today_study_plan BOOLEAN NOT NULL DEFAULT 1,
      study_reminder BOOLEAN NOT NULL DEFAULT 1,
      goal_reminder BOOLEAN NOT NULL DEFAULT 1,
      exam_reminder BOOLEAN NOT NULL DEFAULT 1,
      reminder_time TEXT NOT NULL DEFAULT '18:00',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS AI_Conversations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      subject TEXT NOT NULL DEFAULT 'General',
      explanation_mode TEXT NOT NULL DEFAULT 'Normal',
      is_pinned BOOLEAN NOT NULL DEFAULT 0,
      is_bookmarked BOOLEAN NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Conversation_History (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      conversation_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      sender TEXT NOT NULL,
      content TEXT NOT NULL,
      explanation_mode TEXT DEFAULT 'Normal',
      is_bookmarked BOOLEAN NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (conversation_id) REFERENCES AI_Conversations(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Bookmarks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      conversation_id INTEGER,
      message_id INTEGER,
      title TEXT NOT NULL,
      snippet TEXT NOT NULL,
      category TEXT DEFAULT 'General',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Pinned_Chats (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      conversation_id INTEGER NOT NULL,
      pinned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE,
      FOREIGN KEY (conversation_id) REFERENCES AI_Conversations(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Flashcards (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      subject TEXT NOT NULL,
      topic TEXT NOT NULL,
      question TEXT NOT NULL,
      answer TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Needs Practice',
      is_bookmarked BOOLEAN NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Generated_Quizzes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      subject TEXT NOT NULL,
      difficulty TEXT NOT NULL DEFAULT 'Medium',
      question_type TEXT NOT NULL DEFAULT 'Multiple Choice',
      questions_json TEXT NOT NULL,
      score INTEGER DEFAULT -1,
      total_questions INTEGER DEFAULT 5,
      completed_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Student_AI_Preferences (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      avatar TEXT NOT NULL DEFAULT 'robot-1',
      greeting TEXT NOT NULL DEFAULT 'Ready to learn today?',
      conversation_style TEXT NOT NULL DEFAULT 'Friendly',
      humor_level TEXT NOT NULL DEFAULT 'Balanced',
      response_length TEXT NOT NULL DEFAULT 'Concise',
      theme_color TEXT NOT NULL DEFAULT 'emerald',
      animation_style TEXT NOT NULL DEFAULT 'Smooth',
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Memory_Profile (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER UNIQUE NOT NULL,
      preferred_learning_style TEXT NOT NULL DEFAULT 'Visual & Step-by-Step',
      favorite_subjects TEXT NOT NULL DEFAULT '["Mathematics","Computer Studies"]',
      weak_topics TEXT NOT NULL DEFAULT '["Quadratic Word Problems","Newton Second Law Graphing"]',
      career_goals TEXT NOT NULL DEFAULT '["Software Engineer","Data Scientist"]',
      preferred_explanations TEXT NOT NULL DEFAULT 'Step-by-Step',
      study_habits TEXT NOT NULL DEFAULT '["Evening study sessions","45-minute Pomodoro intervals"]',
      past_topics_summary TEXT NOT NULL DEFAULT 'Recently discussed quadratic formula derivations, trolley physics lab reports, and Python dictionaries.',
      last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Learning_Insights (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      insight_type TEXT NOT NULL DEFAULT 'Strength',
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      subject TEXT NOT NULL,
      action_recommended TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Study_Recommendations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      subject TEXT NOT NULL,
      recommendation_type TEXT NOT NULL DEFAULT 'Study Today',
      reason TEXT NOT NULL,
      priority TEXT NOT NULL DEFAULT 'High',
      action_text TEXT NOT NULL DEFAULT 'Start Learning',
      action_link TEXT,
      is_completed BOOLEAN NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );
  `;

  database.exec(schemaDDL);
}

function seedInitialData(database: Database) {
  // Check if Regions are seeded
  const res = database.exec("SELECT count(*) as count FROM Regions");
  const count = Number(res[0]?.values[0]?.[0] || 0);
  if (count > 0) return; // Already seeded

  const regions = [
    'Khomas', 'Erongo', 'Oshana', 'Ohangwena', 'Omusati', 'Oshikoto', 
    'Otjozondjupa', 'Hardap', '||Kharas', 'Zambezi', 'Kavango East', 
    'Kavango West', 'Kunene', 'Omaheke'
  ];

  regions.forEach(r => {
    database.run("INSERT OR IGNORE INTO Regions (name, country) VALUES (?, 'Namibia')", [r]);
  });

  const schools = [
    ['Windhoek High School', 'Khomas', 'Windhoek', 'Secondary'],
    ['St. Paul\'s College', 'Khomas', 'Windhoek', 'Private Secondary'],
    ['Delta Secondary School Windhoek', 'Khomas', 'Windhoek', 'Secondary'],
    ['Jan Möhr Secondary School', 'Khomas', 'Windhoek', 'Secondary'],
    ['Swakopmund Secondary School', 'Erongo', 'Swakopmund', 'Secondary'],
    ['Kuisebmond Secondary School', 'Erongo', 'Walvis Bay', 'Secondary'],
    ['Oshakati Secondary School', 'Oshana', 'Oshakati', 'Secondary'],
    ['Mweshipandeka Senior Secondary', 'Oshana', 'Ondangwa', 'Secondary'],
    ['Etosha Secondary School', 'Oshikoto', 'Tsumeb', 'Secondary'],
    ['Rundu Secondary School', 'Kavango East', 'Rundu', 'Secondary'],
    ['Caprivi Senior Secondary School', 'Zambezi', 'Katima Mulilo', 'Secondary'],
    ['PK de Villiers Secondary School', '||Kharas', 'Keetmanshoop', 'Secondary'],
    ['Wennie du Plessis Secondary School', 'Omaheke', 'Gobabis', 'Secondary'],
    ['Otjiwarongo Secondary School', 'Otjozondjupa', 'Otjiwarongo', 'Secondary'],
    ['Rehoboth High School', 'Hardap', 'Rehoboth', 'Secondary'],
    ['Outjo Secondary School', 'Kunene', 'Outjo', 'Secondary'],
    ['Negumbo Senior Secondary School', 'Omusati', 'Oshikuku', 'Secondary'],
    ['Gabriel Taapopi Senior Secondary', 'Oshana', 'Ongwediva', 'Secondary']
  ];

  schools.forEach(([name, region, town, type]) => {
    database.run("INSERT OR IGNORE INTO Schools (name, region, town, type) VALUES (?, ?, ?, ?)", [name, region, town, type]);
  });

  const subjects = [
    ['Mathematics', 'STEM'],
    ['Physical Science', 'STEM'],
    ['Biology', 'STEM'],
    ['Computer Studies', 'STEM'],
    ['Agricultural Science', 'STEM'],
    ['English First Language', 'Languages'],
    ['English Second Language', 'Languages'],
    ['Oshikwanyama', 'Languages'],
    ['Oshindonga', 'Languages'],
    ['Otjiherero', 'Languages'],
    ['Khoekhoegowab', 'Languages'],
    ['Afrikaans', 'Languages'],
    ['German', 'Languages'],
    ['Geography', 'Humanities'],
    ['History', 'Humanities'],
    ['Development Studies', 'Humanities'],
    ['Accounting', 'Commerce'],
    ['Economics', 'Commerce'],
    ['Business Studies', 'Commerce'],
    ['Entrepreneurship', 'Commerce'],
    ['Art & Design', 'Arts'],
    ['Physical Education', 'Health']
  ];

  subjects.forEach(([name, category]) => {
    database.run("INSERT OR IGNORE INTO Subjects (name, category) VALUES (?, ?)", [name, category]);
  });

  const interests = [
    ['Artificial Intelligence & Robotics', 'Technology'],
    ['Software Development & Coding', 'Technology'],
    ['Medicine & Healthcare Innovation', 'Health'],
    ['Renewable Energy & Sustainability', 'Engineering'],
    ['Civil & Mechanical Engineering', 'Engineering'],
    ['Financial Literacy & Fintech', 'Finance'],
    ['African History & Cultural Heritage', 'Humanities'],
    ['Law, Human Rights & Governance', 'Law'],
    ['AgriTech & Modern Farming', 'Agriculture'],
    ['Digital Art & Creative Media', 'Arts'],
    ['Public Speaking & Debate', 'Leadership'],
    ['Space Exploration & Astronomy', 'Science']
  ];

  interests.forEach(([name, category]) => {
    database.run("INSERT OR IGNORE INTO Interests (name, category) VALUES (?, ?)", [name, category]);
  });

  // Seed a demo student user for instant evaluation!
  const demoEmail = 'student@edujourney.na';
  const demoPassHash = '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918:a1b2c3d4e5f6'; // hash of 'Password123!'
  database.run("INSERT OR IGNORE INTO Users (id, email, password_hash, role, status) VALUES (1, ?, ?, 'student', 'active')", [demoEmail, demoPassHash]);
  database.run(`INSERT OR IGNORE INTO Student_Profile 
    (id, user_id, full_name, gender, date_of_birth, region, town, school, grade, subjects, interests, profile_picture) 
    VALUES (1, 1, 'Tangi Amukwaya', 'Female', '2008-04-15', 'Khomas', 'Windhoek', 'Delta Secondary School Windhoek', 'Grade 11', '["Mathematics","Physical Science","Computer Studies","English First Language"]', '["Artificial Intelligence & Robotics","Software Development & Coding","Renewable Energy & Sustainability"]', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400')`);
  database.run("INSERT OR IGNORE INTO User_Settings (id, user_id, theme, notifications_email) VALUES (1, 1, 'dark', 1)");
  database.run("INSERT OR IGNORE INTO Authentication (id, user_id, verification_token, is_email_verified) VALUES (1, 1, 'verified-demo-token', 1)");

  // Phase 2 Seeding: Seed demo user onboarding progress (Step 1, ready for evaluation!)
  database.run("INSERT OR IGNORE INTO Onboarding_Progress (id, user_id, current_step, is_completed) VALUES (1, 1, 1, 0)");
  database.run("INSERT OR IGNORE INTO Student_Academic (id, user_id, favourite_subject, difficult_subject, academic_goals) VALUES (1, 1, 'Mathematics', 'Physical Science', '[\"Improve Mathematics\",\"Pass Grade 11\",\"Prepare for NSSCO exams\"]')");
  database.run("INSERT OR IGNORE INTO Learning_Preferences (id, user_id, learning_styles, study_frequency, session_length, reminder_time) VALUES (1, 1, '[\"Videos\",\"Practice Questions\",\"Interactive Activities\"]', 'Daily', '45 Minutes', 'Evening')");
  database.run("INSERT OR IGNORE INTO Career_Dreams (id, user_id, career_dreams) VALUES (1, 1, '[\"Software Developer\",\"AI Engineer\",\"Entrepreneur\"]')");
  database.run("INSERT OR IGNORE INTO Edu_Buddy_Profile (id, user_id, ai_name, ai_avatar, conversation_style, accent_color, greeting_style) VALUES (1, 1, 'Edu Buddy', 'robot-emerald', 'Motivational', 'emerald', 'Let''s conquer today''s lessons!')");
  database.run("INSERT OR IGNORE INTO Notification_Preferences (id, user_id, study_reminders, assignment_reminders, learning_streaks, motivational_messages, school_announcements) VALUES (1, 1, 1, 1, 1, 1, 1)");
  database.run("INSERT OR IGNORE INTO Privacy_Settings (id, user_id, profile_visibility) VALUES (1, 1, 'Friends Only')");

  // Phase 3 Seeding: Seed student dashboard preferences, notifications, streak, widgets & activity
  database.run("INSERT OR IGNORE INTO Dashboard_Preferences (id, user_id, layout_order, active_widgets, theme_preference) VALUES (1, 1, '[\"welcome\",\"overview\",\"progress\",\"actions\",\"activity\",\"upcoming\",\"planner\",\"achievements\"]', '[\"overview\",\"progress\",\"actions\",\"activity\",\"upcoming\",\"planner\"]', 'default')");
  
  database.run("INSERT OR IGNORE INTO Learning_Streak (id, user_id, current_streak, longest_streak, last_activity_date, xp_total, badges) VALUES (1, 1, 7, 12, '2026-07-26', 2450, '[\"Early Bird\", \"Math Whiz\", \"Consistent Learner\", \"AI Explorer\"]')");
  
  // Seed sample notifications
  database.run("INSERT OR IGNORE INTO Notifications (id, user_id, title, message, type, is_read) VALUES (1, 1, 'Welcome to Edu Journey Pro! 🎉', 'Your personal student dashboard and learning workspace is live and ready for action.', 'welcome', 0)");
  database.run("INSERT OR IGNORE INTO Notifications (id, user_id, title, message, type, is_read) VALUES (2, 1, 'Student Profile Initialized ⭐', 'Your Namibian school registry profile at Delta Secondary School Windhoek is verified.', 'profile', 0)");
  database.run("INSERT OR IGNORE INTO Notifications (id, user_id, title, message, type, is_read) VALUES (3, 1, 'Edu Buddy AI Ready 🤖', 'Emerald Spark is configured with motivational conversation style. Click Ask Edu Buddy anytime!', 'edubuddy', 0)");
  
  // Seed recent activity
  database.run("INSERT OR IGNORE INTO Recent_Activity (id, user_id, activity_type, title, subtitle, xp_earned) VALUES (1, 1, 'quiz', 'Completed Practice Quiz', 'Algebra Level 1 - 95% Score achieved', 150)");
  database.run("INSERT OR IGNORE INTO Recent_Activity (id, user_id, activity_type, title, subtitle, xp_earned) VALUES (2, 1, 'session', 'Started Study Session', '45m Physical Science revision session', 100)");
  database.run("INSERT OR IGNORE INTO Recent_Activity (id, user_id, activity_type, title, subtitle, xp_earned) VALUES (3, 1, 'profile', 'Updated Profile', 'Selected Mathematics & Science academic goals', 50)");
  database.run("INSERT OR IGNORE INTO Recent_Activity (id, user_id, activity_type, title, subtitle, xp_earned) VALUES (4, 1, 'school', 'Joined School', 'Delta Secondary School Windhoek registry linked', 50)");
  database.run("INSERT OR IGNORE INTO Recent_Activity (id, user_id, activity_type, title, subtitle, xp_earned) VALUES (5, 1, 'edubuddy', 'Created Edu Buddy', 'Configured Emerald Spark AI study mentor', 100)");
  
  // Seed dashboard widgets
  const defaultWidgets = [
    { id: 'overview', title: "Today's Overview", pos: 1 },
    { id: 'progress', title: 'Learning Progress', pos: 2 },
    { id: 'actions', title: 'Quick Actions', pos: 3 },
    { id: 'activity', title: 'Recent Activity', pos: 4 },
    { id: 'upcoming', title: 'Upcoming Events', pos: 5 },
    { id: 'planner', title: 'Study Planner Preview', pos: 6 }
  ];
  defaultWidgets.forEach(w => {
    database.run("INSERT OR IGNORE INTO Dashboard_Widgets (user_id, widget_id, title, is_enabled, position) VALUES (1, ?, ?, 1, ?)", [w.id, w.title, w.pos]);
  });

  // Phase 4 Seeding: Assignments, Calendar Events, Study Plans, Goals, Streaks, & Reminders
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
  const nextFriday = new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0];
  const nextMonday = new Date(Date.now() + 86400000 * 6).toISOString().split('T')[0];
  const twoWeeks = new Date(Date.now() + 86400000 * 14).toISOString().split('T')[0];
  const threeDaysAgo = new Date(Date.now() - 86400000 * 3).toISOString().split('T')[0];

  database.run(`INSERT OR IGNORE INTO Assignments (id, user_id, title, subject, teacher, due_date, priority, status, progress, estimated_time, difficulty, instructions, teacher_notes, resources, attachments) VALUES 
    (1, 1, 'Algebra: Quadratic & Polynomial Equations Practice', 'Mathematics', 'Mr. Kandjii', ?, 'High', 'In Progress', 40, 60, 'Medium', 'Complete exercises 1 to 15 on page 42 of NSSCO Mathematics textbook. Show all calculations clearly and double-check factorizations.', 'Focus on using the quadratic formula accurately. Check your signs when factoring.', '["Khan Academy: Quadratic Formula|https://khanacademy.org","NSSCO Past Paper 2024 P1|#"]', '["NSSCO_Math_Ex42.pdf|450 KB|PDF","Formula_Sheet_NSSCO.pdf|120 KB|PDF"]')`, [tomorrow]);

  database.run(`INSERT OR IGNORE INTO Assignments (id, user_id, title, subject, teacher, due_date, priority, status, progress, estimated_time, difficulty, instructions, teacher_notes, resources, attachments) VALUES 
    (2, 1, 'Physical Science Lab Report: Newton''s Second Law', 'Physical Science', 'Ms. Van Zyl', ?, 'High', 'Not Started', 0, 90, 'Hard', 'Write up the complete laboratory report from Tuesday''s trolley experiment. Include data tables, graphs of acceleration vs force, and error analysis.', 'Ensure units are SI (m/s^2, N, kg). Pay attention to error margins in graph plotting.', '["Lab Report Template PDF|#","Physics Simulation: Forces|#"]', '["Lab_Data_Table_Trolley.xlsx|85 KB|Excel"]')`, [nextFriday]);

  database.run(`INSERT OR IGNORE INTO Assignments (id, user_id, title, subject, teacher, due_date, priority, status, progress, estimated_time, difficulty, instructions, teacher_notes, resources, attachments) VALUES 
    (3, 1, 'English First Language Essay: Modern African Literature', 'English First Language', 'Mrs. Shikongo', ?, 'Medium', 'Draft', 15, 120, 'Medium', 'Write a 500-word comparative essay on narrative voice in post-independence Namibian storytelling. Use at least two literary citations.', 'Check your intro hook and thesis statement. Proofread for punctuation and sentence variety.', '["Essay Writing Guide|#","Namibian Literary Archives|#"]', '[]')`, [nextMonday]);

  database.run(`INSERT OR IGNORE INTO Assignments (id, user_id, title, subject, teacher, due_date, priority, status, progress, estimated_time, difficulty, instructions, teacher_notes, resources, attachments) VALUES 
    (4, 1, 'Computer Studies: Python Data Structures Project', 'Computer Studies', 'Mr. Amutenya', ?, 'Low', 'Completed', 100, 180, 'Medium', 'Create a simple Python student directory console program using dictionaries and lists. Upload your .py source file with comments.', 'Great job formatting your functions! Code runs cleanly without syntax errors.', '["Python Official Doc: Lists & Dicts|#"]', '["student_directory.py|12 KB|Code"]')`, [twoWeeks]);

  database.run(`INSERT OR IGNORE INTO Assignments (id, user_id, title, subject, teacher, due_date, priority, status, progress, estimated_time, difficulty, instructions, teacher_notes, resources, attachments) VALUES 
    (5, 1, 'Geography: Mapwork & Topographic Contour Practice', 'Geography', 'Mr. Garöeb', ?, 'Medium', 'Reviewed', 100, 45, 'Easy', 'Calculate gradient and identify settlement patterns on the 1:50,000 Windhoek topographic map sheet.', 'Excellent accuracy on grid references. 10/10 score achieved!', '["Mapwork Symbols Reference|#"]', '["Windhoek_Topo_Sheet.pdf|3.2 MB|PDF"]')`, [threeDaysAgo]);

  // Seed Checklists for Assignment 1 & 2
  database.run("INSERT OR IGNORE INTO Assignment_Checklist (id, assignment_id, user_id, title, is_completed, item_order, checklist_type) VALUES (1, 1, 1, 'Review standard quadratic formula derivation', 1, 1, 'reading')");
  database.run("INSERT OR IGNORE INTO Assignment_Checklist (id, assignment_id, user_id, title, is_completed, item_order, checklist_type) VALUES (2, 1, 1, 'Solve questions 1 to 8 (Factoring method)', 1, 2, 'practice')");
  database.run("INSERT OR IGNORE INTO Assignment_Checklist (id, assignment_id, user_id, title, is_completed, item_order, checklist_type) VALUES (3, 1, 1, 'Solve questions 9 to 15 (Quadratic formula)', 0, 3, 'practice')");
  database.run("INSERT OR IGNORE INTO Assignment_Checklist (id, assignment_id, user_id, title, is_completed, item_order, checklist_type) VALUES (4, 1, 1, 'Verify solutions by substitution', 0, 4, 'todo')");

  database.run("INSERT OR IGNORE INTO Assignment_Checklist (id, assignment_id, user_id, title, is_completed, item_order, checklist_type) VALUES (5, 2, 1, 'Format raw experimental data into Excel table', 0, 1, 'todo')");
  database.run("INSERT OR IGNORE INTO Assignment_Checklist (id, assignment_id, user_id, title, is_completed, item_order, checklist_type) VALUES (6, 2, 1, 'Plot acceleration vs force graph', 0, 2, 'practice')");
  database.run("INSERT OR IGNORE INTO Assignment_Checklist (id, assignment_id, user_id, title, is_completed, item_order, checklist_type) VALUES (7, 2, 1, 'Write conclusion & error margin analysis', 0, 3, 'research')");

  // Seed Assignment Notes
  database.run("INSERT OR IGNORE INTO Assignment_Notes (id, assignment_id, user_id, content, note_type, is_pinned, is_bookmarked) VALUES (1, 1, 1, 'Remember: when discriminant b^2 - 4ac is negative, there are no real roots! Ask Mr. Kandjii if we need to simplify radicals in exact form.', 'student', 1, 1)");
  database.run("INSERT OR IGNORE INTO Assignment_Notes (id, assignment_id, user_id, content, note_type, is_pinned, is_bookmarked) VALUES (2, 2, 1, 'Voice note reminder: check friction coefficient calibration on the trolley runway before finalizing graph slope.', 'voice', 0, 1)");

  // Seed Calendar Events
  const todayStr = new Date().toISOString().split('T')[0];
  database.run("INSERT OR IGNORE INTO Calendar_Events (id, user_id, title, event_type, subject, event_date, start_time, end_time, description, color, assignment_id) VALUES (1, 1, 'Algebra Practice Due', 'Assignment', 'Mathematics', ?, '14:00', '14:30', 'Hand in Exercise 42 homework to Mr. Kandjii in Room 14.', 'emerald', 1)", [tomorrow]);
  database.run("INSERT OR IGNORE INTO Calendar_Events (id, user_id, title, event_type, subject, event_date, start_time, end_time, description, color, assignment_id) VALUES (2, 1, 'Physics Lab Group Revision', 'Study Session', 'Physical Science', ?, '15:30', '16:30', 'Meet with study group in library to review trolley lab data.', 'blue', 2)", [todayStr]);
  database.run("INSERT OR IGNORE INTO Calendar_Events (id, user_id, title, event_type, subject, event_date, start_time, end_time, description, color) VALUES (3, 1, 'NSSCO Mock Exam: Mathematics P1', 'Exam', 'Mathematics', ?, '08:00', '10:30', 'Main school hall. Bring calculator, ruler, and student ID.', 'rose')", [nextFriday]);
  database.run("INSERT OR IGNORE INTO Calendar_Events (id, user_id, title, event_type, subject, event_date, start_time, end_time, description, color) VALUES (4, 1, 'Computer Club Hackathon Prep', 'School Event', 'Computer Studies', ?, '14:00', '16:00', 'Computer lab 2. Preparing Python projects for regional showcase.', 'cyan')", [nextMonday]);

  // Seed Study Plans
  const dailyPlanSchedule = JSON.stringify([
    {
      day: 'Today',
      tasks: [
        { subject: 'Mathematics', topic: 'Quadratic Equations Ex 42 Q9-15', duration: '45m', completed: true },
        { subject: 'Physical Science', topic: 'Newton Law Data Tabulation', duration: '30m', completed: false },
        { subject: 'English First Language', topic: 'Brainstorm essay thesis on Namibian literature', duration: '25m', completed: false }
      ]
    }
  ]);
  database.run("INSERT OR IGNORE INTO Study_Plans (id, user_id, title, plan_type, target_date, subjects_included, daily_hours, schedule_json, ai_generated) VALUES (1, 1, 'Daily NSSCO Focus Schedule', 'Daily Study Plan', ?, '[\"Mathematics\",\"Physical Science\",\"English First Language\"]', 2.0, ?, 1)", [todayStr, dailyPlanSchedule]);

  const weeklyPlanSchedule = JSON.stringify([
    { day: 'Monday', tasks: [{ subject: 'Mathematics', topic: 'Algebraic Graphs', duration: '60m', completed: true }, { subject: 'Computer Studies', topic: 'Python Dictionaries', duration: '45m', completed: true }] },
    { day: 'Tuesday', tasks: [{ subject: 'Physical Science', topic: 'Trolley Experiment Lab Write-up', duration: '60m', completed: false }, { subject: 'English First Language', topic: 'Essay Outline & Quotes', duration: '45m', completed: false }] },
    { day: 'Wednesday', tasks: [{ subject: 'Mathematics', topic: 'Past Paper 2024 P1 Section A', duration: '60m', completed: false }, { subject: 'Geography', topic: 'Contour Calculations', duration: '30m', completed: false }] },
    { day: 'Thursday', tasks: [{ subject: 'Physical Science', topic: 'Force & Motion Revision Quiz', duration: '45m', completed: false }, { subject: 'Computer Studies', topic: 'Code Refactoring', duration: '45m', completed: false }] },
    { day: 'Friday', tasks: [{ subject: 'Mathematics', topic: 'NSSCO Mock Exam Prep', duration: '90m', completed: false }] }
  ]);
  database.run("INSERT OR IGNORE INTO Study_Plans (id, user_id, title, plan_type, target_date, subjects_included, daily_hours, schedule_json, ai_generated) VALUES (2, 1, 'Weekly High-Performance Timetable', 'Weekly Study Plan', ?, '[\"Mathematics\",\"Physical Science\",\"Computer Studies\",\"English First Language\",\"Geography\"]', 2.5, ?, 1)", [nextFriday, weeklyPlanSchedule]);

  // Seed Student Goals
  database.run("INSERT OR IGNORE INTO Student_Goals (id, user_id, title, goal_type, target_value, current_value, is_completed, target_date) VALUES (1, 1, 'Complete Math & Physics daily assignments', 'Daily Goal', 2, 1, 0, ?)", [todayStr]);
  database.run("INSERT OR IGNORE INTO Student_Goals (id, user_id, title, goal_type, target_value, current_value, is_completed, target_date) VALUES (2, 1, 'Log 12 hours of focused study time', 'Weekly Goal', 12, 8, 0, ?)", [nextFriday]);
  database.run("INSERT OR IGNORE INTO Student_Goals (id, user_id, title, goal_type, target_value, current_value, is_completed, target_date) VALUES (3, 1, 'Achieve 85%+ grade average across Grade 11 subjects', 'Monthly Goal', 85, 84, 0, ?)", [twoWeeks]);

  // Seed Learning Streaks (Phase 4 table)
  database.run("INSERT OR IGNORE INTO Learning_Streaks (id, user_id, consecutive_days, assignments_completed, hours_studied, goals_achieved, xp_total, last_activity_date) VALUES (1, 1, 7, 15, 42.5, 8, 2450, ?)", [todayStr]);

  // Seed Reminder Settings
  database.run("INSERT OR IGNORE INTO Reminder_Settings (id, user_id, upcoming_assignment, tomorrow_deadline, today_study_plan, study_reminder, goal_reminder, exam_reminder, reminder_time) VALUES (1, 1, 1, 1, 1, 1, 1, 1, '18:00')");

  // Phase 5 Seeding: Edu Buddy AI Experience
  database.run("INSERT OR IGNORE INTO Student_AI_Preferences (id, user_id, avatar, greeting, conversation_style, humor_level, response_length, theme_color, animation_style) VALUES (1, 1, 'robot-1', 'Ready to master quadratic equations today?', 'Friendly', 'Balanced', 'Concise', 'emerald', 'Smooth')");

  database.run("INSERT OR IGNORE INTO Memory_Profile (id, user_id, preferred_learning_style, favorite_subjects, weak_topics, career_goals, preferred_explanations, study_habits, past_topics_summary) VALUES (1, 1, 'Visual & Step-by-Step', '[\"Mathematics\",\"Computer Studies\"]', '[\"Quadratic Word Problems\",\"Newton Second Law Graphing\"]', '[\"Software Engineer\",\"Data Scientist\"]', 'Step-by-Step', '[\"Evening study sessions\",\"45-minute Pomodoro intervals\"]', 'Recently discussed quadratic formula derivations, trolley physics lab reports, and Python dictionaries.')");

  // Seed AI Conversations
  database.run("INSERT OR IGNORE INTO AI_Conversations (id, user_id, title, subject, explanation_mode, is_pinned, is_bookmarked) VALUES (1, 1, 'Mastering the Quadratic Formula', 'Mathematics', 'Step-by-Step', 1, 1)");
  database.run("INSERT OR IGNORE INTO AI_Conversations (id, user_id, title, subject, explanation_mode, is_pinned, is_bookmarked) VALUES (2, 1, 'Newton''s Second Law & Trolley Lab', 'Physical Science', 'Visual Learning', 1, 0)");
  database.run("INSERT OR IGNORE INTO AI_Conversations (id, user_id, title, subject, explanation_mode, is_pinned, is_bookmarked) VALUES (3, 1, 'Python Dictionaries & Lists Guide', 'Computer Studies', 'Normal', 0, 1)");

  // Seed Conversation History
  database.run(`INSERT OR IGNORE INTO Conversation_History (id, conversation_id, user_id, sender, content, explanation_mode, is_bookmarked) VALUES (1, 1, 1, 'user', 'Can you explain when to use the quadratic formula vs completing the square?', 'Step-by-Step', 0)`);
  database.run(`INSERT OR IGNORE INTO Conversation_History (id, conversation_id, user_id, sender, content, explanation_mode, is_bookmarked) VALUES (2, 1, 1, 'ai', '### When to use which method:\n\n**1. Factoring (First Choice)**: Use when roots are simple integers or rational numbers (e.g., $x^2 - 5x + 6 = 0$).\n**2. Completing the Square**: Great when finding the **vertex of a parabola** or when $a=1$ and $b$ is an even integer.\n**3. Quadratic Formula**: Your **universal tool**! Use it whenever factoring is difficult or impossible.\n\n$$x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$$\n\n**Pro-Tip**: Always check the **discriminant** ($\\Delta = b^2 - 4ac$) first. If $\\Delta < 0$, there are no real solutions!', 'Step-by-Step', 1)`);
  database.run(`INSERT OR IGNORE INTO Conversation_History (id, conversation_id, user_id, sender, content, explanation_mode, is_bookmarked) VALUES (3, 1, 1, 'user', 'What if b^2 - 4ac equals zero?', 'Step-by-Step', 0)`);
  database.run(`INSERT OR IGNORE INTO Conversation_History (id, conversation_id, user_id, sender, content, explanation_mode, is_bookmarked) VALUES (4, 1, 1, 'ai', 'When the discriminant $\\Delta = b^2 - 4ac = 0$, you get exactly **one repeated real root** (also called a double root)! Geometrically, this means the parabola touches the x-axis at exactly one point—its vertex.', 'Step-by-Step', 0)`);

  database.run(`INSERT OR IGNORE INTO Conversation_History (id, conversation_id, user_id, sender, content, explanation_mode, is_bookmarked) VALUES (5, 2, 1, 'user', 'How do I plot the acceleration vs force graph for my lab report?', 'Visual Learning', 0)`);
  database.run(`INSERT OR IGNORE INTO Conversation_History (id, conversation_id, user_id, sender, content, explanation_mode, is_bookmarked) VALUES (6, 2, 1, 'ai', 'To plot your **Acceleration ($a$) vs. Force ($F$) graph**:\n1. Place **Force ($N$) on the x-axis** (horizontal) and **Acceleration ($m/s^2$) on the y-axis** (vertical).\n2. According to Newton''s Second Law ($F = ma$), the relationship is directly proportional.\n3. Your data points should form a **straight line passing through the origin $(0,0)$**.\n4. The slope (gradient) of this line represents the reciprocal of mass ($1/m$).', 'Visual Learning', 1)`);

  // Seed Bookmarks
  database.run("INSERT OR IGNORE INTO Bookmarks (id, user_id, conversation_id, message_id, title, snippet, category) VALUES (1, 1, 1, 2, 'The Quadratic Discriminant Rule', 'When b^2 - 4ac > 0, there are 2 distinct real roots. When = 0, 1 real root. When < 0, no real roots.', 'Mathematics')");
  database.run("INSERT OR IGNORE INTO Bookmarks (id, user_id, conversation_id, message_id, title, snippet, category) VALUES (2, 1, 2, 6, 'Friction Compensation in Lab Experiments', 'In trolley experiments, slightly tilt the runway to compensate for friction so the trolley moves at constant velocity without applied force.', 'Physical Science')");

  // Seed Pinned Chats
  database.run("INSERT OR IGNORE INTO Pinned_Chats (id, user_id, conversation_id) VALUES (1, 1, 1)");
  database.run("INSERT OR IGNORE INTO Pinned_Chats (id, user_id, conversation_id) VALUES (2, 1, 2)");

  // Seed Flashcards
  database.run("INSERT OR IGNORE INTO Flashcards (id, user_id, subject, topic, question, answer, status, is_bookmarked) VALUES (1, 1, 'Mathematics', 'Algebra', 'What is the standard form of a quadratic equation?', 'ax² + bx + c = 0, where a ≠ 0', 'Mastered', 1)");
  database.run("INSERT OR IGNORE INTO Flashcards (id, user_id, subject, topic, question, answer, status, is_bookmarked) VALUES (2, 1, 'Mathematics', 'Algebra', 'What does the discriminant Δ = b² - 4ac tell us?', 'If Δ > 0: 2 real roots. If Δ = 0: 1 real root. If Δ < 0: no real roots.', 'Needs Practice', 1)");
  database.run("INSERT OR IGNORE INTO Flashcards (id, user_id, subject, topic, question, answer, status, is_bookmarked) VALUES (3, 1, 'Mathematics', 'Functions', 'What are the coordinates of the vertex of a parabola y = ax² + bx + c?', 'x = -b/(2a), y = f(-b/(2a))', 'Review later', 0)");
  database.run("INSERT OR IGNORE INTO Flashcards (id, user_id, subject, topic, question, answer, status, is_bookmarked) VALUES (4, 1, 'Physical Science', 'Dynamics', 'State Newton''s Second Law of Motion.', 'The net force acting on an object is directly proportional to the rate of change of momentum (F = ma).', 'Mastered', 1)");
  database.run("INSERT OR IGNORE INTO Flashcards (id, user_id, subject, topic, question, answer, status, is_bookmarked) VALUES (5, 1, 'Physical Science', 'Dynamics', 'What is the SI unit of Force and its derivation?', 'The Newton (N). 1 N = 1 kg·m/s²', 'Needs Practice', 0)");
  database.run("INSERT OR IGNORE INTO Flashcards (id, user_id, subject, topic, question, answer, status, is_bookmarked) VALUES (6, 1, 'Computer Studies', 'Data Structures', 'What is the key difference between Python Lists and Tuples?', 'Lists are mutable (can be changed after creation using [], while Tuples are immutable (cannot be changed after creation using ()).', 'Mastered', 1)");
  database.run("INSERT OR IGNORE INTO Flashcards (id, user_id, subject, topic, question, answer, status, is_bookmarked) VALUES (7, 1, 'Computer Studies', 'Data Structures', 'How do you access a value in a Python dictionary named student with key \"grade\"?', 'student[\"grade\"] or student.get(\"grade\")', 'Needs Practice', 0)");

  // Seed Generated Quizzes
  const sampleQuiz1 = JSON.stringify([
    { id: 1, question: "Which of the following is the correct quadratic formula?", options: ["x = (-b ± √(b² - 4ac)) / (2a)", "x = (-b ± √(b² + 4ac)) / (2a)", "x = (b ± √(b² - 4ac)) / (2a)", "x = (-b ± √(b² - 4ac)) / a"], answer: 0, explanation: "The standard quadratic formula divides by 2a and uses b² - 4ac inside the square root." },
    { id: 2, question: "If a quadratic equation has discriminant Δ = 16, how many real roots does it have?", options: ["No real roots", "1 repeated real root", "2 distinct real roots", "Infinite roots"], answer: 2, explanation: "Since 16 > 0, there are two distinct real roots." },
    { id: 3, question: "What is the y-intercept of the function y = 3x² - 5x + 7?", options: ["3", "-5", "7", "0"], answer: 2, explanation: "The y-intercept occurs when x = 0, which gives y = 7." },
    { id: 4, question: "Which method is best suited for finding the vertex form of a parabola?", options: ["Factoring by grouping", "Completing the square", "Synthetic division", "Cross multiplication"], answer: 1, explanation: "Completing the square directly converts ax² + bx + c into vertex form a(x - h)² + k." },
    { id: 5, question: "What is the axis of symmetry for y = x² - 6x + 8?", options: ["x = 3", "x = -3", "x = 6", "x = 4"], answer: 0, explanation: "Axis of symmetry is x = -b/(2a) = -(-6)/2 = 3." }
  ]);
  database.run("INSERT OR IGNORE INTO Generated_Quizzes (id, user_id, title, subject, difficulty, question_type, questions_json, score, total_questions, completed_at) VALUES (1, 1, 'Algebra Essentials Practice', 'Mathematics', 'Medium', 'Multiple Choice', ?, 80, 5, ?)", [sampleQuiz1, threeDaysAgo]);

  const sampleQuiz2 = JSON.stringify([
    { id: 1, question: "If the net force on a 5 kg trolley is 20 N, what is its acceleration?", options: ["4 m/s²", "100 m/s²", "0.25 m/s²", "15 m/s²"], answer: 0, explanation: "Using F = ma: a = F/m = 20/5 = 4 m/s²." },
    { id: 2, question: "What happens to acceleration if the force is doubled while mass remains constant?", options: ["It doubles", "It halves", "It stays the same", "It quadruples"], answer: 0, explanation: "Acceleration is directly proportional to net force (a ∝ F)." },
    { id: 3, question: "Which law explains why a passenger lurches forward when a bus brakes suddenly?", options: ["Newton's First Law (Inertia)", "Newton's Second Law", "Newton's Third Law", "Law of Gravitation"], answer: 0, explanation: "Newton's First Law states that an object in motion tends to stay in motion unless acted upon by an external unbalanced force." },
    { id: 4, question: "When plotting an Acceleration vs Force graph, what does the slope represent?", options: ["Mass (m)", "Reciprocal of mass (1/m)", "Velocity (v)", "Momentum (p)"], answer: 1, explanation: "Since a = (1/m) * F, plotting a on y-axis and F on x-axis gives slope m_graph = 1/m." },
    { id: 5, question: "In a laboratory trolley experiment, why is the runway slightly tilted?", options: ["To increase gravity", "To compensate for friction", "To make the trolley roll faster", "To reduce air resistance"], answer: 1, explanation: "Tilting the runway balances out kinetic friction so the trolley moves at constant velocity when no extra pulling force is applied." }
  ]);
  database.run("INSERT OR IGNORE INTO Generated_Quizzes (id, user_id, title, subject, difficulty, question_type, questions_json, score, total_questions) VALUES (2, 1, 'Newton''s Laws & Dynamics', 'Physical Science', 'Exam Level', 'Multiple Choice', ?, -1, 5)", [sampleQuiz2]);

  // Seed Learning Insights
  database.run("INSERT OR IGNORE INTO Learning_Insights (id, user_id, insight_type, title, description, subject, action_recommended) VALUES (1, 1, 'Strength', 'Top 5% in Algebra Logic', 'Your accuracy on polynomial factorizations has improved by 15% over the last 3 practice sessions.', 'Mathematics', 'Try Exam-Level Algebra Quiz')");
  database.run("INSERT OR IGNORE INTO Learning_Insights (id, user_id, insight_type, title, description, subject, action_recommended) VALUES (2, 1, 'Improvement Area', 'Physics Graph Interpretation', 'You frequently pause on questions requiring acceleration gradient calculations. Recommend visual step-by-step review.', 'Physical Science', 'Revise Newton Lab Notes')");
  database.run("INSERT OR IGNORE INTO Learning_Insights (id, user_id, insight_type, title, description, subject, action_recommended) VALUES (3, 1, 'Habit', 'Consistent Evening Scholar', 'You complete 85% of your study sessions between 18:00 and 20:30. Your concentration score peaks during this window.', 'General', 'Schedule Hardest Subjects at 18:00')");
  database.run("INSERT OR IGNORE INTO Learning_Insights (id, user_id, insight_type, title, description, subject, action_recommended) VALUES (4, 1, 'Recommendation', 'Python Vocabulary Mastery', 'You have mastered basic list operations. Ready to tackle dictionary comprehension and JSON parsing!', 'Computer Studies', 'Generate Python Flashcards')");

  // Seed Study Recommendations
  database.run("INSERT OR IGNORE INTO Study_Recommendations (id, user_id, title, subject, recommendation_type, reason, priority, action_text, action_link, is_completed) VALUES (1, 1, 'Complete Math Exercise 42 (Q9-15)', 'Mathematics', 'Study Today', 'Due tomorrow at 14:00. You''ve already mastered Q1-8!', 'High', 'Continue Mathematics', 'subject:Mathematics', 0)");
  database.run("INSERT OR IGNORE INTO Study_Recommendations (id, user_id, title, subject, recommendation_type, reason, priority, action_text, action_link, is_completed) VALUES (2, 1, 'Revise Newton''s Second Law Formulas', 'Physical Science', 'Revise', 'Upcoming lab report due Friday. Reviewing formulas will speed up data tabulation.', 'Medium', 'Revise Biology & Science', 'subject:Physical Science', 0)");
  database.run("INSERT OR IGNORE INTO Study_Recommendations (id, user_id, title, subject, recommendation_type, reason, priority, action_text, action_link, is_completed) VALUES (3, 1, 'Prepare for Friday''s NSSCO Math Test', 'Mathematics', 'Deadline Prep', 'Only 3 days remaining until your mock exam in the main hall.', 'High', 'Prepare for Friday''s Test', 'quiz:1', 0)");
  database.run("INSERT OR IGNORE INTO Study_Recommendations (id, user_id, title, subject, recommendation_type, reason, priority, action_text, action_link, is_completed) VALUES (4, 1, 'Review yesterday''s mistakes in Physics', 'Physical Science', 'Workload Balance', 'You missed 2 questions on friction forces in your last session.', 'Medium', 'Review yesterday''s mistakes', 'flashcards:Physical Science', 0)");
}

export function queryAll(db: Database, sqlStr: string, params: any[] = []): any[] {
  const stmt = db.prepare(sqlStr);
  stmt.bind(params);
  const results = [];
  while (stmt.step()) {
    results.push(stmt.getAsObject());
  }
  stmt.free();
  return results;
}

export function queryOne(db: Database, sqlStr: string, params: any[] = []): any | null {
  const res = queryAll(db, sqlStr, params);
  return res.length > 0 ? res[0] : null;
}

export function execRun(db: Database, sqlStr: string, params: any[] = []): { lastInsertRowid: number, changes: number } {
  db.run(sqlStr, params);
  const lastIdRes = db.exec("SELECT last_insert_rowid() as id");
  const changesRes = db.exec("SELECT changes() as ch");
  const lastInsertRowid = Number(lastIdRes[0]?.values[0]?.[0] || 0);
  const changes = Number(changesRes[0]?.values[0]?.[0] || 0);
  saveDb();
  return { lastInsertRowid, changes };
}
