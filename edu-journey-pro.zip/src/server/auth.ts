import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { Request, Response, NextFunction } from 'express';

const JWT_SECRET = process.env.JWT_SECRET || 'edujourney-pro-super-secret-key-namibia-2026';
const TOKEN_EXPIRY = '24h';

// Rate Limiter store for login attempts (IP -> { count, resetTime })
const rateLimitStore = new Map<string, { count: number; resetTime: number }>();

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${hash}:${salt}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  try {
    const [hash, salt] = storedHash.split(':');
    if (!hash || !salt) return false;
    const verifyHash = crypto.scryptSync(password, salt, 64).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(verifyHash, 'hex'));
  } catch (e) {
    return false;
  }
}

export function generateToken(payload: object): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
}

export function verifyToken(token: string): any | null {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (e) {
    return null;
  }
}

export function checkRateLimit(ip: string, maxAttempts = 5, windowMs = 15 * 60 * 1000): { allowed: boolean; remaining: number; resetInSeconds: number } {
  const now = Date.now();
  const record = rateLimitStore.get(ip);

  if (!record || now > record.resetTime) {
    rateLimitStore.set(ip, { count: 1, resetTime: now + windowMs });
    return { allowed: true, remaining: maxAttempts - 1, resetInSeconds: Math.ceil(windowMs / 1000) };
  }

  if (record.count >= maxAttempts) {
    const resetInSeconds = Math.ceil((record.resetTime - now) / 1000);
    return { allowed: false, remaining: 0, resetInSeconds };
  }

  record.count += 1;
  return { allowed: true, remaining: maxAttempts - record.count, resetInSeconds: Math.ceil((record.resetTime - now) / 1000) };
}

export function resetRateLimit(ip: string) {
  rateLimitStore.delete(ip);
}

export function generateCsrfToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

export function validateAge(dateOfBirth: string, minAge = 10): { valid: boolean; age: number } {
  const dob = new Date(dateOfBirth);
  if (isNaN(dob.getTime())) return { valid: false, age: 0 };
  
  const today = new Date();
  let age = today.getFullYear() - dob.getFullYear();
  const m = today.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
    age--;
  }
  return { valid: age >= minAge && age <= 100, age };
}

export interface AuthRequest extends Request {
  user?: {
    id: number;
    email: string;
    role: string;
  };
}

export function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const cookieToken = req.cookies?.edujourney_session;
  
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : cookieToken;
  
  if (!token) {
    return res.status(401).json({ success: false, error: 'Unauthorized: No authentication token provided' });
  }

  const decoded = verifyToken(token);
  if (!decoded || !decoded.id) {
    return res.status(401).json({ success: false, error: 'Unauthorized: Invalid or expired session token' });
  }

  req.user = decoded;
  next();
}
