import express from 'express';
import { getDb, queryAll, queryOne, execRun } from './db.js';
import { AuthRequest, requireAuth } from './auth.js';
import { GoogleGenAI } from '@google/genai';

const router = express.Router();

// Lazy initialization of GoogleGenAI client
let aiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key) {
      try {
        aiClient = new GoogleGenAI({
          apiKey: key,
          httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
        });
      } catch (e) {
        console.warn("Failed to initialize GoogleGenAI:", e);
        return null;
      }
    }
  }
  return aiClient;
}

// 1. GET /api/edubuddy/home - Get AI Home screen data
router.get('/home', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;

    const profile = queryOne(db, "SELECT * FROM Student_Profile WHERE user_id = ?", [userId]) || {};
    const preferences = queryOne(db, "SELECT * FROM Student_AI_Preferences WHERE user_id = ?", [userId]) || {
      avatar: 'robot-1',
      greeting: 'Ready to master your goals today?',
      conversation_style: 'Friendly',
      humor_level: 'Balanced',
      response_length: 'Concise',
      theme_color: 'emerald',
      animation_style: 'Smooth'
    };
    const memory = queryOne(db, "SELECT * FROM Memory_Profile WHERE user_id = ?", [userId]) || {
      preferred_learning_style: 'Visual & Step-by-Step',
      favorite_subjects: '["Mathematics","Computer Studies"]',
      weak_topics: '["Quadratic Word Problems","Newton Second Law Graphing"]',
      career_goals: '["Software Engineer","Data Scientist"]',
      preferred_explanations: 'Step-by-Step',
      study_habits: '["Evening study sessions","45-minute Pomodoro intervals"]'
    };

    const streak = queryOne(db, "SELECT * FROM Learning_Streaks WHERE user_id = ?", [userId]) || { consecutive_days: 7, xp_total: 2450 };
    const todayAssignments = queryAll(db, "SELECT * FROM Assignments WHERE user_id = ? AND status != 'Completed' ORDER BY due_date ASC LIMIT 4", [userId]);
    const recentConversations = queryAll(db, "SELECT * FROM AI_Conversations WHERE user_id = ? ORDER BY updated_at DESC LIMIT 5", [userId]);
    const pinnedChats = queryAll(db, "SELECT * FROM AI_Conversations WHERE user_id = ? AND is_pinned = 1 ORDER BY updated_at DESC", [userId]);
    const recommendations = queryAll(db, "SELECT * FROM Study_Recommendations WHERE user_id = ? AND is_completed = 0 ORDER BY priority ASC LIMIT 4", [userId]);
    const insights = queryAll(db, "SELECT * FROM Learning_Insights WHERE user_id = ? ORDER BY created_at DESC LIMIT 4", [userId]);
    const bookmarksCount = queryOne(db, "SELECT count(*) as cnt FROM Bookmarks WHERE user_id = ?", [userId]);
    const flashcardsCount = queryOne(db, "SELECT count(*) as cnt FROM Flashcards WHERE user_id = ?", [userId]);

    // Format fields
    const parsedMemory = {
      ...memory,
      favorite_subjects: typeof memory.favorite_subjects === 'string' ? JSON.parse(memory.favorite_subjects) : (memory.favorite_subjects || []),
      weak_topics: typeof memory.weak_topics === 'string' ? JSON.parse(memory.weak_topics) : (memory.weak_topics || []),
      career_goals: typeof memory.career_goals === 'string' ? JSON.parse(memory.career_goals) : (memory.career_goals || []),
      study_habits: typeof memory.study_habits === 'string' ? JSON.parse(memory.study_habits) : (memory.study_habits || [])
    };

    res.json({
      success: true,
      data: {
        studentName: profile.full_name?.split(' ')[0] || 'Scholar',
        dailyMotivation: "Success is the sum of small efforts repeated day in and day out. Let's make today count!",
        currentStudyGoal: "Master Quadratic Equations & Physics Lab Data",
        learningStreak: streak.consecutive_days || 7,
        xpTotal: streak.xp_total || 2450,
        preferences,
        memory: parsedMemory,
        todayAssignments,
        recentConversations,
        pinnedChats,
        recommendations,
        insights,
        stats: {
          bookmarks: bookmarksCount?.cnt || 0,
          flashcards: flashcardsCount?.cnt || 0
        },
        quickSuggestions: [
          { title: "Continue Mathematics", subtitle: "Quadratic Formula Ex 42 Q9-15", icon: "📐", action: "chat", subject: "Mathematics", prompt: "Let's continue working on Quadratic Equations Ex 42. Can you guide me through question 9?" },
          { title: "Revise Biology & Science", subtitle: "Newton's Second Law & Lab Report", icon: "⚡", action: "chat", subject: "Physical Science", prompt: "Can you review Newton's Second Law with me and check my understanding of force vs acceleration graphs?" },
          { title: "Prepare for Friday's Test", subtitle: "NSSCO Math Mock Exam Prep", icon: "👑", action: "quiz", subject: "Mathematics", prompt: "Generate an Exam-Level quiz on Algebra and Functions to prepare for Friday's mock test." },
          { title: "Review yesterday's mistakes", subtitle: "Friction & Dynamics Practice", icon: "🔄", action: "flashcards", subject: "Physical Science", prompt: "Let's review flashcards on Physics Dynamics and friction compensation." }
        ]
      }
    });
  } catch (err: any) {
    console.error("Error in /home:", err);
    res.status(500).json({ success: false, error: 'Failed to load Edu Buddy home data' });
  }
});

// 2. GET & POST /api/edubuddy/preferences
router.get('/preferences', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const preferences = queryOne(db, "SELECT * FROM Student_AI_Preferences WHERE user_id = ?", [userId]) || {};
    res.json({ success: true, data: preferences });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch AI preferences' });
  }
});

router.post('/preferences', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { avatar, greeting, conversation_style, humor_level, response_length, theme_color, animation_style } = req.body;

    const existing = queryOne(db, "SELECT id FROM Student_AI_Preferences WHERE user_id = ?", [userId]);
    if (existing) {
      execRun(db, `UPDATE Student_AI_Preferences SET avatar = ?, greeting = ?, conversation_style = ?, humor_level = ?, response_length = ?, theme_color = ?, animation_style = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?`, [
        avatar || 'robot-1',
        greeting || 'Ready to learn today?',
        conversation_style || 'Friendly',
        humor_level || 'Balanced',
        response_length || 'Concise',
        theme_color || 'emerald',
        animation_style || 'Smooth',
        userId
      ]);
    } else {
      execRun(db, `INSERT INTO Student_AI_Preferences (user_id, avatar, greeting, conversation_style, humor_level, response_length, theme_color, animation_style) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, [
        userId, avatar || 'robot-1', greeting || 'Ready to learn today?', conversation_style || 'Friendly', humor_level || 'Balanced', response_length || 'Concise', theme_color || 'emerald', animation_style || 'Smooth'
      ]);
    }

    const updated = queryOne(db, "SELECT * FROM Student_AI_Preferences WHERE user_id = ?", [userId]);
    res.json({ success: true, data: updated, message: 'AI personality preferences updated!' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to update AI preferences' });
  }
});

// 3. GET & POST /api/edubuddy/memory
router.get('/memory', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const memory = queryOne(db, "SELECT * FROM Memory_Profile WHERE user_id = ?", [userId]) || {};
    res.json({
      success: true,
      data: {
        ...memory,
        favorite_subjects: typeof memory.favorite_subjects === 'string' ? JSON.parse(memory.favorite_subjects) : (memory.favorite_subjects || []),
        weak_topics: typeof memory.weak_topics === 'string' ? JSON.parse(memory.weak_topics) : (memory.weak_topics || []),
        career_goals: typeof memory.career_goals === 'string' ? JSON.parse(memory.career_goals) : (memory.career_goals || []),
        study_habits: typeof memory.study_habits === 'string' ? JSON.parse(memory.study_habits) : (memory.study_habits || [])
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch AI memory profile' });
  }
});

router.post('/memory', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { preferred_learning_style, favorite_subjects, weak_topics, career_goals, preferred_explanations, study_habits, past_topics_summary } = req.body;

    const existing = queryOne(db, "SELECT id FROM Memory_Profile WHERE user_id = ?", [userId]);
    if (existing) {
      execRun(db, `UPDATE Memory_Profile SET preferred_learning_style = ?, favorite_subjects = ?, weak_topics = ?, career_goals = ?, preferred_explanations = ?, study_habits = ?, past_topics_summary = ?, last_updated = CURRENT_TIMESTAMP WHERE user_id = ?`, [
        preferred_learning_style || 'Visual & Step-by-Step',
        JSON.stringify(favorite_subjects || ['Mathematics', 'Computer Studies']),
        JSON.stringify(weak_topics || ['Quadratic Word Problems', 'Newton Second Law Graphing']),
        JSON.stringify(career_goals || ['Software Engineer', 'Data Scientist']),
        preferred_explanations || 'Step-by-Step',
        JSON.stringify(study_habits || ['Evening study sessions', '45-minute Pomodoro intervals']),
        past_topics_summary || 'Recently discussed quadratic formula derivations and trolley physics.',
        userId
      ]);
    } else {
      execRun(db, `INSERT INTO Memory_Profile (user_id, preferred_learning_style, favorite_subjects, weak_topics, career_goals, preferred_explanations, study_habits, past_topics_summary) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, [
        userId,
        preferred_learning_style || 'Visual & Step-by-Step',
        JSON.stringify(favorite_subjects || ['Mathematics', 'Computer Studies']),
        JSON.stringify(weak_topics || ['Quadratic Word Problems', 'Newton Second Law Graphing']),
        JSON.stringify(career_goals || ['Software Engineer', 'Data Scientist']),
        preferred_explanations || 'Step-by-Step',
        JSON.stringify(study_habits || ['Evening study sessions', '45-minute Pomodoro intervals']),
        past_topics_summary || 'Recently discussed quadratic formula derivations and trolley physics.'
      ]);
    }

    const updated = queryOne(db, "SELECT * FROM Memory_Profile WHERE user_id = ?", [userId]);
    res.json({ success: true, data: updated, message: 'Memory profile updated successfully!' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to update memory profile' });
  }
});

// 4. GET /api/edubuddy/recommendations
router.get('/recommendations', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const recommendations = queryAll(db, "SELECT * FROM Study_Recommendations WHERE user_id = ? ORDER BY priority ASC, id DESC", [userId]);
    res.json({ success: true, data: recommendations });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to load recommendations' });
  }
});

router.post('/recommendations/:id/complete', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const recId = Number(req.params.id);
    execRun(db, "UPDATE Study_Recommendations SET is_completed = 1 WHERE id = ? AND user_id = ?", [recId, userId]);
    res.json({ success: true, message: 'Recommendation marked as completed!' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to complete recommendation' });
  }
});

// 5. GET /api/edubuddy/insights
router.get('/insights', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const insights = queryAll(db, "SELECT * FROM Learning_Insights WHERE user_id = ? ORDER BY created_at DESC", [userId]);
    res.json({ success: true, data: insights });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to load learning insights' });
  }
});

// 6. GET /api/edubuddy/conversations
router.get('/conversations', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { q } = req.query;

    let sql = "SELECT * FROM AI_Conversations WHERE user_id = ?";
    const params: any[] = [userId];

    if (q) {
      sql += " AND (title LIKE ? OR subject LIKE ? OR id IN (SELECT conversation_id FROM Conversation_History WHERE content LIKE ? AND user_id = ?))";
      const searchTerm = `%${q}%`;
      params.push(searchTerm, searchTerm, searchTerm, userId);
    }
    sql += " ORDER BY is_pinned DESC, updated_at DESC";

    const conversations = queryAll(db, sql, params);
    res.json({ success: true, data: conversations });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to load conversations' });
  }
});

// 7. POST /api/edubuddy/conversations - Create new chat
router.post('/conversations', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { title, subject, explanation_mode } = req.body;

    const result = execRun(db, `INSERT INTO AI_Conversations (user_id, title, subject, explanation_mode, created_at, updated_at) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`, [
      userId, title || 'New Learning Chat', subject || 'General', explanation_mode || 'Normal'
    ]);

    const newChat = queryOne(db, "SELECT * FROM AI_Conversations WHERE id = ?", [result.lastInsertRowid]);
    res.json({ success: true, data: newChat });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to create new conversation' });
  }
});

// 8. DELETE /api/edubuddy/conversations/:id
router.delete('/conversations/:id', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const convId = Number(req.params.id);

    execRun(db, "DELETE FROM AI_Conversations WHERE id = ? AND user_id = ?", [convId, userId]);
    execRun(db, "DELETE FROM Pinned_Chats WHERE conversation_id = ? AND user_id = ?", [convId, userId]);
    res.json({ success: true, message: 'Conversation deleted successfully' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to delete conversation' });
  }
});

// 9. PATCH /api/edubuddy/conversations/:id - Rename or Toggle pin
router.patch('/conversations/:id', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const convId = Number(req.params.id);
    const { title, is_pinned } = req.body;

    const current = queryOne(db, "SELECT * FROM AI_Conversations WHERE id = ? AND user_id = ?", [convId, userId]);
    if (!current) {
      return res.status(404).json({ success: false, error: 'Conversation not found' });
    }

    if (title !== undefined) {
      execRun(db, "UPDATE AI_Conversations SET title = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [title, convId]);
    }
    if (is_pinned !== undefined) {
      const pinVal = is_pinned ? 1 : 0;
      execRun(db, "UPDATE AI_Conversations SET is_pinned = ? WHERE id = ?", [pinVal, convId]);
      if (pinVal === 1) {
        execRun(db, "INSERT OR IGNORE INTO Pinned_Chats (user_id, conversation_id) VALUES (?, ?)", [userId, convId]);
      } else {
        execRun(db, "DELETE FROM Pinned_Chats WHERE user_id = ? AND conversation_id = ?", [userId, convId]);
      }
    }

    const updated = queryOne(db, "SELECT * FROM AI_Conversations WHERE id = ?", [convId]);
    res.json({ success: true, data: updated });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to update conversation' });
  }
});

// 10. GET /api/edubuddy/conversations/:id/messages
router.get('/conversations/:id/messages', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const convId = Number(req.params.id);

    const messages = queryAll(db, "SELECT * FROM Conversation_History WHERE conversation_id = ? AND user_id = ? ORDER BY id ASC", [convId, userId]);
    res.json({ success: true, data: messages });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to load conversation messages' });
  }
});

// 11. POST /api/edubuddy/chat - CORE AI CHAT ENDPOINT
router.post('/chat', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    let { conversation_id, message, subject, explanation_mode, is_homework_help } = req.body;

    if (!message || !message.trim()) {
      return res.status(400).json({ success: false, error: 'Message content is required' });
    }

    // If no conversation_id, create a new one
    if (!conversation_id) {
      const titleSnippet = message.length > 35 ? message.substring(0, 35) + '...' : message;
      const convRes = execRun(db, `INSERT INTO AI_Conversations (user_id, title, subject, explanation_mode, created_at, updated_at) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`, [
        userId, titleSnippet, subject || 'General', explanation_mode || 'Normal'
      ]);
      conversation_id = convRes.lastInsertRowid;
    } else {
      execRun(db, "UPDATE AI_Conversations SET updated_at = CURRENT_TIMESTAMP WHERE id = ?", [conversation_id]);
    }

    // Save user message
    const userMsgRes = execRun(db, `INSERT INTO Conversation_History (conversation_id, user_id, sender, content, explanation_mode, is_bookmarked) VALUES (?, ?, 'user', ?, ?, 0)`, [
      conversation_id, userId, message, explanation_mode || 'Normal'
    ]);

    // Check rate limiting or harmful prompt keyword detection
    const lowerMsg = message.toLowerCase();
    const harmfulKeywords = ["do my homework for me without explaining", "write my exam answer to cheat", "bully", "hack the school"];
    if (harmfulKeywords.some(kw => lowerMsg.includes(kw))) {
      const safetyReply = `I am your Edu Buddy AI companion! While I would love to help you excel, my mission is to **teach, guide, explain, and support your learning**. I cannot complete assignments or exams directly for grading or bypass safety rules.\n\nHowever, let's break this topic down together step-by-step so you can master it yourself with full confidence! Where would you like to start?`;
      const aiMsgRes = execRun(db, `INSERT INTO Conversation_History (conversation_id, user_id, sender, content, explanation_mode, is_bookmarked) VALUES (?, ?, 'ai', ?, ?, 0)`, [
        conversation_id, userId, safetyReply, explanation_mode || 'Normal'
      ]);
      return res.json({
        success: true,
        data: { id: aiMsgRes.lastInsertRowid, conversation_id, sender: 'ai', content: safetyReply, explanation_mode: explanation_mode || 'Normal', created_at: new Date().toISOString() }
      });
    }

    // Get student context
    const profile = queryOne(db, "SELECT * FROM Student_Profile WHERE user_id = ?", [userId]) || {};
    const preferences = queryOne(db, "SELECT * FROM Student_AI_Preferences WHERE user_id = ?", [userId]) || {};
    const memory = queryOne(db, "SELECT * FROM Memory_Profile WHERE user_id = ?", [userId]) || {};

    let aiReply = "";
    const client = getAiClient();

    if (client) {
      try {
        const systemInstruction = `You are Edu Buddy, an intelligent, friendly, patient, professional, and encouraging AI educational companion for a Namibian secondary school student named ${profile.full_name || 'Student'} (Grade ${profile.grade || '10'}).
Your purpose is to teach, guide, encourage, motivate, explain, coach, and support learning. You must NEVER replace teachers or parents, and NEVER encourage cheating or simply complete assessments intended for grading.
Current Subject: ${subject || 'General'}.
Requested Explanation Mode: ${explanation_mode || 'Normal'}.
Student Learning Style Preference: ${memory.preferred_learning_style || 'Step-by-Step'}.
Student Favorite Subjects: ${memory.favorite_subjects || 'Mathematics, Science'}.
Student Weak Topics: ${memory.weak_topics || 'Word problems, graphs'}.

When explaining:
1. Use clean Markdown formatting with bullet points, bold text for key terms, and code blocks if relevant.
2. For mathematical equations, use LaTeX syntax ($...$ or $$...$$).
3. If explanation mode is 'Explain Like I\'m 10', use fun everyday analogies and zero intimidation.
4. If explanation mode is 'Teacher Mode', ask guiding Socratic questions.
5. If explanation mode is 'Exam Mode', highlight NSSCO grading criteria, common pitfalls, and time management tips.
6. If explanation mode is 'Visual Learning', include structured markdown tables or ASCII diagrams to visualize concepts.
7. Always end with an encouraging word or a follow-up practice check!`;

        const response = await client.models.generateContent({
          model: 'gemini-3.6-flash',
          contents: message,
          config: {
            systemInstruction,
            temperature: 0.7
          }
        });

        if (response.text) {
          aiReply = response.text;
        }
      } catch (err) {
        console.warn("Gemini API call failed, falling back to heuristic reply:", err);
      }
    }

    // Fallback if Gemini key missing or call failed
    if (!aiReply) {
      aiReply = generateHeuristicBuddyReply(message, subject || 'General', explanation_mode || 'Normal', profile.full_name?.split(' ')[0] || 'Scholar', is_homework_help);
    }

    // Save AI message
    const aiMsgRes = execRun(db, `INSERT INTO Conversation_History (conversation_id, user_id, sender, content, explanation_mode, is_bookmarked) VALUES (?, ?, 'ai', ?, ?, 0)`, [
      conversation_id, userId, aiReply, explanation_mode || 'Normal'
    ]);

    res.json({
      success: true,
      data: {
        id: aiMsgRes.lastInsertRowid,
        conversation_id,
        sender: 'ai',
        content: aiReply,
        explanation_mode: explanation_mode || 'Normal',
        created_at: new Date().toISOString()
      }
    });
  } catch (err: any) {
    console.error("Error in /chat:", err);
    res.status(500).json({ success: false, error: 'Failed to process chat message' });
  }
});

// Helper for heuristic/offline intelligent replies
function generateHeuristicBuddyReply(userMsg: string, subject: string, mode: string, studentName: string, isHomework: boolean): string {
  const lower = userMsg.toLowerCase();

  if (mode === 'Explain Like I\'m 10') {
    return `### Let's make this super fun and easy, ${studentName}! 🎈\n\nImagine **${subject}** is like building with Lego blocks! Every problem has little pieces that fit together.\n\n* **The Big Idea**: When we look at your question about *"**${userMsg.length > 40 ? userMsg.substring(0, 40) + '...' : userMsg}**"*, think of it like balancing a seesaw at the playground.\n* **Why it works**: If you put weight on one side, you must put the exact same weight on the other side to keep it balanced!\n\nDoes this Lego seesaw picture make sense so far? What piece should we add next? 🚀`;
  }

  if (mode === 'Teacher Mode') {
    return `### Hello scholar! Let's put on our thinking caps 🎓\n\nAs your study mentor, I won't just give away the final answer—you learn best by discovering the steps!\n\nLet's examine your question: *"**${userMsg.length > 50 ? userMsg.substring(0, 50) + '...' : userMsg}**"*\n\n1. **First Question for You**: What is the primary formula or principle in **${subject}** that connects the variables in this problem?\n2. **Hint**: Check if we need to isolate an unknown term or convert our units to SI standard first.\n\nWhat do you think our very first calculation step should be? I am right here with you!`;
  }

  if (mode === 'Exam Mode') {
    return `### NSSCO Exam Strategy for ${subject} 📋👑\n\nWhen examiners mark questions related to *"**${userMsg.length > 40 ? userMsg.substring(0, 40) + '...' : userMsg}**"*, they look for 3 specific criteria:\n\n| Assessment Objective | What Examiner Expects | Common Pitfall to Avoid |\n| :--- | :--- | :--- |\n| **AO1: Knowledge** | State exact definition or formula accurately | Using informal words instead of terminology |\n| **AO2: Application** | Substitute known values clearly with units | Omitting intermediate calculation steps |\n| **AO3: Analysis** | Double-check logical reasonableness of answer | Forgetting sign (+/-) or decimal precision |\n\n**Key Formula to Memorize**:\n$$\\text{Result} = \\frac{\\text{Change in Value}}{\\text{Time elapsed}} \\times 100\\%$$\n\nTry writing out your answer using these 3 headers—you'll score full marks! 🌟`;
  }

  if (mode === 'Visual Learning') {
    return `### Let's Visualize This Concept, ${studentName}! 📊👁️\n\nVisualizing **${subject}** makes abstract theory unforgettable! Here is how your concept breaks down:\n\n\`\`\`\n[ Input Data / Given Variables ]\n           │\n           ▼\n[ Core Principle / Formula ] ──► ( Check Discriminant / Units )\n           │\n           ▼\n[ Step-by-Step Resolution ]  ──► ( Final Verified Answer )\n\`\`\`\n\n### Comparison Breakdown:\n| Feature / Step | Action Required | Pro-Tip |\n| :--- | :--- | :--- |\n| **Step 1: Identify** | List knowns and unknowns | Circle numbers in the question |\n| **Step 2: Connect** | Select appropriate formula | Keep equation balanced |\n| **Step 3: Solve** | Execute calculation cleanly | Always attach correct units |\n\nDoes seeing this workflow flowchart help organize your approach? What step shall we tackle first?`;
  }

  if (isHomework || lower.includes("homework") || lower.includes("solve") || lower.includes("assignment")) {
    return `### Homework Guidance: Let's Break It Down! 📝💡\n\nI'm here to guide your thinking so you master this **${subject}** problem yourself without cheating!\n\n#### 🔍 Step 1: Understand What is Asked\nYou are investigating: *"**${userMsg.length > 50 ? userMsg.substring(0, 50) + '...' : userMsg}**"*\n\n#### 🛠️ Step 2: Key Formula & Method\nIn **${subject}**, we approach this by isolating our target variable. For example:\n$$\\text{Target Variable} = \\frac{\\text{Total Force or Sum}}{\\text{Coefficient}}$$\n\n#### 💡 Guiding Hint\nBefore substituting your numbers, ensure all your units match (e.g., convert grams to kg, or minutes to seconds). Once substituted, simplify the numerator first!\n\nWhat result do you get when you simplify the first step? Let me know and I'll check your work! 👍`;
  }

  // Normal / Step-by-Step default
  return `### Excellent question on ${subject}, ${studentName}! 🌟\n\nLet's explore *"**${userMsg.length > 55 ? userMsg.substring(0, 55) + '...' : userMsg}**"* clearly and systematically.\n\n#### 1. Core Concept & Definition\nIn **${subject}**, this topic revolves around understanding systematic relationships and logical rules. By mastering the fundamental principles, complex problems become straightforward.\n\n#### 2. Step-by-Step Breakdown\n* **Step 1: Identify the Knowns**: Look at the information provided and list your variables.\n* **Step 2: Apply the Appropriate Principle**: Use standard formulas or analytical frameworks.\n  $$\\text{Rate of Progress} = \\frac{\\Delta y}{\\Delta x}$$\n* **Step 3: Verify Your Outcome**: Substitute your result back into the original condition to confirm accuracy.\n\n#### 3. Pro-Tip for Mastery 💡\nAlways review your mistakes from practice exercises—that is where 80% of grade jumps happen!\n\nWould you like me to generate a **Quick Practice Quiz** or **Flashcards** on this topic to cement your understanding? 🚀`;
}

// 12. GET, POST, DELETE /api/edubuddy/bookmarks
router.get('/bookmarks', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const bookmarks = queryAll(db, "SELECT * FROM Bookmarks WHERE user_id = ? ORDER BY created_at DESC", [userId]);
    res.json({ success: true, data: bookmarks });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to load bookmarks' });
  }
});

router.post('/bookmarks', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { conversation_id, message_id, title, snippet, category } = req.body;

    const result = execRun(db, `INSERT INTO Bookmarks (user_id, conversation_id, message_id, title, snippet, category) VALUES (?, ?, ?, ?, ?, ?)`, [
      userId, conversation_id || null, message_id || null, title || 'Saved Note', snippet || '', category || 'General'
    ]);

    if (message_id) {
      execRun(db, "UPDATE Conversation_History SET is_bookmarked = 1 WHERE id = ?", [message_id]);
    }
    if (conversation_id) {
      execRun(db, "UPDATE AI_Conversations SET is_bookmarked = 1 WHERE id = ?", [conversation_id]);
    }

    const item = queryOne(db, "SELECT * FROM Bookmarks WHERE id = ?", [result.lastInsertRowid]);
    res.json({ success: true, data: item, message: 'Bookmark saved!' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to create bookmark' });
  }
});

router.delete('/bookmarks/:id', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const bmId = Number(req.params.id);

    const bm = queryOne(db, "SELECT * FROM Bookmarks WHERE id = ? AND user_id = ?", [bmId, userId]);
    if (bm && bm.message_id) {
      execRun(db, "UPDATE Conversation_History SET is_bookmarked = 0 WHERE id = ?", [bm.message_id]);
    }
    execRun(db, "DELETE FROM Bookmarks WHERE id = ? AND user_id = ?", [bmId, userId]);
    res.json({ success: true, message: 'Bookmark removed' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to remove bookmark' });
  }
});

// 13. GET, POST, PATCH /api/edubuddy/flashcards
router.get('/flashcards', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { subject } = req.query;

    let sql = "SELECT * FROM Flashcards WHERE user_id = ?";
    const params: any[] = [userId];
    if (subject && subject !== 'All') {
      sql += " AND subject = ?";
      params.push(subject);
    }
    sql += " ORDER BY id DESC";

    const cards = queryAll(db, sql, params);
    res.json({ success: true, data: cards });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to load flashcards' });
  }
});

router.post('/flashcards', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { subject, topic, question, answer } = req.body;

    const result = execRun(db, `INSERT INTO Flashcards (user_id, subject, topic, question, answer, status, is_bookmarked) VALUES (?, ?, ?, ?, ?, 'Needs Practice', 0)`, [
      userId, subject || 'General', topic || 'Key Concept', question, answer
    ]);

    const newCard = queryOne(db, "SELECT * FROM Flashcards WHERE id = ?", [result.lastInsertRowid]);
    res.json({ success: true, data: newCard, message: 'Flashcard created!' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to create flashcard' });
  }
});

router.patch('/flashcards/:id', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const cardId = Number(req.params.id);
    const { status, is_bookmarked } = req.body;

    if (status !== undefined) {
      execRun(db, "UPDATE Flashcards SET status = ? WHERE id = ? AND user_id = ?", [status, cardId, userId]);
    }
    if (is_bookmarked !== undefined) {
      execRun(db, "UPDATE Flashcards SET is_bookmarked = ? WHERE id = ? AND user_id = ?", [is_bookmarked ? 1 : 0, cardId, userId]);
    }

    const updated = queryOne(db, "SELECT * FROM Flashcards WHERE id = ?", [cardId]);
    res.json({ success: true, data: updated });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to update flashcard' });
  }
});

router.post('/flashcards/generate', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { subject, topic, count = 5 } = req.body;

    let generatedCards: any[] = [];
    const client = getAiClient();

    if (client) {
      try {
        const prompt = `Generate exactly ${count} high-yield educational flashcards for a secondary school student studying ${subject || 'General'} (Topic: ${topic || 'Key Concepts'}).
Return ONLY a JSON array of objects with properties: "question" and "answer". Do not include markdown code fences or extra text.`;

        const response = await client.models.generateContent({
          model: 'gemini-3.6-flash',
          contents: prompt,
          config: { responseMimeType: "application/json" }
        });
        if (response.text) {
          generatedCards = JSON.parse(response.text.trim());
        }
      } catch (err) {
        console.warn("Gemini flashcard generation failed, using heuristic fallback:", err);
      }
    }

    if (!generatedCards || generatedCards.length === 0) {
      const sub = subject || 'General';
      const top = topic || 'Core Essentials';
      generatedCards = [
        { question: `What is the fundamental definition of ${top} in ${sub}?`, answer: `${top} refers to the core systematic rule governing relationships and calculations in ${sub}.` },
        { question: `What is the primary formula or principle associated with ${top}?`, answer: `Always check your units, apply standard balance laws, and verify intermediate calculations.` },
        { question: `Why is ${top} critical for NSSCO exam success?`, answer: `It forms the foundation for Section B structured application questions carrying 15-20% of total exam marks.` },
        { question: `State one common student pitfall when analyzing ${top}.`, answer: `Forgetting sign changes (+/-) or neglecting to state SI units in the final numerical conclusion.` },
        { question: `How can you self-verify your solution in ${top}?`, answer: `Substitute the calculated unknown back into the original condition to confirm exact identity.` }
      ];
    }

    const saved: any[] = [];
    for (const c of generatedCards) {
      const resId = execRun(db, `INSERT INTO Flashcards (user_id, subject, topic, question, answer, status, is_bookmarked) VALUES (?, ?, ?, ?, ?, 'Needs Practice', 0)`, [
        userId, subject || 'General', topic || 'AI Generated', c.question, c.answer
      ]);
      const item = queryOne(db, "SELECT * FROM Flashcards WHERE id = ?", [resId.lastInsertRowid]);
      if (item) saved.push(item);
    }

    res.json({ success: true, data: saved, message: `Generated ${saved.length} new flashcards for ${topic || subject}!` });
  } catch (err: any) {
    console.error("Error generating flashcards:", err);
    res.status(500).json({ success: false, error: 'Failed to auto-generate flashcards' });
  }
});

// 14. GET & POST /api/edubuddy/quizzes
router.get('/quizzes', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const quizzes = queryAll(db, "SELECT * FROM Generated_Quizzes WHERE user_id = ? ORDER BY id DESC", [userId]);
    res.json({ success: true, data: quizzes });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to load quizzes' });
  }
});

router.post('/quizzes/generate', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { subject, topic, difficulty = 'Medium', question_type = 'Multiple Choice', count = 5 } = req.body;

    let questions: any[] = [];
    const client = getAiClient();

    if (client) {
      try {
        const prompt = `Generate an educational quiz of type "${question_type}" with difficulty "${difficulty}" for secondary school subject "${subject}" on topic "${topic || subject}". Generate exactly ${count} questions.
Return ONLY a JSON array of objects where each object has:
- id: integer (1 to ${count})
- question: string
- options: array of 4 string options (if Multiple Choice or True/False)
- answer: integer index (0 to 3) of the correct option
- explanation: detailed explanation string of why the answer is correct.`;

        const response = await client.models.generateContent({
          model: 'gemini-3.6-flash',
          contents: prompt,
          config: { responseMimeType: "application/json" }
        });
        if (response.text) {
          questions = JSON.parse(response.text.trim());
        }
      } catch (err) {
        console.warn("Gemini quiz generation failed, using heuristic fallback:", err);
      }
    }

    if (!questions || questions.length === 0) {
      const sub = subject || 'Mathematics';
      const top = topic || 'Core Principles';
      questions = [
        { id: 1, question: `Which statement best describes the primary rule of ${top} in ${sub}?`, options: [`It requires balanced equations and unit consistency`, `It applies only to theoretical non-SI conditions`, `It ignores initial boundary values`, `It is only used in university-level calculus`], answer: 0, explanation: `In secondary school ${sub}, unit consistency and balanced conditions are paramount.` },
        { id: 2, question: `When solving a problem involving ${top}, what is the recommended first step?`, options: [`Skip directly to the final formula`, `List all given variables and required unknowns`, `Guess an approximate integer value`, `Eliminate decimal places immediately`], answer: 1, explanation: `Listing knowns and unknowns systematically prevents substitution errors.` },
        { id: 3, question: `If an examiner asks to "Analyze the relationship" in ${top}, what must your answer include?`, options: [`Only a single word YES or NO`, `Direct proportionality or mathematical dependency with units`, `A historical biography of the scientist`, `An informal guess without calculations`], answer: 1, explanation: `Analysis questions require stating exact dependencies (e.g., directly or inversely proportional).` },
        { id: 4, question: `What is the most common student error when tackling ${difficulty}-level questions in ${sub}?`, options: [`Writing too neatly`, `Forgetting negative sign conventions or squaring terms`, `Using blue ink instead of black ink`, `Reading the question twice`], answer: 1, explanation: `Sign conventions and squaring/square-rooting errors account for the majority of mark deductions.` },
        { id: 5, question: `How should you verify your final numerical solution in ${top}?`, options: [`By checking if it looks familiar`, `By substituting the result back into the original equation`, `By asking a classmate during the test`, `By leaving it blank if unsure`], answer: 1, explanation: `Reverse substitution confirms mathematical identity and ensures full marks.` }
      ];
    }

    const titleStr = `${topic || subject}: ${difficulty} Practice`;
    const result = execRun(db, `INSERT INTO Generated_Quizzes (user_id, title, subject, difficulty, question_type, questions_json, score, total_questions) VALUES (?, ?, ?, ?, ?, ?, -1, ?)`, [
      userId, titleStr, subject || 'General', difficulty, question_type, JSON.stringify(questions), questions.length
    ]);

    const newQuiz = queryOne(db, "SELECT * FROM Generated_Quizzes WHERE id = ?", [result.lastInsertRowid]);
    res.json({ success: true, data: newQuiz, message: `Generated new ${difficulty} quiz on ${topic || subject}!` });
  } catch (err: any) {
    console.error("Error generating quiz:", err);
    res.status(500).json({ success: false, error: 'Failed to generate quiz' });
  }
});

router.post('/quizzes/:id/submit', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const quizId = Number(req.params.id);
    const { score } = req.body;

    execRun(db, "UPDATE Generated_Quizzes SET score = ?, completed_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?", [score, quizId, userId]);

    // Also award some XP to Learning_Streaks
    execRun(db, "UPDATE Learning_Streaks SET xp_total = xp_total + 100 WHERE user_id = ?", [userId]);

    res.json({ success: true, message: `Quiz completed! You scored ${score}% and earned +100 XP!` });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to submit quiz score' });
  }
});

// 15. POST /api/edubuddy/summarize - SUMMARY TOOL
router.post('/summarize', async (req: AuthRequest, res) => {
  try {
    const { notes_text, format = 'Summary', subject = 'General' } = req.body;

    if (!notes_text || !notes_text.trim()) {
      return res.status(400).json({ success: false, error: 'Please paste your study notes or text to summarize.' });
    }

    let summaryOutput = "";
    const client = getAiClient();

    if (client) {
      try {
        const prompt = `You are Edu Buddy, an expert study coach.
The student has pasted study notes for subject "${subject}".
Please generate an educational output in the exact requested format: "${format}".
Options for format are: Summary, Bullet Points, Key Concepts, Important Definitions, Revision Notes, or Mind Map Outline.
Use clean Markdown formatting, bold headings, bullet lists, and LaTeX math notation ($...$) where applicable. Make it highly structured and easy to revise for exams.

Here are the notes:
${notes_text}`;

        const response = await client.models.generateContent({
          model: 'gemini-3.6-flash',
          contents: prompt
        });
        if (response.text) {
          summaryOutput = response.text;
        }
      } catch (err) {
        console.warn("Gemini summarization failed, using heuristic fallback:", err);
      }
    }

    if (!summaryOutput) {
      const words = notes_text.split(/\s+/).length;
      const snippet = notes_text.length > 100 ? notes_text.substring(0, 100) + '...' : notes_text;

      if (format === 'Bullet Points') {
        summaryOutput = `### 📌 Bullet Point Summary (${subject})\n\nBased on your ${words} words of study notes:\n* **Core Theme**: Analysis of *"${snippet}"*\n* **Primary Principle**: Systematic consistency and unit verification are essential for mastery.\n* **Key Takeaway 1**: Ensure all formulas are memorized in their standard SI form.\n* **Key Takeaway 2**: When solving multi-step questions, isolate variables before substituting numerical values.\n* **Action Step**: Test yourself by attempting 3 practice questions without looking at these notes!`;
      } else if (format === 'Key Concepts') {
        summaryOutput = `### 🔑 Key Concepts Extracted (${subject})\n\n1. **Fundamental Definition**: The theoretical framework describing relationships within *"${snippet}"*.\n2. **Analytical Derivation**: Why the formula holds true across standard experimental boundary conditions.\n3. **Practical Application**: Connecting abstract classroom theory to real-world Namibian industrial and environmental examples.\n4. **NSSCO Exam Relevance**: High-probability topic frequently tested in Paper 1 structured short-answer sections.`;
      } else if (format === 'Important Definitions') {
        summaryOutput = `### 📖 Important Glossary & Definitions (${subject})\n\n| Term / Concept | Precise Academic Definition | Easy Memory Hook |\n| :--- | :--- | :--- |\n| **Primary Principle** | The fundamental law governing behavior in *"${snippet}"*. | "The Golden Rule" |\n| **SI Unit Standard** | The International System of Units used universally in scientific calculations. | "Always check meters & seconds" |\n| **Direct Proportionality** | When variable A doubles, variable B doubles simultaneously ($A \\propto B$). | "Moving together in sync" |\n| **Discriminant / Condition** | The diagnostic check determining root properties or stability. | "The filter before solving" |`;
      } else if (format === 'Mind Map Outline') {
        summaryOutput = `### 🧠 Mind Map Structural Outline (${subject})\n\n\`\`\`\n[ Central Theme: ${subject} Mastery ]\n ├── 1. Theoretical Foundations\n │    ├── Core Definitions & Terminology\n │    └── Historical & Scientific Principles\n ├── 2. Mathematical & Analytical Rules\n │    ├── Primary Equations & Derivations\n │    └── SI Unit Conversions\n ├── 3. Problem Solving Methodology\n │    ├── Step 1: Identify Knowns & Unknowns\n │    ├── Step 2: Formula Substitution\n │    └── Step 3: Result Verification\n └── 4. NSSCO Exam Prep\n      ├── Common Pitfalls to Avoid\n      └── High-Yield Past Paper Exercises\n\`\`\`\n\n*Pro-Tip: Draw this exact structure on a blank piece of paper from memory!*`;
      } else {
        // Default Summary / Revision Notes
        summaryOutput = `### 📝 Comprehensive Revision Summary (${subject})\n\n#### 1. Overview of Study Material\nYou provided **${words} words** covering critical aspects of **${subject}**. The material focuses on establishing a strong conceptual foundation and systematic analytical habits.\n\n#### 2. Core Takeaways\n* **Primary Focus**: *"${snippet}"*\n* **Methodology**: Success requires step-by-step problem decomposition and continuous verification against boundary rules.\n* **Exam Tip**: Examiners award partial credit for showing clear working formulas even if the final arithmetic calculation has a minor typo.\n\n#### 3. Recommended Next Action 🚀\nTurn these notes into active learning! Would you like me to generate **Flashcards** or an **Exam-Level Quiz** from this exact text?`;
      }
    }

    res.json({ success: true, data: { format, subject, summary: summaryOutput, wordCount: notes_text.split(/\s+/).length } });
  } catch (err: any) {
    console.error("Error in /summarize:", err);
    res.status(500).json({ success: false, error: 'Failed to generate study summary' });
  }
});

export default router;
