import express from 'express';
import edubuddyRouter from './edubuddyRoutes.js';
import { getDb, queryAll, queryOne, execRun } from './db.js';
import { 
  hashPassword, 
  verifyPassword, 
  generateToken, 
  checkRateLimit, 
  resetRateLimit, 
  validateAge, 
  generateCsrfToken,
  AuthRequest,
  requireAuth
} from './auth.js';

const router = express.Router();

function getOnboardingState(db: any, userId: number) {
  const profile = queryOne(db, "SELECT * FROM Student_Profile WHERE user_id = ?", [userId]) || {};
  const prog = queryOne(db, "SELECT * FROM Onboarding_Progress WHERE user_id = ?", [userId]) || { current_step: 1, is_completed: 0 };
  const acad = queryOne(db, "SELECT * FROM Student_Academic WHERE user_id = ?", [userId]) || {};
  const learn = queryOne(db, "SELECT * FROM Learning_Preferences WHERE user_id = ?", [userId]) || {};
  const career = queryOne(db, "SELECT * FROM Career_Dreams WHERE user_id = ?", [userId]) || {};
  const buddy = queryOne(db, "SELECT * FROM Edu_Buddy_Profile WHERE user_id = ?", [userId]) || {};
  const notif = queryOne(db, "SELECT * FROM Notification_Preferences WHERE user_id = ?", [userId]) || {};
  const priv = queryOne(db, "SELECT * FROM Privacy_Settings WHERE user_id = ?", [userId]) || {};

  return {
    currentStep: prog.current_step || 1,
    isCompleted: Boolean(prog.is_completed),
    personalInfo: {
      profilePhoto: profile.profile_picture || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(profile.full_name || 'Student')}`,
      fullName: profile.full_name || '',
      gender: profile.gender || '',
      dateOfBirth: profile.date_of_birth || '',
      region: profile.region || 'Khomas',
      town: profile.town || 'Windhoek',
      school: profile.school || '',
      grade: profile.grade || 'Grade 10'
    },
    academicInfo: {
      subjectsStudying: profile.subjects ? JSON.parse(profile.subjects) : ['Mathematics', 'Physical Science', 'English First Language'],
      favouriteSubject: acad.favourite_subject || 'Mathematics',
      difficultSubject: acad.difficult_subject || 'Physical Science',
      academicGoals: acad.academic_goals ? JSON.parse(acad.academic_goals) : ['Improve Mathematics', 'Pass Grade 11', 'Prepare for NSSCO exams']
    },
    learningPreferences: {
      learningStyles: learn.learning_styles ? JSON.parse(learn.learning_styles) : ['Videos', 'Practice Questions', 'Interactive Activities'],
      studyFrequency: learn.study_frequency || 'Daily',
      sessionLength: learn.session_length || '45 Minutes',
      reminderTime: learn.reminder_time || 'Evening',
      customReminderTime: learn.custom_reminder_time || ''
    },
    interests: profile.interests ? JSON.parse(profile.interests) : ['Artificial Intelligence & Robotics', 'Software Development & Coding'],
    careerDreams: career.career_dreams ? JSON.parse(career.career_dreams) : ['Software Developer', 'AI Engineer', 'Entrepreneur'],
    eduBuddy: {
      aiName: buddy.ai_name || 'Edu Buddy',
      aiAvatar: buddy.ai_avatar || 'robot-emerald',
      voicePreference: buddy.voice_preference || 'default',
      conversationStyle: (buddy.conversation_style || 'Motivational') as any,
      accentColor: buddy.accent_color || 'emerald',
      greetingStyle: buddy.greeting_style || "Let's conquer today's lessons!",
      customGreeting: buddy.custom_greeting || ''
    },
    notifications: {
      studyReminders: notif.study_reminders !== undefined ? Boolean(notif.study_reminders) : true,
      assignmentReminders: notif.assignment_reminders !== undefined ? Boolean(notif.assignment_reminders) : true,
      learningStreaks: notif.learning_streaks !== undefined ? Boolean(notif.learning_streaks) : true,
      motivationalMessages: notif.motivational_messages !== undefined ? Boolean(notif.motivational_messages) : true,
      schoolAnnouncements: notif.school_announcements !== undefined ? Boolean(notif.school_announcements) : true
    },
    privacySettings: {
      profileVisibility: (priv.profile_visibility || 'Friends Only') as any
    }
  };
}

// 1. Get Initial Setup Data (Regions, Schools, Subjects, Interests)
router.get('/init-data', async (req, res) => {
  try {
    const db = await getDb();
    const regions = queryAll(db, "SELECT * FROM Regions ORDER BY name ASC");
    const schools = queryAll(db, "SELECT * FROM Schools ORDER BY region, name ASC");
    const subjects = queryAll(db, "SELECT * FROM Subjects ORDER BY category, name ASC");
    const interests = queryAll(db, "SELECT * FROM Interests ORDER BY category, name ASC");
    
    res.json({
      success: true,
      data: { regions, schools, subjects, interests }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch initialization data' });
  }
});

// 2. Student Registration
router.post('/auth/register', async (req, res) => {
  try {
    const db = await getDb();
    const {
      fullName,
      email,
      password,
      confirmPassword,
      gender,
      dateOfBirth,
      region,
      town,
      school,
      grade,
      subjects = [],
      interests = [],
      profilePicture = null
    } = req.body;

    // Validation
    if (!fullName || !email || !password || !confirmPassword || !dateOfBirth || !region || !town || !school || !grade) {
      return res.status(400).json({ success: false, error: 'Please complete all required fields.' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ success: false, error: 'Please enter a valid email address.' });
    }

    if (password !== confirmPassword) {
      return res.status(400).json({ success: false, error: 'Passwords do not match.' });
    }

    if (password.length < 8) {
      return res.status(400).json({ success: false, error: 'Password must be at least 8 characters long.' });
    }

    const ageCheck = validateAge(dateOfBirth, 10);
    if (!ageCheck.valid) {
      return res.status(400).json({ 
        success: false, 
        error: `Invalid Age (${ageCheck.age} years). Students must be at least 10 years old according to project safety guidelines.` 
      });
    }

    // Check if user already exists
    const existing = queryOne(db, "SELECT id FROM Users WHERE email = ?", [email.toLowerCase().trim()]);
    if (existing) {
      return res.status(409).json({ success: false, error: 'An account with this email address already exists.' });
    }

    // Hash password
    const passwordHash = hashPassword(password);
    
    // Insert into Users
    const userRes = execRun(db, "INSERT INTO Users (email, password_hash, role, status) VALUES (?, ?, 'student', 'active')", [email.toLowerCase().trim(), passwordHash]);
    const userId = userRes.lastInsertRowid;

    // Insert into Student_Profile
    execRun(db, `INSERT INTO Student_Profile 
      (user_id, full_name, gender, date_of_birth, region, town, school, grade, subjects, interests, profile_picture) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        userId, 
        fullName.trim(), 
        gender || 'Not Specified', 
        dateOfBirth, 
        region, 
        town, 
        school, 
        grade, 
        JSON.stringify(subjects), 
        JSON.stringify(interests), 
        profilePicture || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(fullName)}`
      ]
    );

    // Insert into User_Settings
    execRun(db, "INSERT INTO User_Settings (user_id, theme, notifications_email) VALUES (?, 'system', 1)", [userId]);

    // Insert into Authentication
    const verificationToken = `verif_${Math.random().toString(36).substring(2, 15)}_${Date.now()}`;
    execRun(db, "INSERT INTO Authentication (user_id, verification_token, is_email_verified) VALUES (?, ?, 0)", [userId, verificationToken]);

    // Phase 2 Onboarding initialization
    execRun(db, "INSERT INTO Onboarding_Progress (user_id, current_step, is_completed) VALUES (?, 1, 0)", [userId]);
    execRun(db, "INSERT INTO Student_Academic (user_id, favourite_subject, difficult_subject, academic_goals) VALUES (?, '', '', '[]')", [userId]);
    execRun(db, "INSERT INTO Learning_Preferences (user_id, learning_styles, study_frequency, session_length, reminder_time) VALUES (?, '[]', 'Daily', '45 Minutes', 'Evening')", [userId]);
    execRun(db, "INSERT INTO Career_Dreams (user_id, career_dreams) VALUES (?, '[]')", [userId]);
    execRun(db, "INSERT INTO Edu_Buddy_Profile (user_id, ai_name, ai_avatar, conversation_style, accent_color, greeting_style) VALUES (?, 'Edu Buddy', 'robot-emerald', 'Motivational', 'emerald', 'Ready to learn today?')", [userId]);
    execRun(db, "INSERT INTO Notification_Preferences (user_id, study_reminders, assignment_reminders, learning_streaks, motivational_messages, school_announcements) VALUES (?, 1, 1, 1, 1, 1)", [userId]);
    execRun(db, "INSERT INTO Privacy_Settings (user_id, profile_visibility) VALUES (?, 'Friends Only')", [userId]);

    // Generate Token & Session
    const token = generateToken({ id: userId, email: email.toLowerCase().trim(), role: 'student', fullName });
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
    execRun(db, "INSERT INTO Sessions (user_id, token, expires_at) VALUES (?, ?, ?)", [userId, token, expiresAt]);

    // Set cookie
    res.cookie('edujourney_session', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 24 * 60 * 60 * 1000
    });

    res.status(201).json({
      success: true,
      message: 'Student account registered successfully! Please check your email to verify your account.',
      token,
      verificationToken,
      user: {
        id: userId,
        email: email.toLowerCase().trim(),
        fullName,
        role: 'student',
        isEmailVerified: false,
        school,
        grade,
        region,
        town,
        profilePicture: profilePicture || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(fullName)}`,
        isOnboardingCompleted: false,
        onboardingStep: 1,
        onboardingData: getOnboardingState(db, userId)
      }
    });
  } catch (error: any) {
    console.error('Registration Error:', error);
    res.status(500).json({ success: false, error: 'Registration failed: ' + (error.message || 'Server error') });
  }
});

// 3. Student Login with Rate Limiting
router.post('/auth/login', async (req, res) => {
  try {
    const ip = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';
    const rateLimit = checkRateLimit(ip as string);

    if (!rateLimit.allowed) {
      return res.status(429).json({
        success: false,
        error: `Too many login attempts. For your security, please wait ${rateLimit.resetInSeconds} seconds before trying again.`
      });
    }

    const { email, password, rememberMe } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Please provide both email and password.' });
    }

    const db = await getDb();
    const user = queryOne(db, "SELECT * FROM Users WHERE email = ?", [email.toLowerCase().trim()]);

    if (!user || !verifyPassword(password, user.password_hash)) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password. Please verify your credentials.',
        remainingAttempts: rateLimit.remaining
      });
    }

    // Success -> Reset rate limit
    resetRateLimit(ip as string);

    // Fetch profile and auth status
    const profile = queryOne(db, "SELECT * FROM Student_Profile WHERE user_id = ?", [user.id]);
    const authStatus = queryOne(db, "SELECT * FROM Authentication WHERE user_id = ?", [user.id]);

    // Update last login IP & time
    execRun(db, "UPDATE Authentication SET last_login_ip = ?, last_login_at = CURRENT_TIMESTAMP WHERE user_id = ?", [ip as string, user.id]);

    const tokenPayload = {
      id: user.id,
      email: user.email,
      role: user.role,
      fullName: profile?.full_name || user.email
    };

    const token = generateToken(tokenPayload);
    const expiryMs = rememberMe ? 7 * 24 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000;
    const expiresAt = new Date(Date.now() + expiryMs).toISOString();

    execRun(db, "INSERT INTO Sessions (user_id, token, expires_at) VALUES (?, ?, ?)", [user.id, token, expiresAt]);

    res.cookie('edujourney_session', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: expiryMs
    });

    res.json({
      success: true,
      message: 'Login successful! Welcome to Edu Journey Pro.',
      token,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        fullName: profile?.full_name || user.email,
        isEmailVerified: Boolean(authStatus?.is_email_verified),
        school: profile?.school,
        grade: profile?.grade,
        region: profile?.region,
        town: profile?.town,
        profilePicture: profile?.profile_picture,
        isOnboardingCompleted: Boolean(queryOne(db, "SELECT is_completed FROM Onboarding_Progress WHERE user_id = ?", [user.id])?.is_completed),
        onboardingStep: queryOne(db, "SELECT current_step FROM Onboarding_Progress WHERE user_id = ?", [user.id])?.current_step || 1,
        onboardingData: getOnboardingState(db, user.id)
      }
    });
  } catch (error: any) {
    console.error('Login Error:', error);
    res.status(500).json({ success: false, error: 'Login failed due to a server error.' });
  }
});

// 4. Forgot Password
router.post('/auth/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ success: false, error: 'Please enter your registered email address.' });
    }

    const db = await getDb();
    const user = queryOne(db, "SELECT id, email FROM Users WHERE email = ?", [email.toLowerCase().trim()]);

    let resetToken = null;
    if (user) {
      resetToken = `reset_${Math.random().toString(36).substring(2, 15)}_${Date.now()}`;
      const expires = new Date(Date.now() + 60 * 60 * 1000).toISOString(); // 1 hr
      execRun(db, "UPDATE Authentication SET reset_token = ?, reset_token_expires = ? WHERE user_id = ?", [resetToken, expires, user.id]);
    }

    // Always respond with success to prevent email enumeration attacks (Security Best Practice)
    res.json({
      success: true,
      message: 'If an account exists with that email, we have sent password reset instructions to your inbox.',
      simulationResetToken: resetToken, // Returned in preview mode so user can test!
      email: email.toLowerCase().trim()
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: 'Failed to process forgot password request.' });
  }
});

// 5. Verify Email
router.post('/auth/verify-email', async (req, res) => {
  try {
    const { token, email } = req.body;
    const db = await getDb();

    let userAuth = null;
    if (token) {
      userAuth = queryOne(db, "SELECT * FROM Authentication WHERE verification_token = ?", [token]);
    } else if (email) {
      const u = queryOne(db, "SELECT id FROM Users WHERE email = ?", [email.toLowerCase().trim()]);
      if (u) {
        userAuth = queryOne(db, "SELECT * FROM Authentication WHERE user_id = ?", [u.id]);
      }
    }

    if (!userAuth) {
      return res.status(400).json({ success: false, error: 'Invalid or expired verification token.' });
    }

    execRun(db, "UPDATE Authentication SET is_email_verified = 1, verification_token = NULL WHERE user_id = ?", [userAuth.user_id]);

    res.json({
      success: true,
      message: 'Email address verified successfully! You now have full access to your student profile.'
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: 'Failed to verify email address.' });
  }
});

// 6. Get Current Authenticated User Profile
router.get('/auth/me', requireAuth, async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id;
    const user = queryOne(db, "SELECT id, email, role, status, created_at FROM Users WHERE id = ?", [userId]);
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found.' });
    }

    const profile = queryOne(db, "SELECT * FROM Student_Profile WHERE user_id = ?", [userId]);
    const authStatus = queryOne(db, "SELECT * FROM Authentication WHERE user_id = ?", [userId]);
    const settings = queryOne(db, "SELECT * FROM User_Settings WHERE user_id = ?", [userId]);

    res.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        status: user.status,
        createdAt: user.created_at,
        fullName: profile?.full_name || user.email,
        gender: profile?.gender,
        dateOfBirth: profile?.date_of_birth,
        region: profile?.region,
        town: profile?.town,
        school: profile?.school,
        grade: profile?.grade,
        subjects: profile?.subjects ? JSON.parse(profile.subjects) : [],
        interests: profile?.interests ? JSON.parse(profile.interests) : [],
        profilePicture: profile?.profile_picture,
        isEmailVerified: Boolean(authStatus?.is_email_verified),
        isOnboardingCompleted: Boolean(queryOne(db, "SELECT is_completed FROM Onboarding_Progress WHERE user_id = ?", [userId])?.is_completed),
        onboardingStep: queryOne(db, "SELECT current_step FROM Onboarding_Progress WHERE user_id = ?", [userId])?.current_step || 1,
        onboardingData: getOnboardingState(db, userId),
        settings: {
          theme: settings?.theme || 'system',
          notificationsEmail: Boolean(settings?.notifications_email),
          notificationsSms: Boolean(settings?.notifications_sms),
          language: settings?.language || 'en'
        }
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: 'Failed to retrieve user profile.' });
  }
});

// 7. Logout
router.post('/auth/logout', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const cookieToken = req.cookies?.edujourney_session;
    const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : cookieToken;

    if (token) {
      const db = await getDb();
      execRun(db, "DELETE FROM Sessions WHERE token = ?", [token]);
    }

    res.clearCookie('edujourney_session');
    res.json({ success: true, message: 'Logged out successfully.' });
  } catch (error: any) {
    res.status(500).json({ success: false, error: 'Error during logout.' });
  }
});

// 8. Database Architecture & Schema Inspector Endpoint (For Phase 1 Verification!)
router.get('/database/inspector', async (req, res) => {
  try {
    const db = await getDb();
    
    const tablesList = [
      { name: 'Users', description: 'Core user authentication identities, email addresses, roles, and account status.' },
      { name: 'Student_Profile', description: 'Detailed demographic and academic profiles: school, grade, region, town, subjects, and interests.' },
      { name: 'Schools', description: 'Pre-seeded registry of Namibian secondary and primary schools categorized by region and town.' },
      { name: 'Regions', description: 'All 14 geographical regions of Namibia (Khomas, Erongo, Oshana, ||Kharas, etc.).' },
      { name: 'Subjects', description: 'Standardized curriculum subjects across STEM, Humanities, Commerce, and Namibian languages.' },
      { name: 'Interests', description: 'Student career aspirations and extracurricular interests (AI, Robotics, AgriTech, Medicine, Law).' },
      { name: 'User_Settings', description: 'Personalized app preferences: dark/light theme, language, and communication notifications.' },
      { name: 'Authentication', description: 'Security audit trail: email verification tokens, password reset hashes, and login IP logs.' },
      { name: 'Sessions', description: 'Active JWT bearer tokens and session expiry tracking for secure stateful or stateless login.' },
      { name: 'Onboarding_Progress', description: 'Phase 2 progress tracker for student onboarding steps 1 through 10 and completion state.' },
      { name: 'Student_Academic', description: 'Phase 2 student academic profile: subjects studying, favourite/difficult subjects, and study goals.' },
      { name: 'Learning_Preferences', description: 'Phase 2 learning habits: preferred learning styles, study frequency, session lengths, and reminder times.' },
      { name: 'Career_Dreams', description: 'Phase 2 career aspirations and dream professions selected by the student.' },
      { name: 'Edu_Buddy_Profile', description: 'Phase 2 Edu Buddy AI customization: AI name, avatar style, voice preference, conversation tone, and greeting.' },
      { name: 'Notification_Preferences', description: 'Phase 2 fine-grained notification permissions for reminders, streaks, and school alerts.' },
      { name: 'Privacy_Settings', description: 'Phase 2 student profile visibility controls (Public, Friends Only, Private).' }
    ];

    const tablesData = tablesList.map(t => {
      const countRes = queryOne(db, `SELECT count(*) as count FROM ${t.name}`);
      const rows = queryAll(db, `SELECT * FROM ${t.name} LIMIT 5`);
      return {
        tableName: t.name,
        description: t.description,
        rowCount: countRes ? countRes.count : 0,
        sampleRows: rows
      };
    });

    res.json({
      success: true,
      phase: "Phase 2 Live & Phase 1 Foundation",
      projectName: "Edu Journey Pro",
      targetCountry: "Namibia",
      databaseEngine: "SQLite (WebAssembly / Memory-Persistent via sql.js)",
      tables: tablesData
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: 'Failed to inspect database architecture.' });
  }
});

// 9. Get Onboarding State
router.get('/onboarding/state', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    // Use authenticated user or fallback to demo user id 1 for testing
    const userId = req.user?.id || 1;
    const data = getOnboardingState(db, userId);
    res.json({ success: true, data });
  } catch (error: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch onboarding state' });
  }
});

// 10. Save Onboarding Progress Step
router.post('/onboarding/save', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { step, personalInfo, academicInfo, learningPreferences, interests, careerDreams, eduBuddy, notifications, privacySettings } = req.body;

    // Update Onboarding_Progress step
    if (step) {
      execRun(db, "INSERT OR REPLACE INTO Onboarding_Progress (id, user_id, current_step, is_completed, last_updated) VALUES ((SELECT id FROM Onboarding_Progress WHERE user_id = ?), ?, ?, (SELECT is_completed FROM Onboarding_Progress WHERE user_id = ?), CURRENT_TIMESTAMP)", [userId, userId, step, userId]);
    }

    // Update Student_Profile if personalInfo provided
    if (personalInfo) {
      execRun(db, `UPDATE Student_Profile SET full_name = ?, gender = ?, date_of_birth = ?, region = ?, town = ?, school = ?, grade = ?, profile_picture = ? WHERE user_id = ?`, [
        personalInfo.fullName,
        personalInfo.gender,
        personalInfo.dateOfBirth,
        personalInfo.region,
        personalInfo.town,
        personalInfo.school,
        personalInfo.grade,
        personalInfo.profilePhoto || null,
        userId
      ]);
    }

    // Update Student_Academic if academicInfo provided
    if (academicInfo) {
      execRun(db, `INSERT OR REPLACE INTO Student_Academic (id, user_id, favourite_subject, difficult_subject, academic_goals) VALUES ((SELECT id FROM Student_Academic WHERE user_id = ?), ?, ?, ?, ?)`, [
        userId, userId,
        academicInfo.favouriteSubject || '',
        academicInfo.difficultSubject || '',
        JSON.stringify(academicInfo.academicGoals || [])
      ]);
      if (academicInfo.subjectsStudying) {
        execRun(db, "UPDATE Student_Profile SET subjects = ? WHERE user_id = ?", [JSON.stringify(academicInfo.subjectsStudying), userId]);
      }
    }

    // Update Learning_Preferences if provided
    if (learningPreferences) {
      execRun(db, `INSERT OR REPLACE INTO Learning_Preferences (id, user_id, learning_styles, study_frequency, session_length, reminder_time, custom_reminder_time) VALUES ((SELECT id FROM Learning_Preferences WHERE user_id = ?), ?, ?, ?, ?, ?, ?)`, [
        userId, userId,
        JSON.stringify(learningPreferences.learningStyles || []),
        learningPreferences.studyFrequency || 'Daily',
        learningPreferences.sessionLength || '45 Minutes',
        learningPreferences.reminderTime || 'Evening',
        learningPreferences.customReminderTime || ''
      ]);
    }

    // Update Interests if provided
    if (interests) {
      execRun(db, "UPDATE Student_Profile SET interests = ? WHERE user_id = ?", [JSON.stringify(interests), userId]);
    }

    // Update Career_Dreams if provided
    if (careerDreams) {
      execRun(db, `INSERT OR REPLACE INTO Career_Dreams (id, user_id, career_dreams) VALUES ((SELECT id FROM Career_Dreams WHERE user_id = ?), ?, ?)`, [
        userId, userId,
        JSON.stringify(careerDreams)
      ]);
    }

    // Update Edu_Buddy_Profile if provided
    if (eduBuddy) {
      execRun(db, `INSERT OR REPLACE INTO Edu_Buddy_Profile (id, user_id, ai_name, ai_avatar, voice_preference, conversation_style, accent_color, greeting_style, custom_greeting) VALUES ((SELECT id FROM Edu_Buddy_Profile WHERE user_id = ?), ?, ?, ?, ?, ?, ?, ?, ?)`, [
        userId, userId,
        eduBuddy.aiName || 'Edu Buddy',
        eduBuddy.aiAvatar || 'robot-emerald',
        eduBuddy.voicePreference || 'default',
        eduBuddy.conversationStyle || 'Friendly',
        eduBuddy.accentColor || 'emerald',
        eduBuddy.greetingStyle || "Ready to learn today?",
        eduBuddy.customGreeting || ''
      ]);
    }

    // Update Notification_Preferences if provided
    if (notifications) {
      execRun(db, `INSERT OR REPLACE INTO Notification_Preferences (id, user_id, study_reminders, assignment_reminders, learning_streaks, motivational_messages, school_announcements) VALUES ((SELECT id FROM Notification_Preferences WHERE user_id = ?), ?, ?, ?, ?, ?, ?)`, [
        userId, userId,
        notifications.studyReminders ? 1 : 0,
        notifications.assignmentReminders ? 1 : 0,
        notifications.learningStreaks ? 1 : 0,
        notifications.motivationalMessages ? 1 : 0,
        notifications.schoolAnnouncements ? 1 : 0
      ]);
    }

    // Update Privacy_Settings if provided
    if (privacySettings) {
      execRun(db, `INSERT OR REPLACE INTO Privacy_Settings (id, user_id, profile_visibility) VALUES ((SELECT id FROM Privacy_Settings WHERE user_id = ?), ?, ?)`, [
        userId, userId,
        privacySettings.profileVisibility || 'Friends Only'
      ]);
    }

    const updatedState = getOnboardingState(db, userId);
    res.json({ success: true, message: 'Progress saved successfully', data: updatedState });
  } catch (error: any) {
    console.error('Save Onboarding Error:', error);
    res.status(500).json({ success: false, error: 'Failed to save onboarding progress' });
  }
});

// 11. Complete Onboarding
router.post('/onboarding/complete', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    
    // Mark as completed
    execRun(db, "INSERT OR REPLACE INTO Onboarding_Progress (id, user_id, current_step, is_completed, last_updated) VALUES ((SELECT id FROM Onboarding_Progress WHERE user_id = ?), ?, 10, 1, CURRENT_TIMESTAMP)", [userId, userId]);

    const finalState = getOnboardingState(db, userId);
    res.json({ success: true, message: 'Onboarding completed!', data: finalState });
  } catch (error: any) {
    res.status(500).json({ success: false, error: 'Failed to complete onboarding' });
  }
});

// ==========================================
// PHASE 3 API ENDPOINTS: STUDENT DASHBOARD
// ==========================================

const MOTIVATIONAL_QUOTES = [
  { quote: "One lesson today brings you closer to your dreams.", author: "Edu Journey Mentor" },
  { quote: "Success is built one study session at a time.", author: "Nelson Mandela" },
  { quote: "Education is the most powerful weapon which you can use to change the world.", author: "Nelson Mandela" },
  { quote: "The beautiful thing about learning is that no one can take it away from you.", author: "B.B. King" },
  { quote: "Do not let what you cannot do interfere with what you can do.", author: "John Wooden" },
  { quote: "Your future is created by what you do today, not tomorrow.", author: "Robert Kiyosaki" },
  { quote: "Small daily improvements over time lead to stunning results.", author: "Robin Sharma" }
];

router.get('/dashboard', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    
    // Get user and profile
    const userRow = queryOne(db, "SELECT * FROM Users WHERE id = ?", [userId]) || { id: userId, email: 'student@edujourney.na', role: 'student' };
    const profileRow = queryOne(db, "SELECT * FROM Student_Profile WHERE user_id = ?", [userId]) || { full_name: 'Tangi Amukwaya', grade: 'Grade 11', school: 'Delta Secondary School Windhoek' };
    const buddyRow = queryOne(db, "SELECT * FROM Edu_Buddy_Profile WHERE user_id = ?", [userId]) || { ai_name: 'Edu Buddy', ai_avatar: 'robot-emerald' };
    
    // Get streak
    const streakRow = queryOne(db, "SELECT * FROM Learning_Streak WHERE user_id = ?", [userId]) || {
      current_streak: 7, longest_streak: 12, last_activity_date: new Date().toISOString().split('T')[0],
      xp_total: 2450, badges: '["Early Bird", "Math Whiz", "Consistent Learner", "AI Explorer"]'
    };

    // Get notifications
    const notifications = queryAll(db, "SELECT * FROM Notifications WHERE user_id = ? ORDER BY id DESC LIMIT 10", [userId]).map(n => ({
      id: n.id,
      title: n.title,
      message: n.message,
      type: n.type as any,
      isRead: Boolean(n.is_read),
      link: n.link,
      createdAt: n.created_at
    }));

    // Get recent activity
    const recentActivity = queryAll(db, "SELECT * FROM Recent_Activity WHERE user_id = ? ORDER BY id DESC LIMIT 10", [userId]).map(a => ({
      id: a.id,
      activityType: a.activity_type as any,
      title: a.title,
      subtitle: a.subtitle,
      xpEarned: a.xp_earned || 0,
      timestamp: a.timestamp
    }));

    // Get widgets
    const widgets = queryAll(db, "SELECT * FROM Dashboard_Widgets WHERE user_id = ? ORDER BY position ASC", [userId]).map(w => ({
      id: w.id,
      widgetId: w.widget_id,
      title: w.title,
      isEnabled: Boolean(w.is_enabled),
      position: w.position,
      settings: w.settings ? JSON.parse(w.settings) : {}
    }));

    const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
    const quoteObj = MOTIVATIONAL_QUOTES[dayOfYear % MOTIVATIONAL_QUOTES.length];

    const dashboardData = {
      user: {
        ...userRow,
        fullName: profileRow.full_name || 'Student',
        grade: profileRow.grade || 'Grade 10',
        school: profileRow.school || 'Namibian High School',
        profilePicture: profileRow.profile_picture || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(profileRow.full_name || 'Student')}`
      },
      eduBuddy: {
        aiName: buddyRow.ai_name || 'Edu Buddy',
        aiAvatar: buddyRow.ai_avatar || 'robot-emerald',
        greetingStyle: buddyRow.greeting_style || 'Ready to learn today?'
      },
      streak: {
        currentStreak: streakRow.current_streak,
        longestStreak: streakRow.longest_streak,
        lastActivityDate: streakRow.last_activity_date,
        xpTotal: streakRow.xp_total,
        badges: typeof streakRow.badges === 'string' ? JSON.parse(streakRow.badges) : (streakRow.badges || [])
      },
      overview: {
        todaysAssignments: 3,
        studySessions: 2,
        upcomingEvents: 4,
        learningTimeMinutes: 165,
        completedTasks: 12,
        currentStreak: streakRow.current_streak
      },
      progress: [
        { id: 1, subject: 'Mathematics', progress: 84, trend: '+5% this week ↗', color: 'emerald', icon: '📐' },
        { id: 2, subject: 'Physical Science', progress: 78, trend: '+3% this week ↗', color: 'blue', icon: '🔬' },
        { id: 3, subject: 'English First Language', progress: 92, trend: '+4% this week ↗', color: 'purple', icon: '📚' },
        { id: 4, subject: 'Geography', progress: 88, trend: '+6% this week ↗', color: 'amber', icon: '🌍' },
        { id: 5, subject: 'History', progress: 74, trend: '+2% this week ↗', color: 'rose', icon: '🏛️' },
        { id: 6, subject: 'Computer Studies', progress: 95, trend: '+8% this week ↗', color: 'cyan', icon: '💻' }
      ],
      recentActivity: recentActivity.length > 0 ? recentActivity : [
        { id: 1, activityType: 'quiz', title: 'Completed Practice Quiz', subtitle: 'Algebra Level 1 - 95% Score achieved', xpEarned: 150, timestamp: '2 hours ago' },
        { id: 2, activityType: 'session', title: 'Started Study Session', subtitle: '45m Physical Science revision session', xpEarned: 100, timestamp: 'Yesterday' },
        { id: 3, activityType: 'profile', title: 'Updated Profile', subtitle: 'Selected Mathematics & Science academic goals', xpEarned: 50, timestamp: '2 days ago' },
        { id: 4, activityType: 'school', title: 'Joined School', subtitle: 'Delta Secondary School Windhoek registry linked', xpEarned: 50, timestamp: '3 days ago' },
        { id: 5, activityType: 'edubuddy', title: 'Created Edu Buddy', subtitle: 'Configured Emerald Spark AI study mentor', xpEarned: 100, timestamp: '3 days ago' }
      ],
      upcomingEvents: [
        { id: 1, title: 'Algebra Polynomials Practice', type: 'Homework', subject: 'Mathematics', date: 'Tomorrow, 14:00', time: '14:00', badgeColor: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20' },
        { id: 2, title: 'NSSCO Mock Exam prep', type: 'Test', subject: 'Physical Science', date: 'Friday, 09:00', time: '09:00', badgeColor: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20' },
        { id: 3, title: 'Essay Submission: Modern Africa', type: 'Deadline', subject: 'English First Language', date: 'Next Monday', time: '23:59', badgeColor: 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20' },
        { id: 4, title: 'Windhoek High School Science Fair', type: 'School Event', subject: 'General', date: 'In 2 weeks', time: '10:00', badgeColor: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20' }
      ],
      plannerPreview: {
        todaysGoal: 'Complete 2 Mathematics practice quizzes & read Physical Science Chapter 4',
        timeTargetMinutes: 180,
        timeCompletedMinutes: 165,
        nextReminder: '16:30 - Physical Science Revision',
        weeklyGoalHours: 15,
        weeklyCompletedHours: 12.5
      },
      achievements: [
        { id: 1, title: '7-Day Learning Streak 🔥', description: 'Log in and study 7 days in a row without breaking streak', icon: '🔥', isLocked: false, progress: 7, maxProgress: 7, xp: 500 },
        { id: 2, title: 'Early Bird Learner 🌅', description: 'Complete a morning study session before 08:00 AM', icon: '🌅', isLocked: false, progress: 1, maxProgress: 1, xp: 250 },
        { id: 3, title: 'Math Whiz 📐', description: 'Achieve 90%+ on 5 consecutive Mathematics practice quizzes', icon: '📐', isLocked: false, progress: 5, maxProgress: 5, xp: 600 },
        { id: 4, title: 'Consistent Learner ⭐', description: 'Log at least 15 hours of study time in a single week', icon: '⭐', isLocked: false, progress: 12.5, maxProgress: 15, xp: 400 },
        { id: 5, title: '30-Day Master 🏆', description: 'Maintain an active learning streak for 30 consecutive days', icon: '🏆', isLocked: true, progress: 7, maxProgress: 30, xp: 1500 },
        { id: 6, title: 'Exam Conqueror 👑', description: 'Score Top 5% in all NSSCO national simulated mock assessments', icon: '👑', isLocked: true, progress: 2, maxProgress: 5, xp: 2000 }
      ],
      widgets: widgets.length > 0 ? widgets : [
        { id: 1, widgetId: 'overview', title: "Today's Overview", isEnabled: true, position: 1 },
        { id: 2, widgetId: 'progress', title: 'Learning Progress', isEnabled: true, position: 2 },
        { id: 3, widgetId: 'actions', title: 'Quick Actions', isEnabled: true, position: 3 },
        { id: 4, widgetId: 'activity', title: 'Recent Activity', isEnabled: true, position: 4 },
        { id: 5, widgetId: 'upcoming', title: 'Upcoming Events', isEnabled: true, position: 5 },
        { id: 6, widgetId: 'planner', title: 'Study Planner Preview', isEnabled: true, position: 6 }
      ],
      notifications: notifications.length > 0 ? notifications : [
        { id: 1, title: 'Welcome to Edu Journey Pro! 🎉', message: 'Your personal student dashboard and learning workspace is live and ready for action.', type: 'welcome', isRead: false, createdAt: 'Just now' },
        { id: 2, title: 'Student Profile Initialized ⭐', message: 'Your Namibian school registry profile at Delta Secondary School Windhoek is verified.', type: 'profile', isRead: false, createdAt: '1 hour ago' },
        { id: 3, title: 'Edu Buddy AI Ready 🤖', message: 'Emerald Spark is configured with motivational conversation style. Click Ask Edu Buddy anytime!', type: 'edubuddy', isRead: false, createdAt: '2 hours ago' }
      ],
      motivationalQuote: quoteObj
    };

    res.json({ success: true, data: dashboardData });
  } catch (error: any) {
    console.error('Get Dashboard Error:', error);
    res.status(500).json({ success: false, error: 'Failed to load dashboard data' });
  }
});

router.get('/notifications', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const notifications = queryAll(db, "SELECT * FROM Notifications WHERE user_id = ? ORDER BY id DESC LIMIT 20", [userId]).map(n => ({
      id: n.id,
      title: n.title,
      message: n.message,
      type: n.type as any,
      isRead: Boolean(n.is_read),
      link: n.link,
      createdAt: n.created_at
    }));
    res.json({ success: true, data: notifications });
  } catch (error: any) {
    res.status(500).json({ success: false, error: 'Failed to load notifications' });
  }
});

router.post('/notifications/mark-read', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { id } = req.body;
    if (id) {
      execRun(db, "UPDATE Notifications SET is_read = 1 WHERE id = ? AND user_id = ?", [id, userId]);
    } else {
      execRun(db, "UPDATE Notifications SET is_read = 1 WHERE user_id = ?", [userId]);
    }
    res.json({ success: true, message: 'Notifications marked as read' });
  } catch (error: any) {
    res.status(500).json({ success: false, error: 'Failed to update notifications' });
  }
});

router.get('/activity', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const activity = queryAll(db, "SELECT * FROM Recent_Activity WHERE user_id = ? ORDER BY id DESC LIMIT 20", [userId]);
    res.json({ success: true, data: activity });
  } catch (error: any) {
    res.status(500).json({ success: false, error: 'Failed to load recent activity' });
  }
});

router.get('/progress', async (req: AuthRequest, res) => {
  res.json({
    success: true,
    data: [
      { id: 1, subject: 'Mathematics', progress: 84, trend: '+5% this week ↗', color: 'emerald', icon: '📐' },
      { id: 2, subject: 'Physical Science', progress: 72, trend: '+12% this week ↗', color: 'blue', icon: '⚡' },
      { id: 3, subject: 'English First Language', progress: 91, trend: 'Top 5% in class 👑', color: 'purple', icon: '📚' },
      { id: 4, subject: 'Computer Studies', progress: 88, trend: '+8% this week ↗', color: 'amber', icon: '💻' }
    ]
  });
});

router.get('/assignments/summary', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const assignments = queryAll(db, "SELECT * FROM Assignments WHERE user_id = ?", [userId]);
    const pending = assignments.filter(a => a.status !== 'Completed' && a.status !== 'Reviewed');
    const completed = assignments.filter(a => a.status === 'Completed' || a.status === 'Reviewed');
    const sessions = queryAll(db, "SELECT * FROM Study_Sessions WHERE user_id = ?", [userId]);
    const events = queryAll(db, "SELECT * FROM Calendar_Events WHERE user_id = ?", [userId]);
    const totalMinutes = sessions.reduce((acc, s) => acc + (s.duration_minutes || 0), 165);

    res.json({
      success: true,
      data: {
        todaysAssignments: pending.length || 3,
        studySessions: sessions.length || 2,
        upcomingEvents: events.length || 4,
        learningTimeMinutes: Math.round(totalMinutes),
        completedTasks: completed.length || 12,
        pendingCount: pending.length,
        completedCount: completed.length
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch assignment summary' });
  }
});

// =========================================================
// PHASE 4 API ENDPOINTS: Assignments, Calendar, Study Planner
// =========================================================

function parseAssignmentMeta(arrStr: string, isAttachment = false): any[] {
  if (!arrStr) return [];
  try {
    const parsed = JSON.parse(arrStr);
    if (!Array.isArray(parsed)) return [];
    return parsed.map((item, idx) => {
      if (typeof item === 'string') {
        const parts = item.split('|');
        if (isAttachment) {
          return {
            id: `att-${idx}-${Date.now()}`,
            title: parts[0] || 'Attachment',
            size: parts[1] || '120 KB',
            type: parts[2] || 'PDF',
            url: parts[3] || '#'
          };
        } else {
          return {
            title: parts[0] || 'Resource Link',
            url: parts[1] || '#',
            type: parts[2] || 'Web'
          };
        }
      }
      return item;
    });
  } catch (e) {
    return [];
  }
}

function formatAssignmentRow(db: any, row: any) {
  if (!row) return null;
  const notes = queryAll(db, "SELECT * FROM Assignment_Notes WHERE assignment_id = ? ORDER BY id DESC", [row.id]).map(n => ({
    ...n,
    is_pinned: Boolean(n.is_pinned),
    is_bookmarked: Boolean(n.is_bookmarked)
  }));
  const checklist = queryAll(db, "SELECT * FROM Assignment_Checklist WHERE assignment_id = ? ORDER BY item_order ASC, id ASC", [row.id]).map(c => ({
    ...c,
    is_completed: Boolean(c.is_completed)
  }));

  return {
    ...row,
    priority: row.priority || 'Medium',
    status: row.status || 'Not Started',
    progress: Number(row.progress || 0),
    estimated_time: Number(row.estimated_time || 60),
    difficulty: row.difficulty || 'Medium',
    resources: parseAssignmentMeta(row.resources, false),
    attachments: parseAssignmentMeta(row.attachments, true),
    notes,
    checklist
  };
}

// 1. ASSIGNMENTS ENDPOINTS
router.get('/assignments', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const rows = queryAll(db, "SELECT * FROM Assignments WHERE user_id = ? ORDER BY id DESC", [userId]);
    const assignments = rows.map(r => formatAssignmentRow(db, r));
    res.json({ success: true, data: assignments });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch assignments' });
  }
});

router.get('/assignments/:id', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { id } = req.params;
    const row = queryOne(db, "SELECT * FROM Assignments WHERE id = ? AND user_id = ?", [id, userId]);
    if (!row) return res.status(404).json({ success: false, error: 'Assignment not found' });
    res.json({ success: true, data: formatAssignmentRow(db, row) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch assignment details' });
  }
});

router.post('/assignments', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const {
      title,
      subject,
      teacher,
      due_date,
      priority = 'Medium',
      status = 'Not Started',
      estimated_time = 60,
      difficulty = 'Medium',
      instructions = '',
      teacher_notes = '',
      resources = [],
      attachments = []
    } = req.body;

    if (!title || !subject || !due_date) {
      return res.status(400).json({ success: false, error: 'Title, subject, and due date are required' });
    }

    const resJson = JSON.stringify(resources.map((r: any) => `${r.title}|${r.url}|${r.type || 'Web'}`));
    const attJson = JSON.stringify(attachments.map((a: any) => `${a.title}|${a.size || '100 KB'}|${a.type || 'File'}|${a.url || '#'}`));

    const { lastInsertRowid } = execRun(db, `INSERT INTO Assignments (
      user_id, title, subject, teacher, due_date, priority, status, progress, estimated_time, difficulty, instructions, teacher_notes, resources, attachments
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
      userId, title, subject, teacher || 'Class Teacher', due_date, priority, status, 0, estimated_time, difficulty, instructions, teacher_notes, resJson, attJson
    ]);

    // Add a default calendar event for due date
    execRun(db, `INSERT INTO Calendar_Events (user_id, title, event_type, subject, event_date, start_time, end_time, description, color, assignment_id) VALUES (
      ?, ?, 'Assignment', ?, ?, '14:00', '15:00', ?, 'emerald', ?
    )`, [userId, `${title} Due`, subject, due_date, `Assignment deadline for ${subject}`, lastInsertRowid]);

    const newRow = queryOne(db, "SELECT * FROM Assignments WHERE id = ?", [lastInsertRowid]);
    res.status(201).json({ success: true, data: formatAssignmentRow(db, newRow), message: 'Assignment created successfully!' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to create assignment' });
  }
});

router.put('/assignments/:id', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { id } = req.params;
    const existing = queryOne(db, "SELECT * FROM Assignments WHERE id = ? AND user_id = ?", [id, userId]);
    if (!existing) return res.status(404).json({ success: false, error: 'Assignment not found' });

    const {
      title = existing.title,
      subject = existing.subject,
      teacher = existing.teacher,
      due_date = existing.due_date,
      priority = existing.priority,
      status = existing.status,
      progress = existing.progress,
      estimated_time = existing.estimated_time,
      difficulty = existing.difficulty,
      instructions = existing.instructions,
      teacher_notes = existing.teacher_notes
    } = req.body;

    execRun(db, `UPDATE Assignments SET 
      title = ?, subject = ?, teacher = ?, due_date = ?, priority = ?, status = ?, progress = ?, estimated_time = ?, difficulty = ?, instructions = ?, teacher_notes = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND user_id = ?`, [
      title, subject, teacher, due_date, priority, status, progress, estimated_time, difficulty, instructions, teacher_notes, id, userId
    ]);

    // If status updated to completed, update streak stats
    if (status === 'Completed' && existing.status !== 'Completed') {
      execRun(db, "UPDATE Learning_Streaks SET assignments_completed = assignments_completed + 1, xp_total = xp_total + 100 WHERE user_id = ?", [userId]);
      execRun(db, "INSERT INTO Recent_Activity (user_id, activity_type, title, subtitle, xp_earned) VALUES (?, 'assignment', ?, ?, 100)", [
        userId, 'Completed Assignment', `${subject}: ${title}`, 100
      ]);
    }

    const updated = queryOne(db, "SELECT * FROM Assignments WHERE id = ?", [id]);
    res.json({ success: true, data: formatAssignmentRow(db, updated), message: 'Assignment updated!' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to update assignment' });
  }
});

router.delete('/assignments/:id', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { id } = req.params;
    execRun(db, "DELETE FROM Assignments WHERE id = ? AND user_id = ?", [id, userId]);
    execRun(db, "DELETE FROM Calendar_Events WHERE assignment_id = ? AND user_id = ?", [id, userId]);
    res.json({ success: true, message: 'Assignment removed' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to delete assignment' });
  }
});

// 2. ASSIGNMENT NOTES ENDPOINTS
router.post('/assignments/:id/notes', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { id } = req.params;
    const { content, note_type = 'student', is_pinned = false, is_bookmarked = false } = req.body;
    if (!content) return res.status(400).json({ success: false, error: 'Note content required' });

    const { lastInsertRowid } = execRun(db, `INSERT INTO Assignment_Notes (assignment_id, user_id, content, note_type, is_pinned, is_bookmarked) VALUES (?, ?, ?, ?, ?, ?)`, [
      id, userId, content, note_type, is_pinned ? 1 : 0, is_bookmarked ? 1 : 0
    ]);
    const newNote = queryOne(db, "SELECT * FROM Assignment_Notes WHERE id = ?", [lastInsertRowid]);
    res.status(201).json({ success: true, data: { ...newNote, is_pinned: Boolean(newNote.is_pinned), is_bookmarked: Boolean(newNote.is_bookmarked) } });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to add note' });
  }
});

router.put('/assignments/:id/notes/:noteId', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { noteId } = req.params;
    const existing = queryOne(db, "SELECT * FROM Assignment_Notes WHERE id = ? AND user_id = ?", [noteId, userId]);
    if (!existing) return res.status(404).json({ success: false, error: 'Note not found' });

    const {
      content = existing.content,
      is_pinned = Boolean(existing.is_pinned),
      is_bookmarked = Boolean(existing.is_bookmarked)
    } = req.body;

    execRun(db, "UPDATE Assignment_Notes SET content = ?, is_pinned = ?, is_bookmarked = ? WHERE id = ? AND user_id = ?", [
      content, is_pinned ? 1 : 0, is_bookmarked ? 1 : 0, noteId, userId
    ]);
    const updated = queryOne(db, "SELECT * FROM Assignment_Notes WHERE id = ?", [noteId]);
    res.json({ success: true, data: { ...updated, is_pinned: Boolean(updated.is_pinned), is_bookmarked: Boolean(updated.is_bookmarked) } });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to update note' });
  }
});

router.delete('/assignments/:id/notes/:noteId', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { noteId } = req.params;
    execRun(db, "DELETE FROM Assignment_Notes WHERE id = ? AND user_id = ?", [noteId, userId]);
    res.json({ success: true, message: 'Note deleted' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to delete note' });
  }
});

// 3. ASSIGNMENT CHECKLIST ENDPOINTS
router.post('/assignments/:id/checklist', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { id } = req.params;
    const { title, checklist_type = 'todo' } = req.body;
    if (!title) return res.status(400).json({ success: false, error: 'Task title required' });

    const existingCount = queryAll(db, "SELECT count(*) as c FROM Assignment_Checklist WHERE assignment_id = ?", [id])[0]?.c || 0;
    const { lastInsertRowid } = execRun(db, "INSERT INTO Assignment_Checklist (assignment_id, user_id, title, is_completed, item_order, checklist_type) VALUES (?, ?, ?, 0, ?, ?)", [
      id, userId, title, existingCount + 1, checklist_type
    ]);
    const newItem = queryOne(db, "SELECT * FROM Assignment_Checklist WHERE id = ?", [lastInsertRowid]);
    res.status(201).json({ success: true, data: { ...newItem, is_completed: false } });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to add checklist item' });
  }
});

router.put('/assignments/:id/checklist/:itemId', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { id, itemId } = req.params;
    const existing = queryOne(db, "SELECT * FROM Assignment_Checklist WHERE id = ? AND user_id = ?", [itemId, userId]);
    if (!existing) return res.status(404).json({ success: false, error: 'Item not found' });

    const is_completed = req.body.is_completed !== undefined ? (req.body.is_completed ? 1 : 0) : (existing.is_completed ? 0 : 1);
    execRun(db, "UPDATE Assignment_Checklist SET is_completed = ? WHERE id = ? AND user_id = ?", [is_completed, itemId, userId]);

    // Recalculate progress for assignment if checklist exists
    const items = queryAll(db, "SELECT * FROM Assignment_Checklist WHERE assignment_id = ?", [id]);
    if (items.length > 0) {
      const compCount = items.filter(i => Boolean(i.is_completed)).length;
      const newProg = Math.round((compCount / items.length) * 100);
      execRun(db, "UPDATE Assignments SET progress = ? WHERE id = ?", [newProg, id]);
    }

    const updated = queryOne(db, "SELECT * FROM Assignment_Checklist WHERE id = ?", [itemId]);
    res.json({ success: true, data: { ...updated, is_completed: Boolean(updated.is_completed) } });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to toggle item' });
  }
});

router.delete('/assignments/:id/checklist/:itemId', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { itemId } = req.params;
    execRun(db, "DELETE FROM Assignment_Checklist WHERE id = ? AND user_id = ?", [itemId, userId]);
    res.json({ success: true, message: 'Item removed' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to delete item' });
  }
});

// 4. AI ASSIGNMENT ASSISTANCE ENDPOINT
router.post('/assignments/:id/ai-assist', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { id } = req.params;
    const { action = 'explain', customPrompt = '' } = req.body;

    const assignment = queryOne(db, "SELECT * FROM Assignments WHERE id = ? AND user_id = ?", [id, userId]);
    if (!assignment) return res.status(404).json({ success: false, error: 'Assignment not found' });

    const eduBuddy = queryOne(db, "SELECT * FROM Edu_Buddy_Profile WHERE user_id = ?", [userId]) || { ai_name: 'Edu Buddy', accent_color: 'emerald' };
    const buddyName = eduBuddy.ai_name || 'Edu Buddy';

    let responseTitle = `${buddyName}'s Academic Guidance`;
    let responseText = '';
    let suggestedChecklist: string[] = [];
    let suggestedResources: Array<{ title: string; url: string }> = [];

    // ENFORCE STRICT NO-CHEATING ETHICS
    const honorPreamble = `🛡️ **${buddyName} Academic Honor Guarantee**: I am here to explain concepts, guide your research, and structure your study strategy. I will never complete the work for you or generate direct solutions that encourage academic dishonesty. Let's learn it together!\n\n`;

    if (action === 'explain') {
      responseTitle = `📖 Explaining "${assignment.title}"`;
      responseText = `${honorPreamble}Here is a clear, step-by-step breakdown of what your teacher (${assignment.teacher}) is asking for in **${assignment.subject}**:\n\n` +
        `**1. Core Objective:** You need to master the underlying concepts of ${assignment.title}. The key task is: *"${assignment.instructions || 'Review the chapter and solve the assigned exercises.'}"*\n\n` +
        `**2. Why This Matters:** This topic builds critical problem-solving skills needed for your upcoming NSSCO examinations in Namibia.\n\n` +
        `**3. How to Start:**\n` +
        `• **Step A:** Read over your class notes and highlight any definitions or formulas.\n` +
        `• **Step B:** Attempt the first 2 practice problems without looking at the solutions.\n` +
        `• **Step C:** If you get stuck, review the worked examples in your textbook or check out the suggested online resources!`;
    } else if (action === 'breakdown' || action === 'checklist') {
      responseTitle = `⚡ Actionable Task Breakdown for ${assignment.subject}`;
      responseText = `${honorPreamble}Breaking down a ${assignment.difficulty.toLowerCase()}-difficulty assignment into bite-sized milestones is the secret to stress-free study! Here is your structured roadmap:\n\n` +
        `**Phase 1: Preparation & Review (Approx. 20% of study time)**\n` +
        `Gather your textbooks, calculators, and review key formulas or vocabulary.\n\n` +
        `**Phase 2: Active Practice / Drafting (Approx. 60% of study time)**\n` +
        `Work through the main exercises or draft your initial paragraphs step-by-step.\n\n` +
        `**Phase 3: Verification & Polish (Approx. 20% of study time)**\n` +
        `Check units, verify spelling/grammar, and ensure all requirements from ${assignment.teacher} are checked off.`;

      suggestedChecklist = [
        `Review chapter concepts for ${assignment.subject}`,
        `Complete first half of assigned practice questions`,
        `Check answers against worked examples`,
        `Complete remaining questions & double-check calculations`,
        `Final review before submission to ${assignment.teacher}`
      ];

      // Auto-add suggested checklist items to database if requested
      if (action === 'checklist') {
        const existingCount = queryAll(db, "SELECT count(*) as c FROM Assignment_Checklist WHERE assignment_id = ?", [id])[0]?.c || 0;
        suggestedChecklist.forEach((itemTitle, idx) => {
          execRun(db, "INSERT INTO Assignment_Checklist (assignment_id, user_id, title, is_completed, item_order, checklist_type) VALUES (?, ?, ?, 0, ?, 'todo')", [
            id, userId, itemTitle, existingCount + idx + 1
          ]);
        });
      }
    } else if (action === 'estimate') {
      responseTitle = `⏱️ Realistic Study Time Estimate`;
      const est = assignment.estimated_time || 60;
      responseText = `${honorPreamble}Based on the **${assignment.difficulty}** difficulty level and curriculum standards for **${assignment.subject}**, I estimate this will take around **${est} minutes** of focused work.\n\n` +
        `**💡 Recommended Pomodoro Strategy:**\n` +
        `• **Session 1 (25 mins):** Read instructions and tackle the initial questions.\n` +
        `• **5-Minute Brain Break:** Stretch, drink water, and rest your eyes.\n` +
        `• **Session 2 (25 mins):** Finish the harder problems or draft the conclusion.\n` +
        `• **Final 10 mins:** Review your work for completeness before marking Ready to Submit!`;
    } else if (action === 'resources') {
      responseTitle = `📚 Curated Learning Resources for ${assignment.subject}`;
      responseText = `${honorPreamble}Here are top-tier educational references and tutorials to help you understand **${assignment.title}** deeply:\n\n` +
        `• **Khan Academy:** Free interactive video lessons and step-by-step practice modules.\n` +
        `• **Namibian NSSCO Past Papers:** Review previous exam questions on this exact topic to see how examiners frame questions.\n` +
        `• **PhET Interactive Simulations:** Visualizing science and math concepts dynamically makes them unforgettable!`;

      suggestedResources = [
        { title: `Khan Academy: ${assignment.subject} Mastery`, url: 'https://www.khanacademy.org' },
        { title: `NSSCO Syllabus Reference Guide`, url: 'https://www.moe.gov.na' },
        { title: `Interactive Study Glossary`, url: '#' }
      ];
    } else if (action === 'encourage') {
      responseTitle = `🌟 You've Got This, Champion!`;
      responseText = `${honorPreamble}**"Success is the sum of small efforts, repeated day in and day out."**\n\n` +
        `Every single equation you solve and every paragraph you write is building your mental superpower. Don't worry if it feels challenging at first — struggle is simply the sound of your brain growing stronger! Take a deep breath, trust your training, and let's conquer **${assignment.subject}** today! 🚀`;
    } else {
      responseTitle = `🤖 ${buddyName}'s Study Response`;
      responseText = `${honorPreamble}I analyzed your question about **"${assignment.title}"**: *"${customPrompt}"*.\n\n` +
        `To master this topic in **${assignment.subject}**, remember to break the problem down into known variables, apply your classroom formulas step-by-step, and never hesitate to ask your teacher for clarification on complex points. You are doing fantastic work!`;
    }

    const updated = queryOne(db, "SELECT * FROM Assignments WHERE id = ?", [id]);
    res.json({
      success: true,
      data: {
        title: responseTitle,
        text: responseText,
        checklistAdded: action === 'checklist' ? suggestedChecklist.length : 0,
        suggestedChecklist,
        suggestedResources,
        updatedAssignment: formatAssignmentRow(db, updated)
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'AI assistance failed' });
  }
});

// 5. CALENDAR EVENTS ENDPOINTS
router.get('/calendar', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const events = queryAll(db, "SELECT * FROM Calendar_Events WHERE user_id = ? ORDER BY event_date ASC, start_time ASC", [userId]);
    res.json({ success: true, data: events });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch calendar events' });
  }
});

router.post('/calendar', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const {
      title,
      event_type = 'Study Session',
      subject = 'General Study',
      event_date,
      start_time = '15:00',
      end_time = '16:00',
      description = '',
      color = 'emerald',
      assignment_id = null
    } = req.body;

    if (!title || !event_date) return res.status(400).json({ success: false, error: 'Title and date required' });

    const { lastInsertRowid } = execRun(db, `INSERT INTO Calendar_Events (
      user_id, title, event_type, subject, event_date, start_time, end_time, description, color, assignment_id
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
      userId, title, event_type, subject, event_date, start_time, end_time, description, color, assignment_id
    ]);

    const newEvent = queryOne(db, "SELECT * FROM Calendar_Events WHERE id = ?", [lastInsertRowid]);
    res.status(201).json({ success: true, data: newEvent, message: 'Event scheduled!' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to create calendar event' });
  }
});

router.put('/calendar/:id', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { id } = req.params;
    const existing = queryOne(db, "SELECT * FROM Calendar_Events WHERE id = ? AND user_id = ?", [id, userId]);
    if (!existing) return res.status(404).json({ success: false, error: 'Event not found' });

    const {
      title = existing.title,
      event_type = existing.event_type,
      subject = existing.subject,
      event_date = existing.event_date,
      start_time = existing.start_time,
      end_time = existing.end_time,
      description = existing.description,
      color = existing.color
    } = req.body;

    execRun(db, `UPDATE Calendar_Events SET 
      title = ?, event_type = ?, subject = ?, event_date = ?, start_time = ?, end_time = ?, description = ?, color = ?
      WHERE id = ? AND user_id = ?`, [
      title, event_type, subject, event_date, start_time, end_time, description, color, id, userId
    ]);

    const updated = queryOne(db, "SELECT * FROM Calendar_Events WHERE id = ?", [id]);
    res.json({ success: true, data: updated, message: 'Event updated!' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to update event' });
  }
});

router.delete('/calendar/:id', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { id } = req.params;
    execRun(db, "DELETE FROM Calendar_Events WHERE id = ? AND user_id = ?", [id, userId]);
    res.json({ success: true, message: 'Event removed' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to delete event' });
  }
});

// 6. STUDY PLANNER ENDPOINTS
router.get('/study-planner', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const rows = queryAll(db, "SELECT * FROM Study_Plans WHERE user_id = ? ORDER BY id DESC", [userId]);
    const plans = rows.map(r => ({
      ...r,
      subjects_included: r.subjects_included ? JSON.parse(r.subjects_included) : [],
      daily_hours: Number(r.daily_hours || 2),
      schedule_json: r.schedule_json ? JSON.parse(r.schedule_json) : [],
      ai_generated: Boolean(r.ai_generated)
    }));
    res.json({ success: true, data: plans });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch study plans' });
  }
});

router.post('/study-planner', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const {
      title = 'AI Customized Study Plan',
      plan_type = 'Daily Study Plan',
      target_date = new Date().toISOString().split('T')[0],
      subjects = ['Mathematics', 'Physical Science', 'English First Language'],
      daily_hours = 2.0
    } = req.body;

    // Generate intelligent schedule based on assignments and subjects
    const assignments = queryAll(db, "SELECT * FROM Assignments WHERE user_id = ? AND status != 'Completed'", [userId]);
    let schedule: any[] = [];

    if (plan_type === 'Daily Study Plan' || plan_type === 'Revision Schedule') {
      const tasks = subjects.map((sub: string, idx: number) => {
        const relatedAss = assignments.find(a => a.subject === sub);
        return {
          id: `task-${idx}-${Date.now()}`,
          subject: sub,
          topic: relatedAss ? `Work on: ${relatedAss.title}` : `${sub} Core Syllabus Revision & Past Papers`,
          duration: `${Math.round((daily_hours * 60) / subjects.length)}m`,
          completed: false,
          timeSlot: idx === 0 ? '15:00 - 15:45' : idx === 1 ? '16:00 - 16:45' : '17:00 - 17:30'
        };
      });
      schedule = [{ day: 'Today', date: target_date, tasks }];
    } else {
      // Weekly or Exam Plan
      const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      schedule = days.map((dayName, dIdx) => {
        const daySubjects = subjects.slice(dIdx % subjects.length, (dIdx % subjects.length) + 2);
        if (daySubjects.length === 0) daySubjects.push(subjects[0] || 'General Revision');
        const tasks = daySubjects.map((sub: string, tIdx: number) => ({
          id: `task-${dIdx}-${tIdx}-${Date.now()}`,
          subject: sub,
          topic: `${sub} Level ${dIdx + 1} Practice Exercises & Exam Techniques`,
          duration: '60m',
          completed: false
        }));
        return { day: dayName, tasks };
      });
    }

    const { lastInsertRowid } = execRun(db, `INSERT INTO Study_Plans (
      user_id, title, plan_type, target_date, subjects_included, daily_hours, schedule_json, ai_generated
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 1)`, [
      userId, title, plan_type, target_date, JSON.stringify(subjects), daily_hours, JSON.stringify(schedule)
    ]);

    const newPlan = queryOne(db, "SELECT * FROM Study_Plans WHERE id = ?", [lastInsertRowid]);
    res.status(201).json({
      success: true,
      data: {
        ...newPlan,
        subjects_included: JSON.parse(newPlan.subjects_included),
        daily_hours: Number(newPlan.daily_hours),
        schedule_json: JSON.parse(newPlan.schedule_json),
        ai_generated: Boolean(newPlan.ai_generated)
      },
      message: 'AI Study Plan generated successfully!'
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to generate study plan' });
  }
});

router.put('/study-planner/:id', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { id } = req.params;
    const { schedule_json, title, daily_hours } = req.body;

    const existing = queryOne(db, "SELECT * FROM Study_Plans WHERE id = ? AND user_id = ?", [id, userId]);
    if (!existing) return res.status(404).json({ success: false, error: 'Plan not found' });

    execRun(db, "UPDATE Study_Plans SET schedule_json = ?, title = ?, daily_hours = ? WHERE id = ? AND user_id = ?", [
      typeof schedule_json === 'string' ? schedule_json : JSON.stringify(schedule_json || JSON.parse(existing.schedule_json)),
      title || existing.title,
      daily_hours || existing.daily_hours,
      id,
      userId
    ]);

    const updated = queryOne(db, "SELECT * FROM Study_Plans WHERE id = ?", [id]);
    res.json({
      success: true,
      data: {
        ...updated,
        subjects_included: JSON.parse(updated.subjects_included),
        daily_hours: Number(updated.daily_hours),
        schedule_json: JSON.parse(updated.schedule_json),
        ai_generated: Boolean(updated.ai_generated)
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to update study plan' });
  }
});

router.delete('/study-planner/:id', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { id } = req.params;
    execRun(db, "DELETE FROM Study_Plans WHERE id = ? AND user_id = ?", [id, userId]);
    res.json({ success: true, message: 'Study plan deleted' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to delete study plan' });
  }
});

// 7. STUDY SESSIONS ENDPOINTS (Focus Mode & Pomodoro)
router.get('/study-sessions', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const sessions = queryAll(db, "SELECT * FROM Study_Sessions WHERE user_id = ? ORDER BY id DESC LIMIT 50", [userId]);
    res.json({ success: true, data: sessions });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch study sessions' });
  }
});

router.post('/study-sessions', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const {
      assignment_id = null,
      title = 'Focus Session',
      subject = 'Mathematics',
      duration_minutes = 25,
      time_spent_seconds = 0,
      mode = 'pomodoro',
      status = 'completed'
    } = req.body;

    const xp_earned = Math.max(20, Math.round((duration_minutes / 10) * 25));

    const { lastInsertRowid } = execRun(db, `INSERT INTO Study_Sessions (
      user_id, assignment_id, title, subject, duration_minutes, time_spent_seconds, mode, status, xp_earned, completed_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`, [
      userId, assignment_id, title, subject, duration_minutes, time_spent_seconds || duration_minutes * 60, mode, status, xp_earned
    ]);

    // Update streak hours studied and xp total
    const hoursAdded = Number((duration_minutes / 60).toFixed(2));
    execRun(db, "UPDATE Learning_Streaks SET hours_studied = hours_studied + ?, xp_total = xp_total + ?, last_activity_date = DATE('now') WHERE user_id = ?", [
      hoursAdded, xp_earned, userId
    ]);

    // Also update Phase 3 Learning_Streak table so both stay in sync
    execRun(db, "UPDATE Learning_Streak SET xp_total = xp_total + ?, last_activity_date = DATE('now') WHERE user_id = ?", [
      xp_earned, userId
    ]);

    // Add recent activity
    execRun(db, "INSERT INTO Recent_Activity (user_id, activity_type, title, subtitle, xp_earned) VALUES (?, 'session', ?, ?, ?)", [
      userId, `Completed ${mode.toUpperCase()} Study Session`, `${duration_minutes}m focused on ${subject}: ${title}`, xp_earned
    ]);

    const newSession = queryOne(db, "SELECT * FROM Study_Sessions WHERE id = ?", [lastInsertRowid]);
    res.status(201).json({ success: true, data: newSession, xpEarned: xp_earned, message: `Session saved! +${xp_earned} XP earned! 🎉` });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to record study session' });
  }
});

// 8. STUDENT GOALS ENDPOINTS
router.get('/goals', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const goals = queryAll(db, "SELECT * FROM Student_Goals WHERE user_id = ? ORDER BY is_completed ASC, id DESC", [userId]).map(g => ({
      ...g,
      is_completed: Boolean(g.is_completed)
    }));
    res.json({ success: true, data: goals });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch student goals' });
  }
});

router.post('/goals', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { title, goal_type = 'Daily Goal', target_value = 1, target_date = new Date().toISOString().split('T')[0] } = req.body;
    if (!title) return res.status(400).json({ success: false, error: 'Goal title required' });

    const { lastInsertRowid } = execRun(db, "INSERT INTO Student_Goals (user_id, title, goal_type, target_value, current_value, is_completed, target_date) VALUES (?, ?, ?, ?, 0, 0, ?)", [
      userId, title, goal_type, target_value, target_date
    ]);
    const newGoal = queryOne(db, "SELECT * FROM Student_Goals WHERE id = ?", [lastInsertRowid]);
    res.status(201).json({ success: true, data: { ...newGoal, is_completed: false }, message: 'Goal set!' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to set goal' });
  }
});

router.put('/goals/:id', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { id } = req.params;
    const existing = queryOne(db, "SELECT * FROM Student_Goals WHERE id = ? AND user_id = ?", [id, userId]);
    if (!existing) return res.status(404).json({ success: false, error: 'Goal not found' });

    const is_completed = req.body.is_completed !== undefined ? (req.body.is_completed ? 1 : 0) : (existing.is_completed ? 0 : 1);
    const current_value = req.body.current_value !== undefined ? req.body.current_value : (is_completed ? existing.target_value : existing.current_value);

    execRun(db, "UPDATE Student_Goals SET is_completed = ?, current_value = ? WHERE id = ? AND user_id = ?", [
      is_completed, current_value, id, userId
    ]);

    if (is_completed && !existing.is_completed) {
      execRun(db, "UPDATE Learning_Streaks SET goals_achieved = goals_achieved + 1, xp_total = xp_total + 150 WHERE user_id = ?", [userId]);
      execRun(db, "INSERT INTO Recent_Activity (user_id, activity_type, title, subtitle, xp_earned) VALUES (?, 'goal', ?, ?, 150)", [
        userId, 'Achieved Goal', `${existing.goal_type}: ${existing.title}`, 150
      ]);
    }

    const updated = queryOne(db, "SELECT * FROM Student_Goals WHERE id = ?", [id]);
    res.json({ success: true, data: { ...updated, is_completed: Boolean(updated.is_completed) }, message: is_completed ? 'Goal Achieved! +150 XP! 🏆' : 'Goal updated' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to update goal' });
  }
});

router.delete('/goals/:id', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const { id } = req.params;
    execRun(db, "DELETE FROM Student_Goals WHERE id = ? AND user_id = ?", [id, userId]);
    res.json({ success: true, message: 'Goal removed' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to delete goal' });
  }
});

// 9. STREAKS & STATS ENDPOINT
router.get('/streaks', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    let row = queryOne(db, "SELECT * FROM Learning_Streaks WHERE user_id = ?", [userId]);
    if (!row) {
      execRun(db, "INSERT OR IGNORE INTO Learning_Streaks (user_id, consecutive_days, assignments_completed, hours_studied, goals_achieved, xp_total) VALUES (?, 7, 15, 42.5, 8, 2450)", [userId]);
      row = queryOne(db, "SELECT * FROM Learning_Streaks WHERE user_id = ?", [userId]);
    }
    res.json({
      success: true,
      data: {
        consecutiveDays: Number(row?.consecutive_days || 7),
        assignmentsCompleted: Number(row?.assignments_completed || 15),
        hoursStudied: Number((row?.hours_studied || 42.5).toFixed(1)),
        goalsAchieved: Number(row?.goals_achieved || 8),
        xpTotal: Number(row?.xp_total || 2450)
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch streaks data' });
  }
});

// 10. REMINDER SETTINGS ENDPOINTS
router.get('/reminders', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    let row = queryOne(db, "SELECT * FROM Reminder_Settings WHERE user_id = ?", [userId]);
    if (!row) {
      execRun(db, "INSERT OR IGNORE INTO Reminder_Settings (user_id) VALUES (?)", [userId]);
      row = queryOne(db, "SELECT * FROM Reminder_Settings WHERE user_id = ?", [userId]);
    }
    res.json({
      success: true,
      data: {
        ...row,
        upcoming_assignment: Boolean(row.upcoming_assignment),
        tomorrow_deadline: Boolean(row.tomorrow_deadline),
        today_study_plan: Boolean(row.today_study_plan),
        study_reminder: Boolean(row.study_reminder),
        goal_reminder: Boolean(row.goal_reminder),
        exam_reminder: Boolean(row.exam_reminder)
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch reminders' });
  }
});

router.put('/reminders', async (req: AuthRequest, res) => {
  try {
    const db = await getDb();
    const userId = req.user?.id || 1;
    const {
      upcoming_assignment = true,
      tomorrow_deadline = true,
      today_study_plan = true,
      study_reminder = true,
      goal_reminder = true,
      exam_reminder = true,
      reminder_time = '18:00'
    } = req.body;

    execRun(db, `UPDATE Reminder_Settings SET 
      upcoming_assignment = ?, tomorrow_deadline = ?, today_study_plan = ?, study_reminder = ?, goal_reminder = ?, exam_reminder = ?, reminder_time = ?
      WHERE user_id = ?`, [
      upcoming_assignment ? 1 : 0, tomorrow_deadline ? 1 : 0, today_study_plan ? 1 : 0, study_reminder ? 1 : 0, goal_reminder ? 1 : 0, exam_reminder ? 1 : 0, reminder_time, userId
    ]);

    const updated = queryOne(db, "SELECT * FROM Reminder_Settings WHERE user_id = ?", [userId]);
    res.json({
      success: true,
      data: {
        ...updated,
        upcoming_assignment: Boolean(updated.upcoming_assignment),
        tomorrow_deadline: Boolean(updated.tomorrow_deadline),
        today_study_plan: Boolean(updated.today_study_plan),
        study_reminder: Boolean(updated.study_reminder),
        goal_reminder: Boolean(updated.goal_reminder),
        exam_reminder: Boolean(updated.exam_reminder)
      },
      message: 'Reminder preferences updated!'
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to update reminders' });
  }
});

// Mount Phase 5 Edu Buddy AI Experience routes
router.use('/edubuddy', edubuddyRouter);

export default router;

