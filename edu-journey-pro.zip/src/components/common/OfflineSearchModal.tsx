import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search,
  X,
  BookOpen,
  WifiOff,
  CheckCircle2,
  FileText,
  HelpCircle,
  Sparkles,
  ArrowRight,
  Filter,
  Zap,
  Bookmark,
  BookMarked,
  Check,
  ChevronRight,
  Download
} from 'lucide-react';
import {
  searchOfflineCurriculum,
  SearchResultItem,
  getDownloadedPackageIds,
  getCachedPackageContent,
  saveOfflineNote,
  ESSENTIAL_CURRICULUM_PACKAGES,
  CurriculumTopic,
  CurriculumSubjectPackage
} from '../../lib/offlineStorage.js';
import { useAccessibility } from '../../context/AccessibilityContext.js';

interface OfflineSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
  onStartQuizForSubject?: (subjectId: string) => void;
}

export const OfflineSearchModal: React.FC<OfflineSearchModalProps> = ({
  isOpen,
  onClose,
  initialQuery = '',
  onStartQuizForSubject
}) => {
  const { isHighContrast } = useAccessibility();

  const [query, setQuery] = useState<string>(initialQuery);
  const [onlyDownloaded, setOnlyDownloaded] = useState<boolean>(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [results, setResults] = useState<SearchResultItem[]>([]);
  const [downloadedIds, setDownloadedIds] = useState<string[]>([]);

  // Selected result inspection modal/drawer
  const [activeTopicPackage, setActiveTopicPackage] = useState<{
    pkg: CurriculumSubjectPackage;
    topic: CurriculumTopic;
  } | null>(null);

  const [savedNoteSuccess, setSavedNoteSuccess] = useState<boolean>(false);

  // Sync state on open
  useEffect(() => {
    if (isOpen) {
      setDownloadedIds(getDownloadedPackageIds());
      if (initialQuery) {
        setQuery(initialQuery);
      }
    }
  }, [isOpen, initialQuery]);

  // Execute search whenever query or filters change
  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }

    const matchedResults = searchOfflineCurriculum(query, {
      onlyDownloaded,
      categoryFilter: selectedCategory,
    });

    setResults(matchedResults);
  }, [query, onlyDownloaded, selectedCategory]);

  if (!isOpen) return null;

  const categories = ['All', 'Mathematics', 'Sciences', 'Languages', 'Humanities', 'Notes'];

  // Open topic viewer from result
  const handleSelectResult = (item: SearchResultItem) => {
    if (item.type === 'note') return; // Handled inline if note

    const pkg = ESSENTIAL_CURRICULUM_PACKAGES.find((p) => p.id === item.packageId);
    if (pkg) {
      const topic = pkg.topics.find((t) => t.id === item.topicId) || pkg.topics[0];
      if (topic) {
        setActiveTopicPackage({ pkg, topic });
      }
    }
  };

  // Save current topic to student's offline notes
  const handleSaveTopicToNotes = () => {
    if (!activeTopicPackage) return;
    const { pkg, topic } = activeTopicPackage;

    let noteText = `Syllabus: ${pkg.subjectName} (${pkg.code} - ${pkg.grade})\nTopic: ${topic.title}\n\nSummary:\n${topic.summary}\n\nKey Concepts:\n`;
    topic.keyConcepts.forEach((kc) => {
      noteText += `• ${kc}\n`;
    });

    if (topic.sampleQuestions.length > 0) {
      noteText += `\nSample Past Paper Questions:\n`;
      topic.sampleQuestions.forEach((sq, i) => {
        noteText += `Q${i + 1}: ${sq.question}\nAnswer: ${sq.answer}\n\n`;
      });
    }

    saveOfflineNote({
      subjectId: pkg.id,
      title: `${topic.title} Notes`,
      content: noteText,
    });

    setSavedNoteSuccess(true);
    setTimeout(() => setSavedNoteSuccess(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className={`w-full max-w-3xl rounded-3xl overflow-hidden shadow-2xl border ${
          isHighContrast
            ? 'bg-black text-amber-300 border-amber-400'
            : 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white border-slate-200 dark:border-slate-800'
        } my-auto flex flex-col max-h-[90vh]`}
      >
        {/* Modal Top Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0 bg-slate-50/80 dark:bg-slate-950/80 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center font-black shadow-md shadow-emerald-500/20">
              <Search className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-sm sm:text-base">Offline Local Curriculum Search</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                  <WifiOff className="w-3 h-3" />
                  Local Index
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Instant keyword search across NSSCO topics, key concepts, past papers, and notes
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Input & Filters Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 space-y-3 shrink-0">
          <div className="relative">
            <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-emerald-500" />
            <input
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search equations, Newton's laws, summary rules, independence, photosynthesis..."
              className="w-full pl-11 pr-10 py-3 rounded-2xl border-2 border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-extrabold text-sm sm:text-base focus:outline-none focus:border-emerald-500 shadow-inner"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Filter Row */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
            {/* Category Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition whitespace-nowrap ${
                    selectedCategory === cat
                      ? 'bg-emerald-500 text-white border-emerald-500 shadow-sm'
                      : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Toggle Cached Only */}
            <label className="flex items-center gap-2 cursor-pointer text-slate-600 dark:text-slate-300 font-bold select-none shrink-0">
              <input
                type="checkbox"
                checked={onlyDownloaded}
                onChange={(e) => setOnlyDownloaded(e.target.checked)}
                className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300"
              />
              <span>Downloaded Only ({downloadedIds.length} Cached)</span>
            </label>
          </div>
        </div>

        {/* Results Container */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-3">
          {query.trim().length === 0 ? (
            <div className="py-12 text-center space-y-3">
              <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
                <Search className="w-8 h-8" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm sm:text-base">Type a Keyword to Search Offline</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mt-1">
                  Try searching for <button onClick={() => setQuery('Newton')} className="text-emerald-500 font-bold hover:underline">"Newton"</button>, <button onClick={() => setQuery('Photosynthesis')} className="text-emerald-500 font-bold hover:underline">"Photosynthesis"</button>, <button onClick={() => setQuery('Quadratic')} className="text-emerald-500 font-bold hover:underline">"Quadratic"</button>, or <button onClick={() => setQuery('Resolution 435')} className="text-emerald-500 font-bold hover:underline">"Resolution 435"</button>.
                </p>
              </div>
            </div>
          ) : results.length === 0 ? (
            <div className="py-12 text-center space-y-2">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center">
                <Search className="w-6 h-6" />
              </div>
              <h4 className="font-extrabold text-sm">No local matches found for "{query}"</h4>
              <p className="text-xs text-slate-500">
                Try checking spelling or unchecking "Downloaded Only" to view all available syllabus modules.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-extrabold text-slate-500 dark:text-slate-400 px-1">
                <span>Found {results.length} local curriculum matches</span>
                <span>Sorted by Relevance</span>
              </div>

              {results.map((item) => (
                <div
                  key={item.id}
                  onClick={() => handleSelectResult(item)}
                  className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-emerald-50/70 dark:hover:bg-emerald-950/40 border border-slate-200 dark:border-slate-700/60 hover:border-emerald-500/40 transition cursor-pointer space-y-2 group"
                >
                  {/* Top Badge Info */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                        {item.subjectName}
                      </span>
                      <span className="text-[10px] font-extrabold text-slate-400 bg-slate-200 dark:bg-slate-700 px-2 py-0.5 rounded-full">
                        Matched: {item.matchedField}
                      </span>
                    </div>

                    {item.isDownloaded ? (
                      <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Cached Offline</span>
                      </span>
                    ) : (
                      <span className="text-[10px] font-medium text-slate-400">Available to Download</span>
                    )}
                  </div>

                  {/* Title & Snippet */}
                  <div>
                    <h4 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors flex items-center justify-between">
                      <span>{item.title}</span>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-500 transform group-hover:translate-x-1 transition-transform" />
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                      {item.snippet}
                    </p>
                  </div>

                  {/* Question / Note Detail Preview if available */}
                  {item.sampleQuestion && (
                    <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-900 dark:text-amber-300 font-medium">
                      <strong>Solution Preview:</strong> {item.sampleQuestion.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* TOPIC INSPECTOR MODAL */}
        <AnimatePresence>
          {activeTopicPackage && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="p-5 sm:p-6 bg-slate-100 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 space-y-4 max-h-[70vh] overflow-y-auto shrink-0 shadow-2xl"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black uppercase text-emerald-600 dark:text-emerald-400">
                      {activeTopicPackage.pkg.subjectName} ({activeTopicPackage.pkg.code})
                    </span>
                  </div>
                  <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                    {activeTopicPackage.topic.title}
                  </h3>
                </div>

                <button
                  onClick={() => setActiveTopicPackage(null)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Summary */}
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 text-xs">
                <div className="font-extrabold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-emerald-500" />
                  <span>Topic Summary</span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  {activeTopicPackage.topic.summary}
                </p>
              </div>

              {/* Key Concepts */}
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 text-xs">
                <div className="font-extrabold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>Key Concepts & Core Rules</span>
                </div>
                <ul className="space-y-1.5 text-slate-600 dark:text-slate-300">
                  {activeTopicPackage.topic.keyConcepts.map((kc, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                      <span>{kc}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Sample Questions */}
              {activeTopicPackage.topic.sampleQuestions.length > 0 && (
                <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 text-xs">
                  <div className="font-extrabold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                    <HelpCircle className="w-4 h-4 text-blue-500" />
                    <span>Sample Past Paper Question & Solution</span>
                  </div>
                  {activeTopicPackage.topic.sampleQuestions.map((sq, i) => (
                    <div key={i} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 space-y-1.5">
                      <div className="font-bold text-slate-900 dark:text-white">Q: {sq.question}</div>
                      <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-900 dark:text-emerald-300 font-medium">
                        <strong>Solution:</strong> {sq.answer}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Footer Actions */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                <button
                  onClick={handleSaveTopicToNotes}
                  className={`px-4 py-2.5 rounded-2xl border text-xs font-extrabold transition flex items-center gap-2 ${
                    savedNoteSuccess
                      ? 'bg-emerald-500 text-white border-emerald-500'
                      : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Bookmark className="w-4 h-4" />
                  <span>{savedNoteSuccess ? '✓ Saved to Notes!' : 'Save Topic to Offline Notes'}</span>
                </button>

                {onStartQuizForSubject && (
                  <button
                    onClick={() => {
                      onStartQuizForSubject(activeTopicPackage.pkg.id);
                      setActiveTopicPackage(null);
                      onClose();
                    }}
                    className="px-5 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs flex items-center gap-2 shadow-md transition"
                  >
                    <Zap className="w-4 h-4 fill-slate-950" />
                    <span>Take Practice Quiz ({activeTopicPackage.pkg.subjectName})</span>
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </motion.div>
    </div>
  );
};
