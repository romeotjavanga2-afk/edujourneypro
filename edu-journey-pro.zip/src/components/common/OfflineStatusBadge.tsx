import React, { useState, useEffect } from 'react';
import { Wifi, WifiOff, HardDrive, Download } from 'lucide-react';
import { getDownloadedPackageIds } from '../../lib/offlineStorage.js';

interface OfflineStatusBadgeProps {
  onOpenOfflineHub: () => void;
  compact?: boolean;
}

export const OfflineStatusBadge: React.FC<OfflineStatusBadgeProps> = ({ onOpenOfflineHub, compact = false }) => {
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [downloadedCount, setDownloadedCount] = useState<number>(0);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    setDownloadedCount(getDownloadedPackageIds().length);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (compact) {
    return (
      <button
        onClick={onOpenOfflineHub}
        className={`p-2 rounded-xl flex items-center justify-center transition ${
          isOnline
            ? 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200'
            : 'bg-amber-500/20 text-amber-500 border border-amber-500/30 animate-pulse'
        }`}
        title={isOnline ? 'Offline Curriculum Hub (Cached Materials)' : 'Offline Mode Active - Unstable Connection'}
      >
        {isOnline ? <HardDrive className="w-4 h-4 text-emerald-500" /> : <WifiOff className="w-4 h-4 text-amber-500" />}
      </button>
    );
  }

  return (
    <button
      onClick={onOpenOfflineHub}
      className={`px-3 py-1.5 rounded-full text-xs font-extrabold flex items-center gap-2 border transition shadow-sm ${
        isOnline
          ? 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border-emerald-500/30'
          : 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-700 dark:text-amber-300 border-amber-500/40 animate-pulse'
      }`}
    >
      {isOnline ? (
        <>
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          <HardDrive className="w-3.5 h-3.5 text-emerald-500" />
          <span>Offline Ready ({downloadedCount} Cached)</span>
        </>
      ) : (
        <>
          <WifiOff className="w-3.5 h-3.5 text-amber-500" />
          <span>Offline Mode ({downloadedCount} Subjects)</span>
        </>
      )}
    </button>
  );
};
