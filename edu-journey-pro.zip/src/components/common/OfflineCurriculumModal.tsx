import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Wifi,
  WifiOff,
  Download,
  CheckCircle2,
  Trash2,
  BookOpen,
  HardDrive,
  Sparkles,
  Search,
  X,
  FileText,
  ChevronRight,
  RefreshCw,
  Plus,
  Save,
  Check,
  Zap,
  Globe,
  AlertTriangle,
  FolderDown
} from 'lucide-react';
import {
  ESSENTIAL_CURRICULUM_PACKAGES,
  CurriculumSubjectPackage,
  getDownloadedPackageIds,
  cacheSubjectPackage,
  removeCachedSubjectPackage,
  getCachedPackageContent,
  getOfflineStorageStatsMB,
  clearAllOfflineCache,
  saveOfflineNote,
  getOfflineNotes,
  OfflineNote,
  searchOfflineCurriculum,
  SearchResultItem
} from '../../lib/offlineStorage.js';
import { OfflinePracticeQuizModal } from '../quiz/OfflinePracticeQuizModal.js';
import { OfflineSearchModal } from './OfflineSearchModal.js';

interface OfflineCurriculumModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const OfflineCurriculumModal: React.FC<OfflineCurriculumModalProps> = ({ isOpen, onClose }) => {
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [downloadedIds, setDownloadedIds] = useState<string[]>([]);
  const [selectedPackage, setSelectedPackage] = useState<CurriculumSubjectPackage | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [downloadProgress, setDownloadProgress] = useState<number>(0);

  // Offline Notes state
  const [notes, setNotes] = useState<OfflineNote[]>([]);
  const [newNoteTitle, setNewNoteTitle] = useState<string>('');
  const [newNoteContent, setNewNoteContent] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'materials' | 'notes' | 'status'>('materials');

  // Quiz & Search Modal state
  const [isQuizOpen, setIsQuizOpen] = useState<boolean>(false);
  const [quizSubjectId, setQuizSubjectId] = useState<string>('All');
  const [isSearchModalOpen, setIsSearchModalOpen] = useState<boolean>(false);

  // Network listener
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial sync
    setDownloadedIds(getDownloadedPackageIds());
    setNotes(getOfflineNotes());

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (!isOpen) return null;

  const storageStats = getOfflineStorageStatsMB();

  const handleDownloadPackage = async (packageId: string) => {
    setDownloadingId(packageId);
    setDownloadProgress(20);

    const interval = setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev >= 90) {
          clearInterval(interval);
          return 90;
        }
        return prev + 25;
      });
    }, 250);

    setTimeout(async () => {
      clearInterval(interval);
      await cacheSubjectPackage(packageId);
      setDownloadedIds(getDownloadedPackageIds());
      setDownloadingId(null);
      setDownloadProgress(0);
    }, 1200);
  };

  const handleDownloadAll = async () => {
    setDownloadingId('all');
    setDownloadProgress(10);

    for (let i = 0; i < ESSENTIAL_CURRICULUM_PACKAGES.length; i++) {
      const pkg = ESSENTIAL_CURRICULUM_PACKAGES[i];
      setDownloadProgress(Math.round(((i + 1) / ESSENTIAL_CURRICULUM_PACKAGES.length) * 100));
      await cacheSubjectPackage(pkg.id);
    }

    setDownloadedIds(getDownloadedPackageIds());
    setDownloadingId(null);
    setDownloadProgress(0);
  };

  const handleRemovePackage = (packageId: string) => {
    removeCachedSubjectPackage(packageId);
    setDownloadedIds(getDownloadedPackageIds());
    if (selectedPackage?.id === packageId) {
      setSelectedPackage(null);
    }
  };

  const handleClearAll = () => {
    if (confirm('Are you sure you want to clear all offline cached curriculum materials?')) {
      clearAllOfflineCache();
      setDownloadedIds([]);
      setSelectedPackage(null);
    }
  };

  const handleCreateNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteTitle.trim() || !newNoteContent.trim()) return;

    saveOfflineNote({
      subjectId: selectedPackage?.id || 'general',
      title: newNoteTitle.trim(),
      content: newNoteContent.trim(),
    });

    setNotes(getOfflineNotes());
    setNewNoteTitle('');
    setNewNoteContent('');
  };

  const categories = ['All', 'Sciences', 'Mathematics', 'Languages', 'Humanities'];

  const filteredPackages = ESSENTIAL_CURRICULUM_PACKAGES.filter((pkg) => {
    const matchesCategory = activeCategory === 'All' || pkg.category === activeCategory;
    const matchesQuery =
      pkg.subjectName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pkg.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pkg.code.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesQuery;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.96 }}
        className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-5xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Top Header & Connectivity Status Ribbon */}
        <div className="p-4 sm:p-6 bg-slate-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400">
              <HardDrive className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-extrabold text-white">Offline Curriculum Hub</h2>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  NSSCO & NSSCH 🇳🇦
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300">
                Cache essential Grade 10–12 study materials, past exam guides & notes for unstable internet areas.
              </p>
            </div>
          </div>

          {/* Network Connection Badge */}
          <div className="flex items-center gap-3 shrink-0">
            <div
              className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold border ${
                isOnline
                  ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                  : 'bg-amber-500/15 border-amber-500/30 text-amber-300 animate-pulse'
              }`}
            >
              {isOnline ? (
                <>
                  <Wifi className="w-4 h-4 text-emerald-400" />
                  <span>Online (Connected)</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-4 h-4 text-amber-400" />
                  <span>Offline Mode Active</span>
                </>
              )}
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Storage Bar & Global Actions */}
        <div className="bg-slate-50 dark:bg-slate-900/50 p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs shrink-0">
          <div className="flex items-center gap-4 flex-1 min-w-[280px]">
            <div className="space-y-1 flex-1">
              <div className="flex items-center justify-between font-semibold text-slate-700 dark:text-slate-300">
                <span>Offline Storage Used</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-extrabold">
                  {storageStats.totalContentMB} MB ({downloadedIds.length} / {ESSENTIAL_CURRICULUM_PACKAGES.length} Subjects Cached)
                </span>
              </div>
              <div className="h-2 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-300"
                  style={{
                    width: `${Math.min(100, (storageStats.totalContentMB / 25) * 100)}%`,
                  }}
                />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setQuizSubjectId('All');
                setIsQuizOpen(true);
              }}
              className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 shadow-sm transition"
            >
              <Zap className="w-3.5 h-3.5 fill-slate-950" />
              <span>Take Offline Practice Quiz</span>
            </button>

            <button
              onClick={handleDownloadAll}
              disabled={downloadingId !== null || downloadedIds.length === ESSENTIAL_CURRICULUM_PACKAGES.length}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition"
            >
              {downloadingId === 'all' ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Downloading ({downloadProgress}%)...</span>
                </>
              ) : (
                <>
                  <FolderDown className="w-3.5 h-3.5" />
                  <span>Download All ({ESSENTIAL_CURRICULUM_PACKAGES.length} Subjects)</span>
                </>
              )}
            </button>

            {downloadedIds.length > 0 && (
              <button
                onClick={handleClearAll}
                className="px-3 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-red-500/10 hover:text-red-500 text-slate-700 dark:text-slate-300 font-bold text-xs flex items-center gap-1.5 transition"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear Storage</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 shrink-0">
          <button
            onClick={() => setActiveTab('materials')}
            className={`px-4 py-3 font-bold text-sm border-b-2 flex items-center gap-2 transition ${
              activeTab === 'materials'
                ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Curriculum Packages ({ESSENTIAL_CURRICULUM_PACKAGES.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('notes')}
            className={`px-4 py-3 font-bold text-sm border-b-2 flex items-center gap-2 transition ${
              activeTab === 'notes'
                ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Offline Scratchpad & Notes ({notes.length})</span>
          </button>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-100/50 dark:bg-slate-950/50 space-y-6">
          {activeTab === 'materials' && (
            <>
              {/* Filter Controls */}
              <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
                <div className="flex items-center gap-2 w-full sm:w-auto flex-1">
                  <div className="relative w-full sm:w-80">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search offline topics, Newton, equations, summary..."
                      className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                    />
                  </div>

                  <button
                    onClick={() => setIsSearchModalOpen(true)}
                    className="px-3 py-2 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/20 text-xs font-extrabold shrink-0 transition flex items-center gap-1"
                  >
                    <Search className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Advanced Search</span>
                  </button>
                </div>

                <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setActiveCategory(cat)}
                      className={`px-3 py-1.5 rounded-full text-xs font-bold transition whitespace-nowrap ${
                        activeCategory === cat
                          ? 'bg-slate-900 text-white dark:bg-emerald-500 dark:text-slate-950 shadow-sm'
                          : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Instant Local Search Match Banner if user is searching */}
              {searchQuery.trim().length > 0 && (() => {
                const searchResults = searchOfflineCurriculum(searchQuery, { categoryFilter: activeCategory });
                return searchResults.length > 0 ? (
                  <div className="p-4 rounded-2xl bg-slate-900 text-white border border-emerald-500/30 space-y-3 shadow-lg">
                    <div className="flex items-center justify-between text-xs font-extrabold border-b border-slate-800 pb-2">
                      <span className="flex items-center gap-1.5 text-emerald-400">
                        <Sparkles className="w-4 h-4" />
                        <span>Matched {searchResults.length} Local Topics & Concept Notes for "{searchQuery}"</span>
                      </span>
                      <button
                        onClick={() => setIsSearchModalOpen(true)}
                        className="text-[11px] text-amber-400 hover:underline"
                      >
                        Expand All Results →
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1">
                      {searchResults.slice(0, 4).map((res) => (
                        <div
                          key={res.id}
                          onClick={() => {
                            const matchedPkg = ESSENTIAL_CURRICULUM_PACKAGES.find((p) => p.id === res.packageId);
                            if (matchedPkg) setSelectedPackage(matchedPkg);
                          }}
                          className="p-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 cursor-pointer text-xs space-y-1 transition group"
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-black text-emerald-400 uppercase">{res.subjectName}</span>
                            <span className="text-[9px] font-bold text-slate-400 bg-slate-900 px-1.5 py-0.5 rounded">{res.matchedField}</span>
                          </div>
                          <div className="font-extrabold text-white group-hover:text-emerald-300 transition-colors">{res.title}</div>
                          <div className="text-[11px] text-slate-300 line-clamp-2 leading-relaxed">{res.snippet}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : null;
              })()}

              {/* Subject Package Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredPackages.map((pkg) => {
                  const isDownloaded = downloadedIds.includes(pkg.id);
                  const isDownloadingThis = downloadingId === pkg.id;
                  const isSelected = selectedPackage?.id === pkg.id;

                  return (
                    <div
                      key={pkg.id}
                      className={`p-4 rounded-2xl border transition-all duration-200 bg-white dark:bg-slate-900 flex flex-col justify-between space-y-3 ${
                        isSelected
                          ? 'border-emerald-500 ring-2 ring-emerald-500/20 shadow-md'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <div className="space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 uppercase tracking-wider">
                              {pkg.grade} • {pkg.code}
                            </span>
                            <h3 className="text-base font-extrabold text-slate-900 dark:text-white mt-1">
                              {pkg.subjectName}
                            </h3>
                          </div>
                          {isDownloaded ? (
                            <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 shrink-0">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Cached</span>
                            </span>
                          ) : (
                            <span className="text-slate-400 text-xs font-medium shrink-0">
                              {pkg.totalSizeMB} MB
                            </span>
                          )}
                        </div>

                        <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                          {pkg.description}
                        </p>

                        <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 pt-1">
                          <span>{pkg.topics.length} Syllabus Modules</span>
                          <span>•</span>
                          <span>Updated {pkg.lastUpdated}</span>
                        </div>
                      </div>

                      {/* Download / View Actions */}
                      <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between gap-2">
                        {isDownloaded ? (
                          <>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <button
                                onClick={() => setSelectedPackage(isSelected ? null : pkg)}
                                className="px-3 py-1.5 rounded-xl bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-500/25 font-bold text-xs flex items-center gap-1.5 transition"
                              >
                                <BookOpen className="w-3.5 h-3.5" />
                                <span>{isSelected ? 'Close Reader' : 'Read Offline'}</span>
                              </button>

                              <button
                                onClick={() => {
                                  setQuizSubjectId(pkg.id);
                                  setIsQuizOpen(true);
                                }}
                                className="px-3 py-1.5 rounded-xl bg-amber-500/20 text-amber-800 dark:text-amber-300 hover:bg-amber-500/30 font-extrabold text-xs flex items-center gap-1 transition"
                              >
                                <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                                <span>Quiz</span>
                              </button>
                            </div>

                            <button
                              onClick={() => handleRemovePackage(pkg.id)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-500/10 transition"
                              title="Delete from offline storage"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </>
                        ) : (
                          <button
                            onClick={() => handleDownloadPackage(pkg.id)}
                            disabled={isDownloadingThis}
                            className="w-full py-2 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-emerald-600 dark:hover:bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-2 transition"
                          >
                            {isDownloadingThis ? (
                              <>
                                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                                <span>Downloading ({downloadProgress}%)...</span>
                              </>
                            ) : (
                              <>
                                <Download className="w-3.5 h-3.5 text-emerald-400" />
                                <span>Download for Offline Use ({pkg.totalSizeMB} MB)</span>
                              </>
                            )}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Reader View for Selected Package */}
              {selectedPackage && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white dark:bg-slate-900 rounded-2xl border border-emerald-500/40 p-5 shadow-lg space-y-5"
                >
                  <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                    <div className="flex items-center gap-2">
                      <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 font-bold">
                        <BookOpen className="w-5 h-5" />
                      </span>
                      <div>
                        <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
                          Offline Curriculum Reader: {selectedPackage.subjectName} ({selectedPackage.code})
                        </h3>
                        <p className="text-xs text-slate-500">
                          {selectedPackage.grade} • Available fully offline without internet connection
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => setSelectedPackage(null)}
                      className="text-xs font-bold text-slate-400 hover:text-slate-600 dark:hover:text-white"
                    >
                      Close Reader
                    </button>
                  </div>

                  {/* Modules Accordion */}
                  <div className="space-y-4">
                    {selectedPackage.topics.map((topic, idx) => (
                      <div
                        key={topic.id}
                        className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3"
                      >
                        <div className="flex items-center justify-between">
                          <h4 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                            <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs flex items-center justify-center font-bold">
                              {idx + 1}
                            </span>
                            <span>{topic.title}</span>
                          </h4>
                          <span className="text-[11px] font-semibold text-slate-400">
                            {(topic.fileSizeKB / 1024).toFixed(1)} MB
                          </span>
                        </div>

                        <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
                          {topic.summary}
                        </p>

                        <div>
                          <h5 className="text-xs font-bold text-slate-800 dark:text-slate-200 mb-1.5 flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                            <span>Core Syllabus Concepts:</span>
                          </h5>
                          <ul className="list-disc list-inside space-y-1 text-xs text-slate-600 dark:text-slate-400">
                            {topic.keyConcepts.map((concept, i) => (
                              <li key={i}>{concept}</li>
                            ))}
                          </ul>
                        </div>

                        {topic.sampleQuestions.length > 0 && (
                          <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
                            <h5 className="text-xs font-bold text-emerald-600 dark:text-emerald-400 mb-2">
                              NSSCO Exam Practice Question & Solution:
                            </h5>
                            {topic.sampleQuestions.map((q, qIdx) => (
                              <div
                                key={qIdx}
                                className="bg-emerald-50/50 dark:bg-emerald-950/20 p-3 rounded-lg border border-emerald-500/20 space-y-1.5 text-xs"
                              >
                                <p className="font-bold text-slate-900 dark:text-slate-100">
                                  Q: {q.question}
                                </p>
                                <p className="text-emerald-800 dark:text-emerald-300 font-mono">
                                  Solution: {q.answer}
                                </p>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </>
          )}

          {/* Offline Scratchpad Tab */}
          {activeTab === 'notes' && (
            <div className="space-y-6">
              <form onSubmit={handleCreateNote} className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
                <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <Plus className="w-4 h-4 text-emerald-500" />
                  <span>Create Offline Note / Homework Scratchpad</span>
                </h3>
                <input
                  type="text"
                  value={newNoteTitle}
                  onChange={(e) => setNewNoteTitle(e.target.value)}
                  placeholder="Note Title (e.g., Physics Mechanics Equations)"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <textarea
                  value={newNoteContent}
                  onChange={(e) => setNewNoteContent(e.target.value)}
                  placeholder="Write your revision notes or answers here... (saved locally when offline)"
                  rows={3}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Offline Note</span>
                </button>
              </form>

              {/* Saved Notes List */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Saved Offline Notes ({notes.length})
                </h4>
                {notes.length === 0 ? (
                  <div className="p-8 text-center text-xs text-slate-400 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
                    No offline notes saved yet. Write your study notes above!
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {notes.map((note) => (
                      <div
                        key={note.id}
                        className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <h5 className="font-extrabold text-xs text-slate-900 dark:text-white">
                            {note.title}
                          </h5>
                          <span className="text-[10px] text-slate-400">
                            {new Date(note.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 dark:text-slate-300 whitespace-pre-wrap">
                          {note.content}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </motion.div>

      {/* Offline Practice Quiz Modal */}
      <OfflinePracticeQuizModal
        isOpen={isQuizOpen}
        onClose={() => setIsQuizOpen(false)}
        initialSubjectId={quizSubjectId}
      />

      {/* Offline Search Modal */}
      <OfflineSearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        initialQuery={searchQuery}
        onStartQuizForSubject={(subjectId) => {
          setQuizSubjectId(subjectId);
          setIsQuizOpen(true);
        }}
      />
    </div>
  );
};
