import React from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { X, Sparkles, Lock, ArrowRight, CheckCircle2, ShieldCheck, Rocket } from 'lucide-react';

export const FeaturePreviewModal: React.FC = () => {
  const { selectedFeatureForPreview, setSelectedFeatureForPreview, setActiveModal } = useAuth();

  if (!selectedFeatureForPreview) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden text-center space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        
        <button
          onClick={() => setSelectedFeatureForPreview(null)}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-700 via-blue-600 to-emerald-500 flex items-center justify-center text-white mx-auto shadow-lg shadow-blue-900/20">
          <Rocket className="w-8 h-8 text-emerald-300 animate-bounce" />
        </div>

        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 text-xs font-extrabold uppercase tracking-wider">
            <Lock className="w-3.5 h-3.5" />
            <span>Scheduled for Phase 2 Release</span>
          </div>
          <h3 className="text-2xl font-extrabold text-slate-900 dark:text-white font-serif">
            {selectedFeatureForPreview}
          </h3>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-md mx-auto">
            You are viewing the preview specification for <strong className="text-slate-900 dark:text-white">{selectedFeatureForPreview}</strong>. In accordance with project development rules, educational features will launch after Phase 1 architectural approval.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-left space-y-2.5 text-xs">
          <div className="font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            <span>What is included in Phase 1 (Currently Live)?</span>
          </div>
          <ul className="space-y-1.5 text-slate-600 dark:text-slate-300 list-disc list-inside">
            <li>Full-stack Express + SQLite database architecture</li>
            <li>Student registration with Namibian school & subject selection</li>
            <li>Secure authentication flow with rate limiting and scrypt hash</li>
            <li>Live database structure & schema inspector</li>
          </ul>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 pt-2">
          <button
            type="button"
            onClick={() => {
              setSelectedFeatureForPreview(null);
              setActiveModal('register');
            }}
            className="flex-1 py-3.5 rounded-xl bg-gradient-to-r from-blue-800 via-blue-700 to-emerald-600 hover:from-blue-900 hover:to-emerald-700 text-white font-bold text-sm shadow-lg transition-all flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-emerald-300" />
            <span>Register Phase 1 Student</span>
          </button>
          
          <button
            type="button"
            onClick={() => {
              setSelectedFeatureForPreview(null);
              setActiveModal('db-inspector');
            }}
            className="flex-1 py-3.5 rounded-xl bg-slate-100 dark:bg-slate-800 font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-colors text-sm"
          >
            Inspect DB Schema
          </button>
        </div>

      </div>
    </div>
  );
};
