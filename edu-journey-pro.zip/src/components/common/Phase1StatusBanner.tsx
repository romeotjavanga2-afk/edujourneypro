import React from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { Database, ShieldCheck, Sparkles, CheckCircle, ChevronRight } from 'lucide-react';

export const Phase1StatusBanner: React.FC = () => {
  const { setActiveModal, user, login } = useAuth();

  const handleTestOnboarding = () => {
    if (user) {
      setActiveModal('onboarding');
    } else {
      // Auto login demo student and launch onboarding for instant verification!
      fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: 'student@edujourney.na', password: 'Password123!' })
      })
      .then(res => res.json())
      .then(data => {
        if (data.success && data.token && data.user) {
          login(data.token, data.user);
          setActiveModal('onboarding');
        } else {
          setActiveModal('login');
        }
      })
      .catch(() => setActiveModal('login'));
    }
  };

  return (
    <div className="bg-[#0A2540] text-white text-xs py-2.5 px-4 border-b border-emerald-500/30 shadow-md relative z-50">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        
        <div className="flex items-center gap-2">
          <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-400 animate-ping"></span>
          <span className="font-extrabold uppercase tracking-wider text-emerald-300">Phase 2 Live:</span>
          <span className="hidden sm:inline">Complete Student Onboarding & Edu Buddy AI Tutor setup!</span>
          <span className="sm:hidden">Student Onboarding & Edu Buddy AI!</span>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleTestOnboarding}
            className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1 rounded-full font-bold shadow transition-transform active:scale-95"
            title="Launch Phase 2 Onboarding Flow immediately"
          >
            <Sparkles className="w-3.5 h-3.5 animate-spin text-amber-300" style={{ animationDuration: '6s' }} />
            <span>Test Phase 2 Onboarding</span>
          </button>

          <button
            onClick={() => setActiveModal('db-inspector')}
            className="inline-flex items-center gap-1 font-bold text-emerald-300 hover:text-white underline underline-offset-2 transition-colors ml-1"
          >
            <Database className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Inspect DB Schema</span>
            <span className="sm:hidden">DB</span>
          </button>
        </div>

      </div>
    </div>
  );
};
