import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  HelpCircle,
  CheckCircle2,
  XCircle,
  ArrowRight,
  RotateCcw,
  BookOpen,
  Award,
  Zap,
  Clock,
  Sparkles,
  WifiOff,
  Flame,
  Check,
  ChevronRight,
  Brain,
  Download,
  AlertCircle,
  FileText,
  Bookmark,
  Share2,
  X
} from 'lucide-react';
import {
  ESSENTIAL_CURRICULUM_PACKAGES,
  CurriculumSubjectPackage,
  CurriculumTopic,
  getDownloadedPackageIds,
  getCachedPackageContent,
  saveOfflineNote
} from '../../lib/offlineStorage.js';
import { useAccessibility } from '../../context/AccessibilityContext.js';

export interface QuizQuestion {
  id: string;
  topicId: string;
  topicTitle: string;
  subjectName: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  hint?: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

export interface QuizResult {
  id: string;
  timestamp: string;
  subjectName: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  timeSpentSeconds: number;
  xpEarned: number;
}

interface OfflinePracticeQuizModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialSubjectId?: string;
}

// Curriculum-aligned Offline Quiz Bank (NSSCO Namibian Standard)
const OFFLINE_QUIZ_BANK: QuizQuestion[] = [
  // Mathematics Questions
  {
    id: 'math-q1',
    topicId: 'math-alg-1',
    topicTitle: 'Algebraic Expressions & Quadratic Equations',
    subjectName: 'Mathematics',
    question: 'Solve the quadratic equation 2x² - 5x + 2 = 0 for x.',
    options: ['x = 1 or x = 2', 'x = 0.5 or x = 2', 'x = -0.5 or x = -2', 'x = 0.25 or x = 4'],
    correctIndex: 1,
    explanation: 'Factoring: (2x - 1)(x - 2) = 0 gives 2x - 1 = 0 => x = 0.5, and x - 2 = 0 => x = 2.',
    hint: 'Factor 2x² - 5x + 2 into two linear binomials (2x - a)(x - b).',
    difficulty: 'Medium',
  },
  {
    id: 'math-q2',
    topicId: 'math-alg-1',
    topicTitle: 'Algebraic Expressions & Quadratic Equations',
    subjectName: 'Mathematics',
    question: 'What is the minimum value of the expression f(x) = (x - 3)² + 4?',
    options: ['3', '4', '-3', '-4'],
    correctIndex: 1,
    explanation: 'Since (x - 3)² ≥ 0 for all real x, the minimum value occurs when (x - 3)² = 0, giving f(3) = 4.',
    hint: 'A squared real number is always non-negative (≥ 0).',
    difficulty: 'Easy',
  },
  {
    id: 'math-q3',
    topicId: 'math-trig-1',
    topicTitle: 'Sine & Cosine Rules',
    subjectName: 'Mathematics',
    question: 'In non-right angled △ABC, when should you use the Cosine Rule c² = a² + b² - 2ab cos(C)?',
    options: [
      'When given 2 angles and 1 side',
      'When given 3 angles',
      'When given 2 sides and the included angle (SAS) or all 3 sides (SSS)',
      'Only in right-angled triangles'
    ],
    correctIndex: 2,
    explanation: 'The Cosine Rule is applied when you know two sides and the angle trapped between them (SAS) or when all three side lengths are known (SSS).',
    hint: 'Consider the sides needed to calculate c when angle C is trapped between a and b.',
    difficulty: 'Easy',
  },
  {
    id: 'math-q4',
    topicId: 'math-trig-1',
    topicTitle: 'Sine & Cosine Rules',
    subjectName: 'Mathematics',
    question: 'Find the area of △ABC if side a = 6 cm, side b = 10 cm, and included angle C = 30°.',
    options: ['30 cm²', '15 cm²', '60 cm²', '25.9 cm²'],
    correctIndex: 1,
    explanation: 'Area = 1/2 × a × b × sin(C) = 1/2 × 6 × 10 × sin(30°) = 30 × 0.5 = 15 cm².',
    hint: 'Use the formula Area = 0.5 * a * b * sin(C). Remember sin(30°) = 0.5.',
    difficulty: 'Medium',
  },

  // Physical Science Questions
  {
    id: 'phys-q1',
    topicId: 'phys-mechanics',
    topicTitle: 'Newtonian Dynamics & Equations of Motion',
    subjectName: 'Physical Science',
    question: 'A 1200 kg vehicle accelerates from rest (0 m/s) to 20 m/s in 8 seconds. What is the resultant net force acting on the vehicle?',
    options: ['2400 N', '3000 N', '9600 N', '1500 N'],
    correctIndex: 1,
    explanation: 'Acceleration a = (v - u)/t = (20 - 0)/8 = 2.5 m/s². Force F = m × a = 1200 kg × 2.5 m/s² = 3000 N.',
    hint: 'First calculate acceleration using a = (v - u) / t, then use Newton\'s 2nd Law F = ma.',
    difficulty: 'Medium',
  },
  {
    id: 'phys-q2',
    topicId: 'phys-mechanics',
    topicTitle: 'Newtonian Dynamics & Equations of Motion',
    subjectName: 'Physical Science',
    question: 'Which of Newton\'s Laws states that every action force has an equal and opposite reaction force?',
    options: ['Newton\'s First Law', 'Newton\'s Second Law', 'Newton\'s Third Law', 'Law of Universal Gravitation'],
    correctIndex: 2,
    explanation: 'Newton\'s Third Law of Motion states that if Object A exerts a force on Object B, Object B exerts an equal magnitude force in the opposite direction on Object A.',
    hint: 'This law explains rocket propulsion and walking friction.',
    difficulty: 'Easy',
  },
  {
    id: 'phys-q3',
    topicId: 'phys-mechanics',
    topicTitle: 'Newtonian Dynamics & Equations of Motion',
    subjectName: 'Physical Science',
    question: 'A ball is dropped from height h under Earth gravity (g = 9.8 m/s²). If initial velocity u = 0, which equation determines its final velocity v?',
    options: ['v = u + at', 'v² = u² + 2as', 's = ut + 0.5at²', 'F = ma'],
    correctIndex: 1,
    explanation: 'v² = u² + 2as (or v² = 2gh) directly relates velocity and displacement without requiring time t.',
    hint: 'Look for the kinematic equation that connects final velocity, initial velocity, acceleration, and distance without time.',
    difficulty: 'Medium',
  },

  // Biology Questions
  {
    id: 'bio-q1',
    topicId: 'bio-photosynthesis',
    topicTitle: 'Photosynthesis & Leaf Anatomy',
    subjectName: 'Biology',
    question: 'What is the balanced chemical equation for oxygenic photosynthesis in plant leaves?',
    options: [
      'C₆H₁₂O₆ + 6O₂ -> 6CO₂ + 6H₂O',
      '6CO₂ + 6H₂O -> C₆H₁₂O₆ + 6O₂',
      'CO₂ + H₂O -> CH₂O + O₂',
      '6CO₂ + 6O₂ -> C₆H₁₂O₆ + 6H₂O'
    ],
    correctIndex: 1,
    explanation: 'Photosynthesis combines 6 carbon dioxide and 6 water molecules using light energy in chlorophyll to yield 1 glucose molecule (C₆H₁₂O₆) and 6 oxygen molecules.',
    hint: 'Reactants are carbon dioxide and water; products are glucose and oxygen gas.',
    difficulty: 'Easy',
  },
  {
    id: 'bio-q2',
    topicId: 'bio-photosynthesis',
    topicTitle: 'Photosynthesis & Leaf Anatomy',
    subjectName: 'Biology',
    question: 'Which plant vascular tissue is responsible for translocating sucrose and amino acids from source leaves to roots?',
    options: ['Xylem', 'Phloem', 'Stomata', 'Epidermis'],
    correctIndex: 1,
    explanation: 'Phloem transports organic nutrients (sucrose, amino acids) produced by photosynthesis via translocation. Xylem transports water and minerals.',
    hint: 'Phloem = Food transport; Xylem = Water transport.',
    difficulty: 'Easy',
  },
  {
    id: 'bio-q3',
    topicId: 'bio-photosynthesis',
    topicTitle: 'Photosynthesis & Leaf Anatomy',
    subjectName: 'Biology',
    question: 'Why do green plant leaves appear green when illuminated with natural sunlight?',
    options: [
      'Chlorophyll absorbs green light and reflects blue and red wavelengths.',
      'Chlorophyll reflects green light while absorbing red and blue light wavelengths.',
      'Stomata emit green neon fluorescence during photosynthesis.',
      'Xylem sap is naturally emerald green.'
    ],
    correctIndex: 1,
    explanation: 'Chlorophyll pigments absorb red and blue wavelengths for chemical reactions, reflecting green light back into our eyes.',
    hint: 'We see the color wavelength that is reflected, not absorbed.',
    difficulty: 'Easy',
  },

  // English Questions
  {
    id: 'eng-q1',
    topicId: 'eng-summary-writing',
    topicTitle: 'Summary Writing (100 words rule)',
    subjectName: 'English Second Language',
    question: 'What is the strict word count range expected for Namibian NSSCO Paper 2 summary writing questions?',
    options: ['50 - 70 words', '90 - 110 words', '150 - 200 words', 'No limit as long as all points are included'],
    correctIndex: 1,
    explanation: 'NSSCO criteria require concise summary answers within 90-110 words. Exceeding or falling short loses key language and structure marks.',
    hint: 'Think of the target around 100 words.',
    difficulty: 'Easy',
  },
  {
    id: 'eng-q2',
    topicId: 'eng-summary-writing',
    topicTitle: 'Summary Writing (100 words rule)',
    subjectName: 'English Second Language',
    question: 'When writing a formal summary response for NSSCO exams, which item MUST be avoided?',
    options: [
      'Connecting words like "Furthermore" and "Consequently"',
      'Personal opinions, examples, and quotes from the passage',
      'Using bullet points in draft notes',
      'Rephrasing key points in clear sentences'
    ],
    correctIndex: 1,
    explanation: 'Summaries must remain factual and direct. Personal opinions, figurative examples, and quotes waste precious word count and reduce content marks.',
    hint: 'Summaries report only given facts without adding your own commentary.',
    difficulty: 'Easy',
  },

  // History & Heritage Questions
  {
    id: 'hist-q1',
    topicId: 'hist-nam-independence',
    topicTitle: 'Namibia\'s Journey to Independence',
    subjectName: 'History & Namibian Heritage',
    question: 'Which historical UN Security Council Resolution passed in 1978 established the official framework for UNTAG-supervised elections in Namibia?',
    options: ['Resolution 242', 'Resolution 435', 'Resolution 1514', 'Resolution 632'],
    correctIndex: 1,
    explanation: 'UN Resolution 435 (1978) was the cornerstone international directive leading to the 1989 UNTAG elections and independence on March 21, 1990.',
    hint: 'This famous resolution number is widely taught in Grade 11 Namibian History.',
    difficulty: 'Easy',
  },
  {
    id: 'hist-q2',
    topicId: 'hist-nam-independence',
    topicTitle: 'Namibia\'s Journey to Independence',
    subjectName: 'History & Namibian Heritage',
    question: 'On which exact date did Namibia officially achieve sovereign independence as a democratic republic?',
    options: ['21 March 1990', '26 August 1966', '10 December 1959', '4 May 1978'],
    correctIndex: 0,
    explanation: 'Namibia gained independence on 21 March 1990, with Dr. Sam Nujoma sworn in as the founding President.',
    hint: 'Celebrated annually as Independence Day in Namibia.',
    difficulty: 'Easy',
  }
];

export const OfflinePracticeQuizModal: React.FC<OfflinePracticeQuizModalProps> = ({
  isOpen,
  onClose,
  initialSubjectId
}) => {
  const { isHighContrast } = useAccessibility();

  // State
  const [downloadedPackageIds, setDownloadedPackageIds] = useState<string[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  
  // Active quiz progression
  const [quizState, setQuizState] = useState<'selection' | 'active' | 'review' | 'completed'>('selection');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [confirmedAnswers, setConfirmedAnswers] = useState<Record<number, boolean>>({});
  const [showHint, setShowHint] = useState<boolean>(false);
  const [timerSeconds, setTimerSeconds] = useState<number>(0);
  const [timerInterval, setTimerInterval] = useState<NodeJS.Timeout | null>(null);

  // Result metrics
  const [score, setScore] = useState<number>(0);
  const [xpEarned, setXpEarned] = useState<number>(0);
  const [savedNoteSuccess, setSavedNoteSuccess] = useState<boolean>(false);
  const [recentQuizHistory, setRecentQuizHistory] = useState<QuizResult[]>([]);

  // On mount / open
  useEffect(() => {
    if (isOpen) {
      const downloaded = getDownloadedPackageIds();
      setDownloadedPackageIds(downloaded);

      // Load saved quiz history
      try {
        const rawHistory = localStorage.getItem('edujourney_offline_quiz_results');
        if (rawHistory) {
          setRecentQuizHistory(JSON.parse(rawHistory));
        }
      } catch (e) {
        console.error('Failed to load quiz history', e);
      }

      if (initialSubjectId) {
        setSelectedSubject(initialSubjectId);
      }
    }
  }, [isOpen, initialSubjectId]);

  // Handle timer
  useEffect(() => {
    if (quizState === 'active') {
      const interval = setInterval(() => {
        setTimerSeconds((prev) => prev + 1);
      }, 1000);
      setTimerInterval(interval);
      return () => clearInterval(interval);
    } else {
      if (timerInterval) clearInterval(timerInterval);
    }
  }, [quizState]);

  if (!isOpen) return null;

  // Filter available subjects from essential packages
  const availablePackages = ESSENTIAL_CURRICULUM_PACKAGES.map((pkg) => {
    const isDownloaded = downloadedPackageIds.includes(pkg.id);
    return {
      ...pkg,
      isDownloaded,
    };
  });

  // Start Quiz setup
  const handleStartQuiz = (subjectFilter: string) => {
    let filtered = [...OFFLINE_QUIZ_BANK];

    if (subjectFilter !== 'All') {
      const matchedPkg = ESSENTIAL_CURRICULUM_PACKAGES.find((p) => p.id === subjectFilter || p.subjectName === subjectFilter);
      if (matchedPkg) {
        filtered = OFFLINE_QUIZ_BANK.filter((q) => q.subjectName.toLowerCase() === matchedPkg.subjectName.toLowerCase());
      }
    }

    // Fallback if empty
    if (filtered.length === 0) {
      filtered = OFFLINE_QUIZ_BANK;
    }

    // Shuffle questions slightly for dynamic feel
    const shuffled = [...filtered].sort(() => Math.random() - 0.5);

    setQuizQuestions(shuffled);
    setCurrentIndex(0);
    setSelectedAnswers({});
    setConfirmedAnswers({});
    setShowHint(false);
    setTimerSeconds(0);
    setQuizState('active');
  };

  // Handle option pick
  const handleOptionSelect = (optionIndex: number) => {
    if (confirmedAnswers[currentIndex]) return; // Already confirmed
    setSelectedAnswers((prev) => ({
      ...prev,
      [currentIndex]: optionIndex,
    }));
  };

  // Confirm / check answer
  const handleConfirmAnswer = () => {
    setConfirmedAnswers((prev) => ({
      ...prev,
      [currentIndex]: true,
    }));
  };

  // Navigation
  const handleNextQuestion = () => {
    setShowHint(false);
    if (currentIndex < quizQuestions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      handleFinishQuiz();
    }
  };

  // Calculate final results
  const handleFinishQuiz = () => {
    let calculatedScore = 0;
    quizQuestions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctIndex) {
        calculatedScore += 1;
      }
    });

    const percentage = Math.round((calculatedScore / quizQuestions.length) * 100);
    const earnedXP = calculatedScore * 20 + (percentage >= 80 ? 50 : 20);

    setScore(calculatedScore);
    setXpEarned(earnedXP);

    const newResult: QuizResult = {
      id: `quiz-${Date.now()}`,
      timestamp: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
      subjectName: selectedSubject === 'All' ? 'NSSCO Mixed Revision' : selectedSubject,
      score: calculatedScore,
      totalQuestions: quizQuestions.length,
      percentage,
      timeSpentSeconds: timerSeconds,
      xpEarned: earnedXP,
    };

    const updatedHistory = [newResult, ...recentQuizHistory].slice(0, 10);
    setRecentQuizHistory(updatedHistory);
    localStorage.setItem('edujourney_offline_quiz_results', JSON.stringify(updatedHistory));

    setQuizState('completed');
  };

  // Save missed questions to offline notes
  const handleSaveMissedQuestionsToNotes = () => {
    const missed = quizQuestions.filter((q, idx) => selectedAnswers[idx] !== q.correctIndex);
    if (missed.length === 0) return;

    let noteContent = `Offline Revision Notes - ${new Date().toLocaleDateString()}\n\n`;
    missed.forEach((m, idx) => {
      noteContent += `${idx + 1}. [${m.subjectName}] ${m.question}\n`;
      noteContent += `• Correct Answer: ${m.options[m.correctIndex]}\n`;
      noteContent += `• Concept Note: ${m.explanation}\n\n`;
    });

    saveOfflineNote({
      subjectId: 'quiz-revision',
      title: `Quiz Correction Note (${missed.length} items to review)`,
      content: noteContent,
    });

    setSavedNoteSuccess(true);
    setTimeout(() => setSavedNoteSuccess(false), 3000);
  };

  const formatTime = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const currentQ = quizQuestions[currentIndex];
  const isAnswered = selectedAnswers[currentIndex] !== undefined;
  const isConfirmed = confirmedAnswers[currentIndex] === true;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className={`w-full max-w-3xl rounded-3xl overflow-hidden shadow-2xl border ${
          isHighContrast
            ? 'bg-black text-amber-300 border-amber-400'
            : 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white border-slate-200 dark:border-slate-800'
        } my-auto flex flex-col max-h-[90vh]`}
      >
        {/* Top Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0 bg-slate-50/80 dark:bg-slate-950/80 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center font-black shadow-md shadow-emerald-500/20">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-sm sm:text-base">Offline Curriculum Practice Quiz</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                  <WifiOff className="w-3 h-3" />
                  Offline Ready
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                NSSCO Curriculum Revision • Tested from local cached materials
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body Container */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-6">

          {/* 1. SELECTION SCREEN */}
          {quizState === 'selection' && (
            <div className="space-y-6">
              
              {/* Feature Hero Card */}
              <div className="p-5 rounded-3xl bg-gradient-to-r from-emerald-950 via-[#0A2540] to-teal-950 text-white border border-emerald-500/30 relative overflow-hidden shadow-lg">
                <div className="relative z-10 space-y-2">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold">
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    <span>No Internet Required</span>
                  </div>
                  <h2 className="text-lg sm:text-xl font-extrabold text-white">Test Your Knowledge Offline</h2>
                  <p className="text-xs text-slate-300 leading-relaxed max-w-xl">
                    Take interactive multiple-choice & past paper revision quizzes based on the Namibian NSSCO curriculum directly from your cached device storage. Earn XP and save revision corrections.
                  </p>
                </div>
              </div>

              {/* Select Subject Filter */}
              <div className="space-y-3">
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-emerald-500" />
                  <span>Select Subject Revision Package</span>
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  
                  {/* All Subjects Option */}
                  <button
                    type="button"
                    onClick={() => setSelectedSubject('All')}
                    className={`p-4 rounded-2xl border-2 text-left transition flex items-center justify-between ${
                      selectedSubject === 'All'
                        ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-900 dark:text-emerald-300 font-extrabold'
                        : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-black text-sm">
                        ✨
                      </div>
                      <div>
                        <div className="text-xs sm:text-sm font-extrabold">All Cached Subjects</div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">Mixed NSSCO Grade 11 Revision Test</div>
                      </div>
                    </div>
                    {selectedSubject === 'All' && <Check className="w-5 h-5 text-emerald-500" />}
                  </button>

                  {/* Individual downloaded/essential packages */}
                  {availablePackages.map((pkg) => (
                    <button
                      key={pkg.id}
                      type="button"
                      onClick={() => setSelectedSubject(pkg.id)}
                      className={`p-4 rounded-2xl border-2 text-left transition flex items-center justify-between ${
                        selectedSubject === pkg.id
                          ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-900 dark:text-emerald-300 font-extrabold'
                          : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center font-black text-xs">
                          {pkg.code.slice(-4)}
                        </div>
                        <div>
                          <div className="text-xs sm:text-sm font-extrabold">{pkg.subjectName}</div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                            <span>{pkg.grade}</span>
                            <span>•</span>
                            <span>{pkg.topics.length} Topics</span>
                            {pkg.isDownloaded && (
                              <span className="text-emerald-600 dark:text-emerald-400 font-bold">✓ Downloaded</span>
                            )}
                          </div>
                        </div>
                      </div>
                      {selectedSubject === pkg.id && <Check className="w-5 h-5 text-emerald-500" />}
                    </button>
                  ))}

                </div>
              </div>

              {/* Start Quiz CTA */}
              <div className="pt-2">
                <button
                  onClick={() => handleStartQuiz(selectedSubject)}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-extrabold text-sm sm:text-base shadow-lg shadow-emerald-500/25 hover:from-emerald-600 hover:to-teal-700 transition flex items-center justify-center gap-2 group"
                >
                  <Brain className="w-5 h-5 group-hover:rotate-12 transition-transform" />
                  <span>Start Practice Quiz Now</span>
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>

              {/* Recent Offline Quiz History */}
              {recentQuizHistory.length > 0 && (
                <div className="space-y-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-2">
                    <Award className="w-4 h-4 text-amber-500" />
                    <span>Recent Offline Quiz Results</span>
                  </h4>

                  <div className="space-y-2">
                    {recentQuizHistory.slice(0, 3).map((res) => (
                      <div
                        key={res.id}
                        className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-xl font-black text-xs flex items-center justify-center ${
                            res.percentage >= 80
                              ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                              : res.percentage >= 50
                              ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400'
                              : 'bg-rose-500/20 text-rose-600 dark:text-rose-400'
                          }`}>
                            {res.percentage}%
                          </div>
                          <div>
                            <div className="font-extrabold text-slate-900 dark:text-white">{res.subjectName}</div>
                            <div className="text-[10px] text-slate-500 dark:text-slate-400">
                              {res.score}/{res.totalQuestions} Correct • {res.timestamp}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 text-[11px] font-bold text-amber-500">
                          <Flame className="w-3.5 h-3.5 fill-amber-500" />
                          <span>+{res.xpEarned} XP</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          )}

          {/* 2. ACTIVE QUIZ SCREEN */}
          {quizState === 'active' && currentQ && (
            <div className="space-y-5">
              
              {/* Progress & Metadata Header */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-extrabold text-slate-500 dark:text-slate-400">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200">
                      Question {currentIndex + 1} of {quizQuestions.length}
                    </span>
                    <span className="px-2.5 py-1 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold">
                      {currentQ.subjectName}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 font-mono text-slate-600 dark:text-slate-300">
                    <Clock className="w-3.5 h-3.5 text-amber-500" />
                    <span>{formatTime(timerSeconds)}</span>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-300"
                    style={{ width: `${((currentIndex + 1) / quizQuestions.length) * 100}%` }}
                  />
                </div>
              </div>

              {/* Question Box */}
              <div className="p-5 rounded-3xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                    Topic: {currentQ.topicTitle}
                  </span>
                  <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                    currentQ.difficulty === 'Easy'
                      ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                      : currentQ.difficulty === 'Medium'
                      ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                      : 'bg-rose-500/10 text-rose-600 dark:text-rose-400'
                  }`}>
                    {currentQ.difficulty}
                  </span>
                </div>

                <h3 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white leading-relaxed">
                  {currentQ.question}
                </h3>

                {currentQ.hint && (
                  <div className="pt-2">
                    {!showHint ? (
                      <button
                        onClick={() => setShowHint(true)}
                        className="text-[11px] font-bold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Show Formula Hint</span>
                      </button>
                    ) : (
                      <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-800 dark:text-amber-300">
                        <strong>Hint:</strong> {currentQ.hint}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Options List */}
              <div className="space-y-2.5">
                {currentQ.options.map((opt, optIdx) => {
                  const isSelected = selectedAnswers[currentIndex] === optIdx;
                  const isCorrect = currentQ.correctIndex === optIdx;

                  let optionStyle = 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 hover:border-slate-300';

                  if (isSelected && !isConfirmed) {
                    optionStyle = 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-300 ring-2 ring-emerald-500/30';
                  } else if (isConfirmed) {
                    if (isCorrect) {
                      optionStyle = 'border-emerald-500 bg-emerald-500 text-white font-extrabold shadow-md';
                    } else if (isSelected && !isCorrect) {
                      optionStyle = 'border-rose-500 bg-rose-500 text-white font-extrabold shadow-md';
                    } else {
                      optionStyle = 'border-slate-200 dark:border-slate-800 opacity-50';
                    }
                  }

                  return (
                    <button
                      key={optIdx}
                      type="button"
                      disabled={isConfirmed}
                      onClick={() => handleOptionSelect(optIdx)}
                      className={`w-full p-4 rounded-2xl border-2 text-left font-bold text-xs sm:text-sm transition flex items-center justify-between gap-3 ${optionStyle}`}
                    >
                      <div className="flex items-center gap-3">
                        <span className={`w-6 h-6 rounded-lg text-xs flex items-center justify-center shrink-0 font-extrabold ${
                          isConfirmed && isCorrect
                            ? 'bg-white text-emerald-700'
                            : isConfirmed && isSelected && !isCorrect
                            ? 'bg-white text-rose-700'
                            : isSelected
                            ? 'bg-emerald-500 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                        }`}>
                          {String.fromCharCode(65 + optIdx)}
                        </span>
                        <span>{opt}</span>
                      </div>

                      {isConfirmed && isCorrect && <CheckCircle2 className="w-5 h-5 shrink-0 text-white" />}
                      {isConfirmed && isSelected && !isCorrect && <XCircle className="w-5 h-5 shrink-0 text-white" />}
                    </button>
                  );
                })}
              </div>

              {/* Explanation Banner when Confirmed */}
              {isConfirmed && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`p-4 rounded-2xl border ${
                    selectedAnswers[currentIndex] === currentQ.correctIndex
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-900 dark:text-emerald-300'
                      : 'bg-amber-500/10 border-amber-500/30 text-amber-900 dark:text-amber-300'
                  } text-xs space-y-1`}
                >
                  <div className="font-extrabold flex items-center gap-1.5">
                    {selectedAnswers[currentIndex] === currentQ.correctIndex ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                        <span>Correct Solution!</span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-4 h-4 text-amber-500" />
                        <span>Explanation & Concept Notes:</span>
                      </>
                    )}
                  </div>
                  <p className="leading-relaxed opacity-90">{currentQ.explanation}</p>
                </motion.div>
              )}

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-between gap-3">
                {!isConfirmed ? (
                  <button
                    disabled={!isAnswered}
                    onClick={handleConfirmAnswer}
                    className="w-full py-3.5 rounded-2xl bg-emerald-500 text-white font-extrabold text-xs sm:text-sm shadow-md disabled:opacity-40 disabled:cursor-not-allowed hover:bg-emerald-600 transition"
                  >
                    Check Solution
                  </button>
                ) : (
                  <button
                    onClick={handleNextQuestion}
                    className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-extrabold text-xs sm:text-sm shadow-md hover:from-emerald-600 hover:to-teal-700 transition flex items-center justify-center gap-2"
                  >
                    <span>{currentIndex < quizQuestions.length - 1 ? 'Next Question' : 'View Final Score'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>

            </div>
          )}

          {/* 3. COMPLETED SCORECARD */}
          {quizState === 'completed' && (
            <div className="space-y-6 text-center py-2">
              
              {/* Score Badge */}
              <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex flex-col items-center justify-center shadow-xl shadow-emerald-500/25 border-4 border-white dark:border-slate-800">
                <span className="text-2xl font-black">{Math.round((score / quizQuestions.length) * 100)}%</span>
                <span className="text-[10px] font-extrabold uppercase text-emerald-100">{score}/{quizQuestions.length} Correct</span>
              </div>

              <div className="space-y-1">
                <h3 className="text-xl font-black text-slate-900 dark:text-white">
                  {score === quizQuestions.length
                    ? '🎉 Perfect Score! Outstanding!'
                    : score / quizQuestions.length >= 0.7
                    ? '👏 Great Job! Strong Curriculum Mastery'
                    : '📚 Good Effort! Keep Reviewing'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Completed in {formatTime(timerSeconds)} • Earned +{xpEarned} XP Offline
                </p>
              </div>

              {/* Reward Cards */}
              <div className="grid grid-cols-2 gap-3 max-w-md mx-auto">
                <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-center">
                  <Flame className="w-5 h-5 text-amber-500 mx-auto mb-1 fill-amber-500" />
                  <div className="text-xs font-black text-slate-900 dark:text-white">+{xpEarned} XP</div>
                  <div className="text-[10px] text-slate-500">Offline Streak Preserved</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-center">
                  <Award className="w-5 h-5 text-emerald-500 mx-auto mb-1" />
                  <div className="text-xs font-black text-slate-900 dark:text-white">NSSCO Standard</div>
                  <div className="text-[10px] text-slate-500">Local Cache Sync</div>
                </div>
              </div>

              {/* Save Missed Corrections */}
              {score < quizQuestions.length && (
                <div className="pt-2">
                  <button
                    onClick={handleSaveMissedQuestionsToNotes}
                    className={`px-4 py-2.5 rounded-2xl border text-xs font-extrabold transition inline-flex items-center gap-2 ${
                      savedNoteSuccess
                        ? 'bg-emerald-500 text-white border-emerald-500'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    <Bookmark className="w-4 h-4" />
                    <span>{savedNoteSuccess ? '✓ Corrections Saved to Offline Notes!' : 'Save Corrections to Offline Notes'}</span>
                  </button>
                </div>
              )}

              {/* Actions */}
              <div className="pt-4 flex items-center justify-center gap-3">
                <button
                  onClick={() => setQuizState('selection')}
                  className="px-5 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-extrabold text-xs sm:text-sm hover:bg-slate-200 transition flex items-center gap-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Try Another Quiz</span>
                </button>

                <button
                  onClick={onClose}
                  className="px-6 py-3 rounded-2xl bg-emerald-500 text-white font-extrabold text-xs sm:text-sm hover:bg-emerald-600 transition shadow-md"
                >
                  Return to Dashboard
                </button>
              </div>

            </div>
          )}

        </div>
      </motion.div>
    </div>
  );
};
