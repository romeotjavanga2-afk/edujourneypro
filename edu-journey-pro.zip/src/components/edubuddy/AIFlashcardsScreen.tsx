import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Layers, Sparkles, Plus, RotateCw, CheckCircle2, 
  XCircle, Clock, Bookmark, Filter, Search, Trash2, 
  ArrowRight, ArrowLeft, Zap, ShieldCheck, BookOpen 
} from 'lucide-react';
import { AIFlashcard } from '../../types.js';

interface AIFlashcardsScreenProps {
  onBackToHome: () => void;
  onAskBuddyAboutConcept: (subject: string, conceptPrompt: string) => void;
}

export const AIFlashcardsScreen: React.FC<AIFlashcardsScreenProps> = ({
  onBackToHome,
  onAskBuddyAboutConcept
}) => {
  const [cards, setCards] = useState<AIFlashcard[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [reviewIndex, setReviewIndex] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'review' | 'grid'>('review');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Auto generate modal
  const [isGenModalOpen, setIsGenModalOpen] = useState<boolean>(false);
  const [genSubject, setGenSubject] = useState<string>('Mathematics');
  const [genTopic, setGenTopic] = useState<string>('Quadratic Formula & Discriminant');
  const [genCount, setGenCount] = useState<number>(5);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  // Custom create modal
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [customSubject, setCustomSubject] = useState<string>('Physical Science');
  const [customTopic, setCustomTopic] = useState<string>('Dynamics');
  const [customQuestion, setCustomQuestion] = useState<string>('');
  const [customAnswer, setCustomAnswer] = useState<string>('');

  const subjectsList = [
    'All', 'Mathematics', 'Physical Science', 'Computer Studies', 
    'English First Language', 'Geography', 'History'
  ];

  const loadCards = async () => {
    try {
      const url = selectedSubject !== 'All' ? `/api/edubuddy/flashcards?subject=${encodeURIComponent(selectedSubject)}` : '/api/edubuddy/flashcards';
      const res = await fetch(url);
      const json = await res.json();
      if (json.success) {
        setCards(json.data);
      }
    } catch (e) {
      console.warn("Offline flashcards load fallback:", e);
    }
  };

  useEffect(() => {
    loadCards();
    setReviewIndex(0);
    setIsFlipped(false);
  }, [selectedSubject]);

  const handleUpdateStatus = async (cardId: number, status: string) => {
    try {
      await fetch(`/api/edubuddy/flashcards/${cardId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      setCards(cards.map(c => c.id === cardId ? { ...c, status } : c));
      
      // Auto advance to next card in review mode
      if (viewMode === 'review' && filteredCards.length > 1) {
        setIsFlipped(false);
        setTimeout(() => {
          setReviewIndex(prev => (prev + 1) % filteredCards.length);
        }, 200);
      }
    } catch (e) {}
  };

  const handleToggleBookmark = async (cardId: number, currentBm: number, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const newBm = currentBm === 1 ? 0 : 1;
      await fetch(`/api/edubuddy/flashcards/${cardId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_bookmarked: newBm })
      });
      setCards(cards.map(c => c.id === cardId ? { ...c, is_bookmarked: newBm } : c));
    } catch (e) {}
  };

  const handleAutoGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!genTopic.trim() || isGenerating) return;

    setIsGenerating(true);
    try {
      const res = await fetch('/api/edubuddy/flashcards/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject: genSubject, topic: genTopic, count: genCount })
      });
      const json = await res.json();
      if (json.success && json.data) {
        setCards([...json.data, ...cards]);
        setIsGenModalOpen(false);
        if (selectedSubject !== 'All' && selectedSubject !== genSubject) {
          setSelectedSubject('All');
        }
        setReviewIndex(0);
        setIsFlipped(false);
      }
    } catch (err) {
      console.error("Gen flashcard error:", err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCreateCustom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customQuestion.trim() || !customAnswer.trim()) return;

    try {
      const res = await fetch('/api/edubuddy/flashcards', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject: customSubject, topic: customTopic, question: customQuestion, answer: customAnswer })
      });
      const json = await res.json();
      if (json.success && json.data) {
        setCards([json.data, ...cards]);
        setIsCreateModalOpen(false);
        setCustomQuestion('');
        setCustomAnswer('');
        setReviewIndex(0);
      }
    } catch (e) {}
  };

  const filteredCards = cards.filter(c => {
    if (searchTerm && !c.question.toLowerCase().includes(searchTerm.toLowerCase()) && !c.topic.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    return true;
  });

  const currentCard = filteredCards[reviewIndex];

  const masteredCount = cards.filter(c => c.status === 'Mastered').length;
  const reviewCount = cards.filter(c => c.status === 'Needs Practice' || c.status === 'Review later').length;

  return (
    <div className="space-y-6 pb-12 animate-fadeIn">
      
      {/* Top Banner & Control Bar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-500 to-fuchsia-600 text-white flex items-center justify-center shadow-lg shadow-purple-500/20">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Smart Flashcard Suite</span>
              <span className="text-xs bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20 px-2.5 py-0.5 rounded-full font-extrabold">
                Active Recall
              </span>
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {cards.length} Cards in Deck • {masteredCount} Mastered • {reviewCount} Needs Practice
            </p>
          </div>
        </div>

        {/* View Switchers & Create buttons */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-end">
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            <button
              onClick={() => setViewMode('review')}
              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition flex items-center gap-1.5 ${
                viewMode === 'review' ? 'bg-white dark:bg-slate-900 text-purple-600 dark:text-purple-400 shadow-sm' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Flip Review</span>
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition flex items-center gap-1.5 ${
                viewMode === 'grid' ? 'bg-white dark:bg-slate-900 text-purple-600 dark:text-purple-400 shadow-sm' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Grid ({filteredCards.length})</span>
            </button>
          </div>

          <button
            onClick={() => setIsGenModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-500 hover:to-fuchsia-500 text-white font-extrabold text-xs shadow-md shadow-purple-500/20 transition flex items-center gap-1.5"
          >
            <Sparkles className="w-4 h-4" />
            <span>✨ AI Generate Deck</span>
          </button>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 font-extrabold text-xs transition"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filters bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 no-scrollbar">
          {subjectsList.map((sub) => (
            <button
              key={sub}
              onClick={() => setSelectedSubject(sub)}
              className={`px-3 py-1.5 rounded-xl text-xs font-extrabold whitespace-nowrap transition ${
                selectedSubject === sub
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {sub}
            </button>
          ))}
        </div>

        <div className="relative shrink-0 w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search card text..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>
      </div>

      {/* VIEW 1: INTERACTIVE FLIP CARD REVIEW */}
      {viewMode === 'review' && (
        <div className="max-w-3xl mx-auto space-y-6">
          
          {filteredCards.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border border-slate-200 dark:border-slate-800 text-center space-y-4">
              <Layers className="w-14 h-14 text-slate-400 mx-auto" />
              <h3 className="font-extrabold text-base text-slate-800 dark:text-white">No flashcards found</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Generate a deck with AI above or create your custom cards to start practicing active recall!
              </p>
              <button
                onClick={() => setIsGenModalOpen(true)}
                className="px-5 py-2.5 rounded-xl bg-purple-600 text-white text-xs font-bold shadow-md mx-auto inline-block"
              >
                ✨ Generate with AI
              </button>
            </div>
          ) : (
            <>
              {/* Card tracker */}
              <div className="flex items-center justify-between px-2 text-xs font-extrabold">
                <span className="text-purple-600 dark:text-purple-400 uppercase tracking-wider">
                  Card {reviewIndex + 1} of {filteredCards.length}
                </span>
                <span className="text-slate-500 dark:text-slate-400">
                  {currentCard?.subject} • {currentCard?.topic}
                </span>
              </div>

              {/* FLIP CARD STAGE */}
              <div
                onClick={() => setIsFlipped(!isFlipped)}
                className="group relative cursor-pointer select-none perspective-1000 min-h-[320px] sm:min-h-[360px] flex items-stretch"
              >
                <motion.div
                  initial={false}
                  animate={{ rotateY: isFlipped ? 180 : 0 }}
                  transition={{ duration: 0.5, type: "spring", stiffness: 260, damping: 20 }}
                  className="w-full relative preserve-3d rounded-3xl p-6 sm:p-10 bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 shadow-xl hover:shadow-2xl hover:border-purple-500/50 transition-all flex flex-col justify-between text-center"
                >
                  {/* FRONT SIDE (QUESTION) */}
                  <div className={`space-y-4 my-auto backface-hidden ${isFlipped ? 'opacity-0 pointer-events-none absolute inset-0 p-10 flex flex-col justify-center' : ''}`}>
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-black uppercase tracking-wider bg-purple-500/10 text-purple-600 dark:text-purple-400 px-3 py-1 rounded-full">
                        ❓ Question
                      </span>
                      <button
                        onClick={(e) => currentCard && handleToggleBookmark(currentCard.id, currentCard.is_bookmarked, e)}
                        className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-amber-500"
                      >
                        <Bookmark className={`w-5 h-5 ${currentCard?.is_bookmarked === 1 ? 'fill-amber-500 text-amber-500' : ''}`} />
                      </button>
                    </div>

                    <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white pt-4 leading-relaxed">
                      {currentCard?.question}
                    </h2>

                    <div className="pt-8 text-xs font-bold text-slate-400 dark:text-slate-500 flex items-center justify-center gap-1.5 animate-pulse">
                      <RotateCw className="w-4 h-4" />
                      <span>Click anywhere to reveal answer</span>
                    </div>
                  </div>

                  {/* BACK SIDE (ANSWER) */}
                  <div 
                    className={`space-y-4 my-auto backface-hidden ${!isFlipped ? 'opacity-0 pointer-events-none absolute inset-0 p-10 flex flex-col justify-center' : ''}`}
                    style={{ transform: 'rotateY(180deg)' }}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-black uppercase tracking-wider bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-3 py-1 rounded-full">
                        💡 Answer & Key Rule
                      </span>
                      <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                        currentCard?.status === 'Mastered' ? 'bg-emerald-500/20 text-emerald-400' :
                        currentCard?.status === 'Needs Practice' ? 'bg-rose-500/20 text-rose-400' :
                        'bg-amber-500/20 text-amber-400'
                      }`}>
                        {currentCard?.status || 'Review later'}
                      </span>
                    </div>

                    <p className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white pt-4 leading-relaxed">
                      {currentCard?.answer}
                    </p>

                    <div className="pt-6 flex justify-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onAskBuddyAboutConcept(currentCard?.subject || 'General', `Can you give me an everyday example or deeper explanation of: ${currentCard?.question} -> ${currentCard?.answer}?`);
                        }}
                        className="text-xs text-purple-600 dark:text-purple-400 hover:underline font-extrabold flex items-center gap-1 bg-purple-500/10 px-3 py-1.5 rounded-xl"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Ask Edu Buddy for more details</span>
                      </button>
                    </div>
                  </div>
                </motion.div>
              </div>

              {/* Status Grading Action Buttons */}
              {currentCard && (
                <div className="grid grid-cols-3 gap-3 pt-2">
                  <button
                    onClick={() => handleUpdateStatus(currentCard.id, 'Needs Practice')}
                    className={`p-3.5 rounded-2xl font-extrabold text-xs transition flex flex-col sm:flex-row items-center justify-center gap-1.5 border ${
                      currentCard.status === 'Needs Practice'
                        ? 'bg-rose-500 text-white border-rose-600 shadow-md'
                        : 'bg-white dark:bg-slate-900 text-rose-600 dark:text-rose-400 border-slate-200 dark:border-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/40'
                    }`}
                  >
                    <XCircle className="w-4 h-4" />
                    <span>Needs Practice</span>
                  </button>

                  <button
                    onClick={() => handleUpdateStatus(currentCard.id, 'Review later')}
                    className={`p-3.5 rounded-2xl font-extrabold text-xs transition flex flex-col sm:flex-row items-center justify-center gap-1.5 border ${
                      currentCard.status === 'Review later'
                        ? 'bg-amber-500 text-white border-amber-600 shadow-md'
                        : 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 border-slate-200 dark:border-slate-800 hover:bg-amber-50 dark:hover:bg-amber-950/40'
                    }`}
                  >
                    <Clock className="w-4 h-4" />
                    <span>Review Later</span>
                  </button>

                  <button
                    onClick={() => handleUpdateStatus(currentCard.id, 'Mastered')}
                    className={`p-3.5 rounded-2xl font-extrabold text-xs transition flex flex-col sm:flex-row items-center justify-center gap-1.5 border ${
                      currentCard.status === 'Mastered'
                        ? 'bg-emerald-500 text-[#0A2540] border-emerald-600 shadow-md'
                        : 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 border-slate-200 dark:border-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Mastered! ✓</span>
                  </button>
                </div>
              )}

              {/* Navigation buttons */}
              <div className="flex items-center justify-between pt-2">
                <button
                  onClick={() => {
                    setIsFlipped(false);
                    setReviewIndex(prev => (prev - 1 + filteredCards.length) % filteredCards.length);
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold text-xs flex items-center gap-1.5 hover:bg-slate-200 transition"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Prev Card</span>
                </button>

                <button
                  onClick={() => {
                    setIsFlipped(false);
                    setReviewIndex(prev => (prev + 1) % filteredCards.length);
                  }}
                  className="px-4 py-2 rounded-xl bg-purple-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-md hover:bg-purple-500 transition"
                >
                  <span>Next Card</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* VIEW 2: GRID LIST VIEW */}
      {viewMode === 'grid' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCards.map((card) => (
            <div
              key={card.id}
              className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                  <span className="font-extrabold uppercase tracking-wider text-purple-600 dark:text-purple-400">
                    {card.subject} • {card.topic}
                  </span>
                  <button
                    onClick={(e) => handleToggleBookmark(card.id, card.is_bookmarked, e)}
                    className="text-slate-400 hover:text-amber-500"
                  >
                    <Bookmark className={`w-4 h-4 ${card.is_bookmarked === 1 ? 'fill-amber-500 text-amber-500' : ''}`} />
                  </button>
                </div>
                <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
                  Q: {card.question}
                </h4>
                <div className="p-3 mt-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <strong className="text-emerald-600 dark:text-emerald-400">A:</strong> {card.answer}
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                <span className={`px-2.5 py-0.5 rounded-full font-bold ${
                  card.status === 'Mastered' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' :
                  card.status === 'Needs Practice' ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400' :
                  'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                }`}>
                  {card.status}
                </span>

                <button
                  onClick={() => {
                    setViewMode('review');
                    const idx = filteredCards.findIndex(c => c.id === card.id);
                    if (idx !== -1) setReviewIndex(idx);
                  }}
                  className="text-purple-600 dark:text-purple-400 font-extrabold hover:underline"
                >
                  Review Card →
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* MODAL 1: AI AUTO GENERATE DECK */}
      {isGenModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6"
          >
            <div className="flex items-center justify-between border-b pb-4">
              <h3 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                <span>AI Flashcard Deck Generator</span>
              </h3>
              <button onClick={() => setIsGenModalOpen(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <form onSubmit={handleAutoGenerate} className="space-y-4">
              <div>
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-2">Subject</label>
                <select
                  value={genSubject}
                  onChange={(e) => setGenSubject(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800 border text-sm font-bold text-slate-800 dark:text-slate-100"
                >
                  {subjectsList.filter(s => s !== 'All').map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-2">Topic or Syllabus Chapter</label>
                <input
                  type="text"
                  value={genTopic}
                  onChange={(e) => setGenTopic(e.target.value)}
                  placeholder="e.g. Quadratic Formula, Physics Friction, Python Lists..."
                  required
                  className="w-full p-3.5 rounded-xl bg-slate-100 dark:bg-slate-800 border text-sm font-semibold text-slate-800 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-2">Number of Cards</label>
                <select
                  value={genCount}
                  onChange={(e) => setGenCount(Number(e.target.value))}
                  className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800 border text-sm font-bold text-slate-800 dark:text-slate-100"
                >
                  <option value={3}>3 Cards (Quick Concept Refresh)</option>
                  <option value={5}>5 Cards (Standard Revision Deck)</option>
                  <option value={10}>10 Cards (Complete Chapter Review)</option>
                </select>
              </div>

              <div className="pt-4 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setIsGenModalOpen(false)}
                  className="flex-1 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isGenerating || !genTopic.trim()}
                  className="flex-2 py-3.5 px-6 rounded-xl bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white font-extrabold text-xs shadow-lg flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isGenerating ? <Sparkles className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  <span>{isGenerating ? 'Generating Deck...' : '✨ Generate Deck'}</span>
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* MODAL 2: CREATE CUSTOM CARD */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6"
          >
            <div className="flex items-center justify-between border-b pb-4">
              <h3 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-purple-600" />
                <span>Create Custom Flashcard</span>
              </h3>
              <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateCustom} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">Subject</label>
                  <select
                    value={customSubject}
                    onChange={(e) => setCustomSubject(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 border text-xs font-bold"
                  >
                    {subjectsList.filter(s => s !== 'All').map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">Topic</label>
                  <input
                    type="text"
                    value={customTopic}
                    onChange={(e) => setCustomTopic(e.target.value)}
                    required
                    className="w-full p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 border text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">Question (Front Side)</label>
                <textarea
                  value={customQuestion}
                  onChange={(e) => setCustomQuestion(e.target.value)}
                  rows={3}
                  placeholder="What is the standard formula or definition?"
                  required
                  className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800 border text-xs font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">Answer & Explanation (Back Side)</label>
                <textarea
                  value={customAnswer}
                  onChange={(e) => setCustomAnswer(e.target.value)}
                  rows={3}
                  placeholder="The concise correct answer and pro memory tip..."
                  required
                  className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800 border text-xs font-medium"
                />
              </div>

              <div className="pt-4 flex items-center gap-3">
                <button type="button" onClick={() => setIsCreateModalOpen(false)} className="flex-1 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 font-bold text-xs">Cancel</button>
                <button type="submit" className="flex-2 py-3 px-6 rounded-xl bg-purple-600 text-white font-extrabold text-xs shadow-md">Save Flashcard</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};
