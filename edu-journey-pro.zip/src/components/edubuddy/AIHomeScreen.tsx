import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Sparkles, MessageSquare, Brain, Layers, FileText, 
  ArrowRight, Flame, Trophy, Settings, Bookmark, 
  CheckCircle2, Clock, Zap, BookOpen, ShieldCheck, Heart 
} from 'lucide-react';

interface AIHomeScreenProps {
  data: any;
  onNavigate: (tab: 'chat' | 'quizzes' | 'flashcards' | 'summary') => void;
  onStartChatWithPrompt: (subject: string, prompt: string) => void;
  onOpenPreferences: () => void;
}

export const AIHomeScreen: React.FC<AIHomeScreenProps> = ({
  data,
  onNavigate,
  onStartChatWithPrompt,
  onOpenPreferences
}) => {
  const [selectedSubject, setSelectedSubject] = useState<string>('All');

  const studentName = data?.studentName || 'Scholar';
  const streak = data?.learningStreak || 7;
  const xpTotal = data?.xpTotal || 2450;
  const preferences = data?.preferences || {};
  const memory = data?.memory || {};
  const quickSuggestions = data?.quickSuggestions || [];
  const recommendations = data?.recommendations || [];

  const avatarIcon = 
    preferences.avatar === 'cyber-owl' ? '🦉' :
    preferences.avatar === 'astro-guide' ? '👩‍🚀' :
    preferences.avatar === 'safari-cheetah' ? '🐆' :
    preferences.avatar === 'quantum-leopard' ? '🐯' :
    preferences.avatar === 'digital-mentor' ? '🌟' : '🤖';

  const greetingText = preferences.greeting || "Ready to master your goals today?";

  const quickCards = [
    {
      id: 'chat',
      title: 'Ask Edu Buddy',
      subtitle: '24/7 Step-by-Step AI Tutoring',
      description: 'Get instant explanations, Socratic homework guidance, and concept breakdowns in your preferred learning style.',
      icon: MessageSquare,
      color: 'from-emerald-500 to-teal-600',
      badge: 'Interactive Tutoring',
      action: () => onNavigate('chat')
    },
    {
      id: 'quizzes',
      title: 'Practice Quiz Generator',
      subtitle: 'Test Your NSSCO Mastery',
      description: 'Create custom multiple-choice or short-answer quizzes across Easy, Medium, Hard, or Exam Level difficulty.',
      icon: Brain,
      color: 'from-blue-500 to-indigo-600',
      badge: 'Active Assessment',
      action: () => onNavigate('quizzes')
    },
    {
      id: 'flashcards',
      title: 'Smart Flashcard Suite',
      subtitle: 'Active Recall & Flip Review',
      description: 'Generate high-yield revision flashcards from your syllabus or notes. Track mastered topics and review weak spots.',
      icon: Layers,
      color: 'from-purple-500 to-fuchsia-600',
      badge: 'Memory Booster',
      action: () => onNavigate('flashcards')
    },
    {
      id: 'summary',
      title: 'Note Summarizer Tool',
      subtitle: 'Turn Long Notes into Core Points',
      description: 'Paste textbook summaries or lecture transcripts to extract bullet points, definitions, and mind map outlines.',
      icon: FileText,
      color: 'from-amber-500 to-orange-600',
      badge: 'Exam Prep Tool',
      action: () => onNavigate('summary')
    }
  ];

  return (
    <div className="space-y-8 pb-12 animate-fadeIn">
      {/* 1. Hero Banner / Mentor Status Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0A2540] via-slate-900 to-emerald-950 p-6 sm:p-8 md:p-10 text-white shadow-2xl border border-emerald-500/30">
        {/* Background Decorative glow */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center gap-5">
            {/* Avatar badge */}
            <div className="relative shrink-0">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-emerald-400 via-teal-300 to-cyan-400 p-0.5 shadow-xl shadow-emerald-500/30">
                <div className="w-full h-full bg-[#0A2540] rounded-[14px] flex items-center justify-center text-3xl sm:text-4xl">
                  {avatarIcon}
                </div>
              </div>
              <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-emerald-400 border-2 border-[#0A2540] flex items-center justify-center shadow-md">
                <Sparkles className="w-3.5 h-3.5 text-[#0A2540] animate-spin" style={{ animationDuration: '6s' }} />
              </span>
            </div>

            {/* Greeting & Motivation */}
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-extrabold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-500/30 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  <span>Edu Buddy AI Companion</span>
                </span>
                <span className="text-xs text-slate-400">
                  Style: <strong className="text-slate-200">{preferences.conversation_style || 'Friendly'}</strong>
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
                Hi, <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-300 to-teal-200">{studentName}</span>! {greetingText}
              </h1>
              <p className="text-sm sm:text-base text-slate-300 max-w-2xl font-normal leading-relaxed">
                "{data?.dailyMotivation || "Success is the sum of small efforts repeated day in and day out. Let's make today count!"}"
              </p>
            </div>
          </div>

          {/* Stats & Customizer Actions */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-3 w-full lg:w-auto shrink-0 pt-4 lg:pt-0 border-t lg:border-t-0 border-white/10">
            <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/15 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center font-bold text-lg">
                <Flame className="w-5 h-5 fill-orange-400 animate-pulse" />
              </div>
              <div>
                <div className="text-xs text-slate-300 font-medium">Learning Streak</div>
                <div className="text-sm font-extrabold text-white">{streak} Days 🔥</div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/15 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                <Trophy className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs text-slate-300 font-medium">Mentor XP</div>
                <div className="text-sm font-extrabold text-emerald-300">+{xpTotal.toLocaleString()} XP</div>
              </div>
            </div>

            <button
              onClick={onOpenPreferences}
              className="p-3 rounded-2xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white border border-white/15 transition shadow-sm"
              title="Customize AI Personality & Preferences"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* 2. Core Study Tools Grid (4 Pillars) */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-emerald-500" />
              <span>Interactive AI Learning Suite</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              Select a specialized tool to accelerate your NSSCO studies and homework comprehension
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickCards.map((card) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={card.id}
                whileHover={{ y: -4, scale: 1.01 }}
                whileTap={{ scale: 0.98 }}
                onClick={card.action}
                className="group cursor-pointer bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl hover:border-emerald-500/40 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${card.color} text-white flex items-center justify-center shadow-md`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 group-hover:bg-emerald-500/10 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition">
                      {card.badge}
                    </span>
                  </div>
                  <h3 className="font-extrabold text-base text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition">
                    {card.title}
                  </h3>
                  <div className="text-xs font-bold text-slate-500 dark:text-slate-400 mt-0.5">
                    {card.subtitle}
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2.5 leading-relaxed line-clamp-3">
                    {card.description}
                  </p>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-bold text-emerald-600 dark:text-emerald-400">
                  <span>Launch Suite</span>
                  <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition" />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* 3. Personalized Study Recommendations & Quick Jump */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Smart Topic Suggestions */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-emerald-500" />
              <span>Recommended Study Starters</span>
            </h3>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Tailored to your weak topics & due dates
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {quickSuggestions.map((item: any, idx: number) => (
              <div
                key={idx}
                onClick={() => {
                  if (item.action === 'quiz') onNavigate('quizzes');
                  else if (item.action === 'flashcards') onNavigate('flashcards');
                  else onStartChatWithPrompt(item.subject || 'General', item.prompt);
                }}
                className="group cursor-pointer bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-emerald-500/40 hover:shadow-md transition flex items-start gap-3.5"
              >
                <div className="w-11 h-11 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center text-xl shrink-0 group-hover:scale-110 transition">
                  {item.icon || '📚'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                    {item.subject || 'General Study'}
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white truncate group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition">
                    {item.title}
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                    {item.subtitle}
                  </p>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-500 group-hover:translate-x-1 transition shrink-0 self-center" />
              </div>
            ))}
          </div>
        </div>

        {/* Right 1 Col: Memory Profile Summary Card */}
        <div className="bg-gradient-to-br from-slate-900 to-[#0A2540] rounded-2xl p-5 text-white border border-slate-800 shadow-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 px-2.5 py-1 rounded-full border border-emerald-500/30 flex items-center gap-1">
                <Brain className="w-3.5 h-3.5" />
                <span>AI Memory Profile</span>
              </span>
              <button
                onClick={onOpenPreferences}
                className="text-xs text-emerald-400 hover:underline font-semibold"
              >
                Edit Profile
              </button>
            </div>

            <h3 className="font-extrabold text-base text-white mb-2">
              How Edu Buddy Knows You Best
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Edu Buddy customizes explanations and examples based on your personal learning style and academic aspirations.
            </p>

            <div className="space-y-3 text-xs border-t border-slate-800 pt-3">
              <div>
                <span className="text-slate-400 font-medium">Learning Style:</span>
                <div className="font-bold text-emerald-300 mt-0.5 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>{memory.preferred_learning_style || 'Visual & Step-by-Step'}</span>
                </div>
              </div>

              <div>
                <span className="text-slate-400 font-medium">Career Ambitions:</span>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {(memory.career_goals || ['Software Engineer', 'Data Scientist']).map((goal: string, idx: number) => (
                    <span key={idx} className="bg-white/10 px-2 py-0.5 rounded-md text-white font-semibold">
                      {goal}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-slate-400 font-medium">Target Focus Areas:</span>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {(memory.weak_topics || ['Quadratic Word Problems', 'Newton Second Law Graphing']).map((topic: string, idx: number) => (
                    <span key={idx} className="bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2 py-0.5 rounded-md font-medium">
                      🎯 {topic}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-5 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span>Socratic guidance active</span>
            <span className="text-emerald-400 font-bold">100% Privacy Safe</span>
          </div>
        </div>

      </div>
    </div>
  );
};
