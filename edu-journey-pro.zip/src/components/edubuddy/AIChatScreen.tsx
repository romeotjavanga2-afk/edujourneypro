import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, Sparkles, Bot, User, Plus, MessageSquare, 
  Trash2, Pin, PinOff, Bookmark, Edit2, Search, 
  HelpCircle, ShieldCheck, Check, CornerDownLeft, 
  Lightbulb, ChevronDown, CheckCircle2, AlertCircle, RefreshCw 
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { AIChatConversation, AIChatMessage } from '../../types.js';

interface AIChatScreenProps {
  initialSubject?: string;
  initialPrompt?: string;
  onClearInitialPrompt?: () => void;
  preferences?: any;
}

export const AIChatScreen: React.FC<AIChatScreenProps> = ({
  initialSubject = 'Mathematics',
  initialPrompt = '',
  onClearInitialPrompt,
  preferences = {}
}) => {
  const [conversations, setConversations] = useState<AIChatConversation[]>([]);
  const [activeConvId, setActiveConvId] = useState<number | null>(null);
  const [messages, setMessages] = useState<AIChatMessage[]>([]);
  const [inputMsg, setInputMsg] = useState<string>('');
  const [subject, setSubject] = useState<string>(initialSubject);
  const [explanationMode, setExplanationMode] = useState<string>('Step-by-Step');
  const [isHomeworkGuidance, setIsHomeworkGuidance] = useState<boolean>(false);
  const [isThinking, setIsThinking] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [editingTitleId, setEditingTitleId] = useState<number | null>(null);
  const [newTitleText, setNewTitleText] = useState<string>('');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const subjectsList = [
    'Mathematics', 'Physical Science', 'Computer Studies', 
    'English First Language', 'Geography', 'History', 'General'
  ];

  const explanationModes = [
    { id: 'Step-by-Step', label: '🔢 Step-by-Step', desc: 'Numbered logical sequence explaining why at each step' },
    { id: 'Explain Like I\'m 10', label: '🎈 Explain Like I\'m 10', desc: 'Fun everyday analogies, zero intimidation' },
    { id: 'Teacher Mode', label: '🎓 Teacher Mode', desc: 'Socratic questioning to help you discover the answer' },
    { id: 'Exam Mode', label: '👑 NSSCO Exam Mode', desc: 'Marking criteria, common pitfalls & time management' },
    { id: 'Visual Learning', label: '📊 Visual Learning', desc: 'ASCII diagrams, tables & structured comparisons' },
    { id: 'Normal', label: '📚 Standard Academic', desc: 'Standard secondary school explanation' },
    { id: 'Detailed', label: '🔬 Detailed & In-Depth', desc: 'Deep theory, derivations & real-world applications' },
  ];

  const quickTopicPills = [
    "Explain the Quadratic Formula derivation",
    "How do I plot Acceleration vs Force graphs?",
    "Difference between Python Lists and Tuples",
    "NSSCO Paper 1 Time Management Tips",
    "How to calculate percentage profit and loss"
  ];

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  // Load conversations list
  const fetchConversations = async (query = '') => {
    try {
      const url = query ? `/api/edubuddy/conversations?q=${encodeURIComponent(query)}` : '/api/edubuddy/conversations';
      const res = await fetch(url);
      const json = await res.json();
      if (json.success) {
        setConversations(json.data);
        if (!activeConvId && json.data.length > 0 && !initialPrompt) {
          setActiveConvId(json.data[0].id);
          setSubject(json.data[0].subject || 'Mathematics');
          setExplanationMode(json.data[0].explanation_mode || 'Step-by-Step');
        }
      }
    } catch (e) {
      console.warn("Offline conversation load fallback:", e);
    }
  };

  useEffect(() => {
    fetchConversations(searchTerm);
  }, [searchTerm]);

  // Load messages for active conversation
  const fetchMessages = async (convId: number) => {
    try {
      const res = await fetch(`/api/edubuddy/conversations/${convId}/messages`);
      const json = await res.json();
      if (json.success) {
        setMessages(json.data);
      }
    } catch (e) {
      console.warn("Offline messages load fallback:", e);
    }
  };

  useEffect(() => {
    if (activeConvId) {
      fetchMessages(activeConvId);
    } else {
      setMessages([]);
    }
  }, [activeConvId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isThinking]);

  // Handle initial prompt from Home recommendations
  useEffect(() => {
    if (initialPrompt && initialPrompt.trim()) {
      setSubject(initialSubject || 'Mathematics');
      setInputMsg(initialPrompt);
      setActiveConvId(null); // Start a fresh conversation for the recommended topic
      if (onClearInitialPrompt) onClearInitialPrompt();
    }
  }, [initialPrompt]);

  const handleStartNewChat = async () => {
    try {
      const res = await fetch('/api/edubuddy/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: 'New Learning Session', subject, explanation_mode: explanationMode })
      });
      const json = await res.json();
      if (json.success) {
        setConversations([json.data, ...conversations]);
        setActiveConvId(json.data.id);
        setMessages([]);
        if (window.innerWidth < 1024) setIsSidebarOpen(false);
      }
    } catch (e) {
      showToast("Could not create chat offline");
    }
  };

  const handleDeleteConversation = async (convId: number, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await fetch(`/api/edubuddy/conversations/${convId}`, { method: 'DELETE' });
      const filtered = conversations.filter(c => c.id !== convId);
      setConversations(filtered);
      if (activeConvId === convId) {
        setActiveConvId(filtered.length > 0 ? filtered[0].id : null);
      }
      showToast("Conversation deleted");
    } catch (e) {}
  };

  const handleTogglePin = async (convId: number, currentPin: number, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const newPin = currentPin === 1 ? 0 : 1;
      await fetch(`/api/edubuddy/conversations/${convId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_pinned: newPin })
      });
      fetchConversations();
      showToast(newPin === 1 ? "Chat pinned to top" : "Chat unpinned");
    } catch (e) {}
  };

  const handleRenameSave = async (convId: number) => {
    if (!newTitleText.trim()) {
      setEditingTitleId(null);
      return;
    }
    try {
      await fetch(`/api/edubuddy/conversations/${convId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: newTitleText.trim() })
      });
      setConversations(conversations.map(c => c.id === convId ? { ...c, title: newTitleText.trim() } : c));
      setEditingTitleId(null);
      showToast("Title updated");
    } catch (e) {}
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputMsg.trim() || isThinking) return;

    const userText = inputMsg.trim();
    setInputMsg('');
    setIsThinking(true);

    // Optimistic user message append
    const tempUserMsg: AIChatMessage = {
      id: Date.now(),
      conversation_id: activeConvId || 0,
      sender: 'user',
      content: userText,
      explanation_mode: explanationMode,
      created_at: new Date().toISOString()
    };
    setMessages(prev => [...prev, tempUserMsg]);

    try {
      const res = await fetch('/api/edubuddy/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversation_id: activeConvId,
          message: userText,
          subject,
          explanation_mode: explanationMode,
          is_homework_help: isHomeworkGuidance
        })
      });
      const json = await res.json();
      if (json.success && json.data) {
        if (!activeConvId) {
          setActiveConvId(json.data.conversation_id);
          fetchConversations();
        }
        setMessages(prev => [...prev, {
          id: json.data.id,
          conversation_id: json.data.conversation_id,
          sender: 'ai',
          content: json.data.content,
          explanation_mode: json.data.explanation_mode,
          created_at: json.data.created_at
        }]);
      }
    } catch (err) {
      console.error("Chat send failed:", err);
      showToast("Failed to send message. Please try again.");
    } finally {
      setIsThinking(false);
    }
  };

  const handleBookmarkMessage = async (msgId: number, content: string) => {
    try {
      const snippet = content.length > 80 ? content.substring(0, 80) + '...' : content;
      await fetch('/api/edubuddy/bookmarks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversation_id: activeConvId,
          message_id: msgId,
          title: `${subject} Note (${explanationMode})`,
          snippet,
          category: subject
        })
      });
      setMessages(messages.map(m => m.id === msgId ? { ...m, is_bookmarked: 1 } : m));
      showToast("Saved to Bookmarks!");
    } catch (e) {
      showToast("Failed to save bookmark");
    }
  };

  const pinnedList = conversations.filter(c => c.is_pinned === 1);
  const unpinnedList = conversations.filter(c => c.is_pinned !== 1);

  return (
    <div className="h-[calc(100vh-140px)] min-h-[600px] flex flex-col lg:flex-row gap-4 bg-slate-50 dark:bg-slate-950 rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-xl relative animate-fadeIn">
      
      {/* Toast popup */}
      {toastMsg && (
        <div className="absolute top-4 right-4 z-50 bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-4 py-2 rounded-xl shadow-lg text-xs font-bold flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* LEFT SIDEBAR: Conversation History */}
      <aside className={`fixed inset-y-0 left-0 z-40 w-80 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col transition-transform duration-300 transform lg:translate-x-0 lg:static lg:w-72 shrink-0 ${isSidebarOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'}`}>
        
        {/* Sidebar Header & New Chat */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 space-y-3">
          <button
            onClick={handleStartNewChat}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-[#0A2540] font-extrabold text-sm shadow-md shadow-emerald-500/20 flex items-center justify-center gap-2 transition transform active:scale-98"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>New Learning Chat</span>
          </button>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search chat history..."
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60 text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            />
          </div>
        </div>

        {/* Conversation Lists */}
        <div className="flex-1 overflow-y-auto p-3 space-y-4">
          {/* Pinned Section */}
          {pinnedList.length > 0 && (
            <div>
              <div className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500 px-2 mb-1.5 flex items-center gap-1">
                <Pin className="w-3 h-3 text-emerald-500 rotate-45" />
                <span>Pinned Study Sessions</span>
              </div>
              <div className="space-y-1">
                {pinnedList.map(c => renderConvItem(c))}
              </div>
            </div>
          )}

          {/* Recent Section */}
          <div>
            <div className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500 px-2 mb-1.5">
              Recent Conversations
            </div>
            {unpinnedList.length === 0 && pinnedList.length === 0 ? (
              <div className="text-center py-8 text-xs text-slate-400">
                No conversations yet. Start asking Edu Buddy anything!
              </div>
            ) : (
              <div className="space-y-1">
                {unpinnedList.map(c => renderConvItem(c))}
              </div>
            )}
          </div>
        </div>

        {/* Sidebar Footer info */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
          <span className="flex items-center gap-1 font-semibold text-emerald-600 dark:text-emerald-400">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>NSSCO AI Mentor</span>
          </span>
          <span>Grade 8-12 Standard</span>
        </div>
      </aside>

      {/* MOBILE BACKDROP FOR SIDEBAR */}
      {isSidebarOpen && (
        <div 
          onClick={() => setIsSidebarOpen(false)} 
          className="fixed inset-0 z-30 bg-slate-950/60 backdrop-blur-sm lg:hidden"
        />
      )}

      {/* MAIN CHAT AREA */}
      <main className="flex-1 flex flex-col min-w-0 bg-white dark:bg-slate-900/90 relative">
        
        {/* Chat Top Banner / Controls */}
        <header className="p-4 border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md flex flex-wrap items-center justify-between gap-3 shrink-0">
          
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="lg:hidden p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
            >
              <MessageSquare className="w-5 h-5" />
            </button>

            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-[#0A2540] flex items-center justify-center font-bold shadow-md shadow-emerald-500/20 shrink-0">
              <Bot className="w-6 h-6" />
            </div>

            <div>
              <h2 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white truncate max-w-[200px] sm:max-w-xs">
                {activeConvId ? conversations.find(c => c.id === activeConvId)?.title || 'Learning Session' : 'Ask Edu Buddy Anything'}
              </h2>
              <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Online & Ready to Assist</span>
              </div>
            </div>
          </div>

          {/* Controls: Subject & Mode selectors + Guidance Toggle */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Subject Selector */}
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {subjectsList.map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>

            {/* Explanation Mode Dropdown */}
            <select
              value={explanationMode}
              onChange={(e) => setExplanationMode(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-emerald-500/10 dark:bg-emerald-500/20 border border-emerald-500/30 text-xs font-bold text-emerald-700 dark:text-emerald-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {explanationModes.map(m => (
                <option key={m.id} value={m.id}>{m.label}</option>
              ))}
            </select>

            {/* Socratic Homework Guidance Toggle */}
            <button
              type="button"
              onClick={() => {
                const next = !isHomeworkGuidance;
                setIsHomeworkGuidance(next);
                showToast(next ? "Socratic Homework Guidance Active" : "Standard Tutoring Mode");
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold border flex items-center gap-1.5 transition ${
                isHomeworkGuidance
                  ? 'bg-amber-500/15 border-amber-500/40 text-amber-700 dark:text-amber-400 shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400'
              }`}
              title="When enabled, Edu Buddy asks guiding questions instead of giving direct answers"
            >
              <Lightbulb className={`w-3.5 h-3.5 ${isHomeworkGuidance ? 'fill-amber-400 text-amber-500 animate-bounce' : ''}`} />
              <span className="hidden sm:inline">{isHomeworkGuidance ? 'Guidance Active' : 'Socratic Guide'}</span>
            </button>
          </div>
        </header>

        {/* Messages Stream Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {messages.length === 0 ? (
            /* Welcome / Empty State */
            <div className="max-w-xl mx-auto my-auto py-8 text-center space-y-6 animate-fadeIn">
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-[#0A2540] flex items-center justify-center text-3xl mx-auto shadow-xl shadow-emerald-500/20">
                🤖
              </div>
              <div>
                <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
                  How can I help you learn {subject} today?
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
                  Ask any question, paste a problem from your homework, or choose an explanation mode above!
                </p>
              </div>

              {/* Socratic guidance alert banner */}
              {isHomeworkGuidance && (
                <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-3.5 text-left text-xs text-amber-800 dark:text-amber-300 flex items-start gap-3 max-w-md mx-auto">
                  <Lightbulb className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block font-bold">Socratic Homework Guidance is ON</strong>
                    Edu Buddy will guide your thinking step-by-step without doing the homework for you or encouraging cheating.
                  </div>
                </div>
              )}

              {/* Quick Topic Pills */}
              <div className="space-y-2 pt-2">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Try asking about:
                </div>
                <div className="flex flex-wrap justify-center gap-2">
                  {quickTopicPills.map((pill, idx) => (
                    <button
                      key={idx}
                      onClick={() => setInputMsg(pill)}
                      className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-emerald-500/10 dark:hover:bg-emerald-500/10 hover:border-emerald-500/30 border border-slate-200 dark:border-slate-700/80 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 transition text-left"
                    >
                      {pill}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* Render Message Bubbles */
            messages.map((msg) => {
              const isAi = msg.sender === 'ai';
              return (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex items-start gap-3 sm:gap-4 max-w-3xl ${!isAi ? 'ml-auto flex-row-reverse' : ''}`}
                >
                  {/* Avatar */}
                  <div className={`w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 font-bold text-sm shadow-md ${
                    isAi 
                      ? 'bg-gradient-to-tr from-emerald-500 to-teal-400 text-[#0A2540]' 
                      : 'bg-slate-800 dark:bg-white text-white dark:text-slate-900'
                  }`}>
                    {isAi ? <Bot className="w-5 h-5" /> : <User className="w-5 h-5" />}
                  </div>

                  {/* Bubble Content */}
                  <div className={`flex-1 min-w-0 rounded-3xl p-4 sm:p-5 shadow-sm border ${
                    isAi 
                      ? 'bg-white dark:bg-slate-800/90 border-slate-200 dark:border-slate-700/80 text-slate-800 dark:text-slate-100 rounded-tl-none' 
                      : 'bg-gradient-to-tr from-[#0A2540] to-slate-900 text-white border-slate-800 rounded-tr-none'
                  }`}>
                    {/* Top metadata row for AI messages */}
                    {isAi && (
                      <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-100 dark:border-slate-700/60 text-xs text-slate-400">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-emerald-600 dark:text-emerald-400">Edu Buddy AI</span>
                          <span className="bg-slate-100 dark:bg-slate-700/80 px-2 py-0.5 rounded-full text-[10px] font-bold text-slate-600 dark:text-slate-300">
                            {msg.explanation_mode || explanationMode}
                          </span>
                        </div>

                        {/* Bookmark / Action button */}
                        <button
                          onClick={() => handleBookmarkMessage(msg.id, msg.content)}
                          className={`flex items-center gap-1 px-2 py-1 rounded-lg transition ${
                            msg.is_bookmarked === 1
                              ? 'text-amber-500 bg-amber-500/10 font-bold'
                              : 'text-slate-400 hover:text-emerald-500 hover:bg-slate-100 dark:hover:bg-slate-700'
                          }`}
                          title="Save this explanation to Bookmarks"
                        >
                          <Bookmark className={`w-3.5 h-3.5 ${msg.is_bookmarked === 1 ? 'fill-amber-500' : ''}`} />
                          <span>{msg.is_bookmarked === 1 ? 'Saved' : 'Bookmark'}</span>
                        </button>
                      </div>
                    )}

                    {/* Markdown / Text body */}
                    <div className="prose prose-sm dark:prose-invert max-w-none leading-relaxed break-words">
                      <ReactMarkdown>{msg.content}</ReactMarkdown>
                    </div>
                  </div>
                </motion.div>
              );
            })
          )}

          {/* Typing indicator */}
          {isThinking && (
            <div className="flex items-center gap-3 max-w-3xl animate-fadeIn">
              <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-[#0A2540] flex items-center justify-center font-bold shadow-md">
                <Bot className="w-5 h-5 animate-spin" style={{ animationDuration: '3s' }} />
              </div>
              <div className="bg-white dark:bg-slate-800 rounded-3xl rounded-tl-none p-4 border border-slate-200 dark:border-slate-700/80 shadow-sm flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                  Edu Buddy is structuring a {explanationMode} explanation for {subject}...
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input Bar */}
        <footer className="p-4 border-t border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md shrink-0">
          <form onSubmit={handleSendMessage} className="max-w-4xl mx-auto flex items-center gap-3">
            <div className="flex-1 relative">
              <input
                type="text"
                value={inputMsg}
                onChange={(e) => setInputMsg(e.target.value)}
                placeholder={`Ask a question or paste your homework problem for ${subject}...`}
                disabled={isThinking}
                className="w-full pl-4 pr-10 py-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 text-sm text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition disabled:opacity-50"
              />
              {isHomeworkGuidance && (
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-extrabold uppercase bg-amber-500/20 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded-md pointer-events-none">
                  Socratic Guide
                </span>
              )}
            </div>

            <button
              type="submit"
              disabled={!inputMsg.trim() || isThinking}
              className="px-5 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-[#0A2540] font-extrabold text-sm shadow-lg shadow-emerald-500/20 flex items-center gap-2 transition transform active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
            >
              <span>Send</span>
              <Send className="w-4 h-4" />
            </button>
          </form>
        </footer>
      </main>
    </div>
  );

  // Helper to render conversation list item in sidebar
  function renderConvItem(c: AIChatConversation) {
    const isActive = activeConvId === c.id;
    const isEditing = editingTitleId === c.id;

    return (
      <div
        key={c.id}
        onClick={() => {
          if (!isEditing) setActiveConvId(c.id);
        }}
        className={`group relative flex items-center justify-between p-3 rounded-2xl cursor-pointer transition text-xs font-bold ${
          isActive 
            ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 shadow-sm' 
            : 'hover:bg-slate-100 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300 border border-transparent'
        }`}
      >
        <div className="flex items-center gap-2.5 min-w-0 flex-1">
          <MessageSquare className={`w-4 h-4 shrink-0 ${isActive ? 'text-emerald-500' : 'text-slate-400'}`} />
          {isEditing ? (
            <input
              type="text"
              value={newTitleText}
              onChange={(e) => setNewTitleText(e.target.value)}
              onBlur={() => handleRenameSave(c.id)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleRenameSave(c.id);
              }}
              autoFocus
              onClick={(e) => e.stopPropagation()}
              className="w-full px-2 py-1 rounded bg-white dark:bg-slate-800 border border-emerald-500 text-xs text-slate-900 dark:text-white focus:outline-none"
            />
          ) : (
            <span className="truncate">{c.title || 'Untitled Session'}</span>
          )}
        </div>

        {/* Action icons on hover */}
        {!isEditing && (
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition shrink-0 ml-1">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setEditingTitleId(c.id);
                setNewTitleText(c.title || '');
              }}
              className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 hover:text-white"
              title="Rename chat"
            >
              <Edit2 className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={(e) => handleTogglePin(c.id, c.is_pinned, e)}
              className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 hover:text-emerald-500"
              title={c.is_pinned === 1 ? "Unpin chat" : "Pin chat"}
            >
              {c.is_pinned === 1 ? <PinOff className="w-3.5 h-3.5 text-emerald-500" /> : <Pin className="w-3.5 h-3.5" />}
            </button>

            <button
              onClick={(e) => handleDeleteConversation(c.id, e)}
              className="p-1 rounded hover:bg-rose-500/20 text-slate-400 hover:text-rose-500"
              title="Delete chat"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    );
  }
};
