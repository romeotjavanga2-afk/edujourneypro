import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, MessageSquare, Brain, Layers, FileText, 
  Home, Settings, Flame, Trophy, ShieldCheck, 
  ArrowLeft, Check, X, Bot, Heart, User, CheckCircle2 
} from 'lucide-react';
import { AIHomeScreen } from './AIHomeScreen.js';
import { AIChatScreen } from './AIChatScreen.js';
import { AIQuizGenerator } from './AIQuizGenerator.js';
import { AIFlashcardsScreen } from './AIFlashcardsScreen.js';
import { AISummaryTool } from './AISummaryTool.js';

interface EduBuddyAIViewProps {
  onBackToDashboard: () => void;
  initialTab?: 'home' | 'chat' | 'quizzes' | 'flashcards' | 'summary';
}

export const EduBuddyAIView: React.FC<EduBuddyAIViewProps> = ({
  onBackToDashboard,
  initialTab = 'home'
}) => {
  const [activeTab, setActiveTab] = useState<'home' | 'chat' | 'quizzes' | 'flashcards' | 'summary'>(initialTab);
  const [homeData, setHomeData] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isPreferencesOpen, setIsPreferencesOpen] = useState<boolean>(false);

  // Cross-tab prompt transfer state
  const [chatSubject, setChatSubject] = useState<string>('Mathematics');
  const [chatPrompt, setChatPrompt] = useState<string>('');

  // Preferences form state for modal
  const [prefAvatar, setPrefAvatar] = useState<string>('robot-1');
  const [prefGreeting, setPrefGreeting] = useState<string>('Ready to master your goals today?');
  const [prefStyle, setPrefStyle] = useState<string>('Friendly');
  const [prefLearningStyle, setPrefLearningStyle] = useState<string>('Visual & Step-by-Step');
  const [prefWeakTopics, setPrefWeakTopics] = useState<string>('Quadratic Word Problems, Newton Second Law Graphing');
  const [isSavingPref, setIsSavingPref] = useState<boolean>(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  const fetchHomeData = useCallback(async () => {
    try {
      const res = await fetch('/api/edubuddy/home');
      const json = await res.json();
      if (json.success && json.data) {
        setHomeData(json.data);
        if (json.data.preferences) {
          setPrefAvatar(json.data.preferences.avatar || 'robot-1');
          setPrefGreeting(json.data.preferences.greeting || 'Ready to master your goals today?');
          setPrefStyle(json.data.preferences.conversation_style || 'Friendly');
        }
        if (json.data.memory) {
          setPrefLearningStyle(json.data.memory.preferred_learning_style || 'Visual & Step-by-Step');
          const topics = Array.isArray(json.data.memory.weak_topics) ? json.data.memory.weak_topics.join(', ') : json.data.memory.weak_topics;
          if (topics) setPrefWeakTopics(topics);
        }
        setLoading(false);
        return;
      }
    } catch (e) {
      console.warn("Offline Edu Buddy Home load fallback:", e);
    }

    // Offline heuristic fallback data
    setHomeData({
      studentName: 'Scholar',
      dailyMotivation: "Success is the sum of small efforts repeated day in and day out. Let's make today count!",
      currentStudyGoal: "Master Quadratic Equations & Physics Lab Data",
      learningStreak: 7,
      xpTotal: 2450,
      preferences: { avatar: 'robot-1', greeting: 'Ready to master your goals today?', conversation_style: 'Friendly' },
      memory: { preferred_learning_style: 'Visual & Step-by-Step', weak_topics: ['Quadratic Word Problems', 'Newton Second Law Graphing'] },
      quickSuggestions: [
        { title: "Continue Mathematics", subtitle: "Quadratic Formula Ex 42 Q9-15", icon: "📐", action: "chat", subject: "Mathematics", prompt: "Let's continue working on Quadratic Equations Ex 42. Can you guide me through question 9?" },
        { title: "Revise Biology & Science", subtitle: "Newton's Second Law & Lab Report", icon: "⚡", action: "chat", subject: "Physical Science", prompt: "Can you review Newton's Second Law with me and check my understanding of force vs acceleration graphs?" }
      ]
    });
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchHomeData();
  }, [fetchHomeData]);

  const handleStartChatWithPrompt = (subject: string, promptText: string) => {
    setChatSubject(subject);
    setChatPrompt(promptText);
    setActiveTab('chat');
  };

  const handleSavePreferences = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingPref(true);
    setSaveSuccessMsg(null);

    try {
      await fetch('/api/edubuddy/preferences', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ avatar: prefAvatar, greeting: prefGreeting, conversation_style: prefStyle })
      });

      const weakArr = prefWeakTopics.split(',').map(s => s.trim()).filter(Boolean);
      await fetch('/api/edubuddy/memory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ preferred_learning_style: prefLearningStyle, weak_topics: weakArr })
      });

      fetchHomeData();
      setSaveSuccessMsg("AI Personality & Memory profile updated!");
      setTimeout(() => {
        setIsPreferencesOpen(false);
        setSaveSuccessMsg(null);
      }, 1500);
    } catch (e) {
      setSaveSuccessMsg("Saved changes offline!");
      setTimeout(() => setIsPreferencesOpen(false), 1200);
    } finally {
      setIsSavingPref(false);
    }
  };

  const navTabs = [
    { id: 'home' as const, label: 'Mentor Home', icon: Home },
    { id: 'chat' as const, label: 'AI Tutoring Chat', icon: MessageSquare, badge: 'Socratic' },
    { id: 'quizzes' as const, label: 'Quiz Generator', icon: Brain, badge: 'XP Bonus' },
    { id: 'flashcards' as const, label: 'Flashcard Review', icon: Layers },
    { id: 'summary' as const, label: 'Note Summarizer', icon: FileText },
  ];

  const avatarsList = [
    { id: 'robot-1', icon: '🤖', name: 'Emerald Robot', desc: 'Friendly & modern AI tutor' },
    { id: 'cyber-owl', icon: '🦉', name: 'Cyber Owl', desc: 'Wise & observant mentor' },
    { id: 'astro-guide', icon: '👩‍🚀', name: 'Astro Guide', desc: 'Explores science & cosmos' },
    { id: 'safari-cheetah', icon: '🐆', name: 'Safari Cheetah', desc: 'Fast problem solver' },
    { id: 'quantum-leopard', icon: '🐯', name: 'Quantum Leopard', desc: 'Bold & strategic thinker' },
    { id: 'digital-mentor', icon: '🌟', name: 'Spark Mentor', desc: 'Positive & encouraging' }
  ];

  if (loading) {
    return (
      <div className="min-h-[500px] flex flex-col items-center justify-center p-8 text-center space-y-4">
        <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-1 animate-spin shadow-xl">
          <div className="w-full h-full bg-[#0A2540] rounded-[22px]" />
        </div>
        <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
          Waking up Edu Buddy AI Companion...
        </h2>
        <p className="text-xs text-slate-500 max-w-sm">
          Synchronizing your memory profile, NSSCO learning streaks, and custom quiz suite
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Top Banner & Navigation Tabs Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        
        {/* Left: Title & Back */}
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToDashboard}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300 transition shrink-0"
            title="Back to Dashboard Home"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-500 text-[#0A2540] flex items-center justify-center font-bold text-xl shadow-md shadow-emerald-500/20 shrink-0">
            <Sparkles className="w-6 h-6 animate-spin" style={{ animationDuration: '8s' }} />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-base sm:text-lg text-slate-900 dark:text-white leading-none">
                Edu Buddy AI Workspace
              </h1>
              <span className="text-[10px] font-black uppercase tracking-wider bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                Phase 5 Suite
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Your intelligent secondary school study companion & assessment generator
            </p>
          </div>
        </div>

        {/* Right: Sub-nav Tab Switchers */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 no-scrollbar">
          {navTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative px-3.5 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-2 whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-[#0A2540] dark:bg-emerald-500 text-white dark:text-[#0A2540] shadow-md shadow-slate-900/10'
                    : 'bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400 dark:text-[#0A2540]' : ''}`} />
                <span>{tab.label}</span>
                {tab.badge && !isActive && (
                  <span className="text-[9px] bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-1.5 py-0.2 rounded font-bold">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ACTIVE SCREEN RENDERING */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.2 }}
        >
          {activeTab === 'home' && (
            <AIHomeScreen
              data={homeData}
              onNavigate={(tab) => setActiveTab(tab)}
              onStartChatWithPrompt={handleStartChatWithPrompt}
              onOpenPreferences={() => setIsPreferencesOpen(true)}
            />
          )}

          {activeTab === 'chat' && (
            <AIChatScreen
              initialSubject={chatSubject}
              initialPrompt={chatPrompt}
              onClearInitialPrompt={() => setChatPrompt('')}
              preferences={homeData?.preferences || {}}
            />
          )}

          {activeTab === 'quizzes' && (
            <AIQuizGenerator
              onBackToHome={() => setActiveTab('home')}
              onAskBuddyAboutQuestion={(subj, qText) => handleStartChatWithPrompt(subj, qText)}
            />
          )}

          {activeTab === 'flashcards' && (
            <AIFlashcardsScreen
              onBackToHome={() => setActiveTab('home')}
              onAskBuddyAboutConcept={(subj, cText) => handleStartChatWithPrompt(subj, cText)}
            />
          )}

          {activeTab === 'summary' && (
            <AISummaryTool
              onBackToHome={() => setActiveTab('home')}
              onConvertToFlashcards={(subj, topic) => {
                setActiveTab('flashcards');
              }}
              onAskBuddyAboutSummary={(subj, prompt) => handleStartChatWithPrompt(subj, prompt)}
            />
          )}
        </motion.div>
      </AnimatePresence>

      {/* AI PERSONALITY & PREFERENCES MODAL */}
      {isPreferencesOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto my-auto"
          >
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                  <Settings className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
                    Customize Edu Buddy Personality & Memory
                  </h3>
                  <p className="text-xs text-slate-500">
                    Personalize your tutor's avatar, voice, and learning style adaptations
                  </p>
                </div>
              </div>
              <button onClick={() => setIsPreferencesOpen(false)} className="text-slate-400 hover:text-white p-2 rounded-lg">
                ✕
              </button>
            </div>

            <form onSubmit={handleSavePreferences} className="space-y-6">
              
              {/* 1. Choose Avatar */}
              <div>
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
                  Select AI Companion Avatar
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {avatarsList.map((av) => {
                    const isSel = prefAvatar === av.id;
                    return (
                      <div
                        key={av.id}
                        onClick={() => setPrefAvatar(av.id)}
                        className={`p-3.5 rounded-2xl border cursor-pointer transition flex items-center gap-3 ${
                          isSel 
                            ? 'bg-emerald-500/10 border-emerald-500 dark:border-emerald-400 shadow-sm' 
                            : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 hover:border-emerald-500/40'
                        }`}
                      >
                        <span className="text-2xl sm:text-3xl shrink-0">{av.icon}</span>
                        <div className="min-w-0">
                          <div className="font-extrabold text-xs text-slate-900 dark:text-white truncate">
                            {av.name}
                          </div>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                            {av.desc}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 2. Conversation Style & Greeting */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-2">
                    Conversation Style
                  </label>
                  <select
                    value={prefStyle}
                    onChange={(e) => setPrefStyle(e.target.value)}
                    className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800 border text-sm font-bold text-slate-800 dark:text-slate-100"
                  >
                    <option value="Friendly">🌟 Friendly & Encouraging</option>
                    <option value="Socratic Teacher">🎓 Socratic Teacher (Guiding)</option>
                    <option value="Exam Focused">👑 Exam Focused (NSSCO Criteria)</option>
                    <option value="Fun & Casual">🎈 Fun & Casual (Everyday Analogies)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-2">
                    Preferred Learning Style
                  </label>
                  <select
                    value={prefLearningStyle}
                    onChange={(e) => setPrefLearningStyle(e.target.value)}
                    className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800 border text-sm font-bold text-slate-800 dark:text-slate-100"
                  >
                    <option value="Visual & Step-by-Step">📊 Visual & Step-by-Step</option>
                    <option value="Detailed & Theoretical">🔬 Detailed & Theoretical</option>
                    <option value="Practice-Oriented">⚡ Practice & Drill Focused</option>
                    <option value="Simple & Direct">🎯 Concise & Direct Answers</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-2">
                  Custom Daily Greeting Message
                </label>
                <input
                  type="text"
                  value={prefGreeting}
                  onChange={(e) => setPrefGreeting(e.target.value)}
                  placeholder="e.g. Ready to master your goals today?"
                  required
                  className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800 border text-sm font-semibold text-slate-800 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-1">
                  Target Weak Topics (Comma separated)
                </label>
                <p className="text-[11px] text-slate-400 mb-2">
                  Edu Buddy will proactively suggest practice quizzes and study starters on these topics
                </p>
                <input
                  type="text"
                  value={prefWeakTopics}
                  onChange={(e) => setPrefWeakTopics(e.target.value)}
                  placeholder="e.g. Quadratic Word Problems, Newton Second Law Graphing, Python Lists"
                  className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-800 border text-sm font-semibold text-slate-800 dark:text-slate-100"
                />
              </div>

              {saveSuccessMsg && (
                <div className="p-3.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>{saveSuccessMsg}</span>
                </div>
              )}

              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsPreferencesOpen(false)}
                  className="px-5 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingPref}
                  className="px-8 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-[#0A2540] font-extrabold text-xs shadow-md flex items-center gap-2"
                >
                  {isSavingPref ? <Sparkles className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4 stroke-[3]" />}
                  <span>{isSavingPref ? 'Saving Profile...' : 'Save AI Personality'}</span>
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

    </div>
  );
};
