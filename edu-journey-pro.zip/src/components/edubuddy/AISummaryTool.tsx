import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  FileText, Sparkles, Copy, Check, Bookmark, Layers, 
  ArrowRight, ShieldCheck, Zap, RefreshCw, BookOpen, HelpCircle 
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface AISummaryToolProps {
  onBackToHome: () => void;
  onConvertToFlashcards: (subject: string, topic: string) => void;
  onAskBuddyAboutSummary: (subject: string, prompt: string) => void;
}

export const AISummaryTool: React.FC<AISummaryToolProps> = ({
  onBackToHome,
  onConvertToFlashcards,
  onAskBuddyAboutSummary
}) => {
  const [subject, setSubject] = useState<string>('Mathematics');
  const [format, setFormat] = useState<string>('Revision Notes');
  const [notesText, setNotesText] = useState<string>('');
  const [summaryOutput, setSummaryOutput] = useState<string>('');
  const [wordCountInput, setWordCountInput] = useState<number>(0);
  const [wordCountOutput, setWordCountOutput] = useState<number>(0);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const subjectsList = [
    'Mathematics', 'Physical Science', 'Computer Studies', 
    'English First Language', 'Geography', 'History', 'General'
  ];

  const formats = [
    { id: 'Revision Notes', label: '📝 Comprehensive Revision Notes', desc: 'Structured summary with headers and key takeaways' },
    { id: 'Bullet Points', label: '📌 High-Yield Bullet Points', desc: 'Quick scannable bullet lists for rapid review' },
    { id: 'Key Concepts', label: '🔑 Core Principles & Derivations', desc: 'Deep dive into fundamental laws and theory' },
    { id: 'Important Definitions', label: '📖 Glossary & Definitions Table', desc: 'Table format of exact NSSCO terms to memorize' },
    { id: 'Mind Map Outline', label: '🧠 Mind Map Structural Outline', desc: 'Hierarchical visual ASCII tree outline' },
  ];

  const sampleNotes = `In mathematics, a quadratic equation is a second-order polynomial equation in a single variable x ax^2 + bx + c = 0 with a != 0. Because it is a second-order polynomial equation, the fundamental theorem of algebra guarantees that it has two solutions. These solutions may be both real, or both complex. The discriminant Delta = b^2 - 4ac determines the nature of the roots. When Delta > 0, there are two distinct real roots. When Delta = 0, there is exactly one repeated real root, meaning the parabola touches the x axis at its vertex. When Delta < 0, there are no real roots, and the parabola sits completely above or below the x axis. In physical science trolley experiments, friction compensation is critical: you tilt the runway slightly until the trolley moves at a constant velocity without applied pulling force, balancing friction with gravity.`;

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setNotesText(val);
    const words = val.trim() ? val.trim().split(/\s+/).length : 0;
    setWordCountInput(words);
    setErrorMsg(null);
  };

  const handleGenerateSummary = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notesText.trim() || isGenerating) return;

    if (wordCountInput < 10) {
      setErrorMsg("Please paste at least 10 words of study notes or lecture text to generate a meaningful summary.");
      return;
    }

    setIsGenerating(true);
    setErrorMsg(null);
    setIsSaved(false);

    try {
      const res = await fetch('/api/edubuddy/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notes_text: notesText, format, subject })
      });
      const json = await res.json();
      if (json.success && json.data) {
        setSummaryOutput(json.data.summary);
        const outWords = json.data.summary.trim().split(/\s+/).length;
        setWordCountOutput(outWords);
      } else {
        setErrorMsg(json.error || "Failed to generate summary.");
      }
    } catch (err) {
      setErrorMsg("Offline summarization fallback active. Check network connection.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = () => {
    if (!summaryOutput) return;
    navigator.clipboard.writeText(summaryOutput);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  const handleSaveToBookmarks = async () => {
    if (!summaryOutput || isSaved) return;
    try {
      const snippet = summaryOutput.length > 80 ? summaryOutput.substring(0, 80) + '...' : summaryOutput;
      await fetch('/api/edubuddy/bookmarks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: `${subject} Summary (${format})`,
          snippet,
          category: subject
        })
      });
      setIsSaved(true);
    } catch (e) {}
  };

  return (
    <div className="space-y-6 pb-12 animate-fadeIn">
      
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 text-white flex items-center justify-center shadow-lg shadow-amber-500/20">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Study Note Summarizer</span>
              <span className="text-xs bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 px-2.5 py-0.5 rounded-full font-extrabold">
                Exam Prep
              </span>
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Transform messy lecture notes, textbook chapters, or drafts into structured NSSCO revision points
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            setNotesText(sampleNotes);
            setWordCountInput(sampleNotes.split(/\s+/).length);
          }}
          className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-extrabold text-xs transition flex items-center gap-1.5 shrink-0"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
          <span>Load Sample Notes</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* LEFT COL: INPUT & FORMAT SETUP */}
        <div className="bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-md space-y-6 flex flex-col justify-between">
          <form onSubmit={handleGenerateSummary} className="space-y-6">
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                  Subject
                </label>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-4 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  {subjectsList.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                  Summary Output Format
                </label>
                <select
                  value={format}
                  onChange={(e) => setFormat(e.target.value)}
                  className="w-full px-4 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  {formats.map(f => <option key={f.id} value={f.id}>{f.label}</option>)}
                </select>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Paste Study Notes or Lecture Transcript
                </label>
                <span className={`text-xs font-bold ${wordCountInput < 10 ? 'text-slate-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                  {wordCountInput} Words
                </span>
              </div>

              <textarea
                value={notesText}
                onChange={handleTextChange}
                rows={10}
                placeholder="Paste your classroom notes, textbook summaries, or lecture transcripts here... Edu Buddy will extract the key ideas and format them for easy study!"
                required
                className="w-full p-4 rounded-2xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500 leading-relaxed"
              />
            </div>

            {errorMsg && (
              <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-semibold">
                {errorMsg}
              </div>
            )}

            <button
              type="submit"
              disabled={isGenerating || !notesText.trim()}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 hover:from-amber-400 hover:to-orange-400 text-white font-extrabold text-base shadow-xl shadow-orange-500/25 flex items-center justify-center gap-3 transition transform active:scale-98 disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <Sparkles className="w-5 h-5 animate-spin" />
                  <span>Synthesizing Study Notes...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  <span>Generate Structured AI Summary</span>
                </>
              )}
            </button>
          </form>

          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Supports up to 5,000 words</span>
            <span className="flex items-center gap-1 font-semibold text-emerald-600 dark:text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>NSSCO Exam Aligned</span>
            </span>
          </div>
        </div>

        {/* RIGHT COL: GENERATED OUTPUT */}
        <div className="bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-md flex flex-col justify-between min-h-[500px]">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 mb-4">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
                  ✨
                </span>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                    {format} Output
                  </h3>
                  {summaryOutput && (
                    <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                      Reduced {wordCountInput} words → {wordCountOutput} key points ({Math.round((1 - wordCountOutput/Math.max(1,wordCountInput))*100)}% lighter)
                    </span>
                  )}
                </div>
              </div>

              {/* Top output actions */}
              {summaryOutput && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 transition"
                    title="Copy to clipboard"
                  >
                    {isCopied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                  </button>

                  <button
                    onClick={handleSaveToBookmarks}
                    disabled={isSaved}
                    className={`p-2 rounded-xl transition ${
                      isSaved ? 'bg-amber-500/15 text-amber-500 font-bold' : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:text-amber-500'
                    }`}
                    title="Save summary to Bookmarks"
                  >
                    <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-amber-500' : ''}`} />
                  </button>
                </div>
              )}
            </div>

            {/* Output markdown stream */}
            {!summaryOutput ? (
              <div className="text-center py-24 space-y-3 text-slate-400">
                <FileText className="w-16 h-16 mx-auto stroke-1 text-slate-300 dark:text-slate-700 animate-pulse" />
                <h4 className="font-extrabold text-base text-slate-600 dark:text-slate-400">No Summary Generated Yet</h4>
                <p className="text-xs max-w-xs mx-auto text-slate-500">
                  Paste your notes on the left and select an output format to see your AI-synthesized revision guide appear here!
                </p>
              </div>
            ) : (
              <div className="prose prose-sm dark:prose-invert max-w-none leading-relaxed overflow-y-auto max-h-[450px] pr-2">
                <ReactMarkdown>{summaryOutput}</ReactMarkdown>
              </div>
            )}
          </div>

          {/* Bottom Conversion Actions */}
          {summaryOutput && (
            <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <button
                onClick={() => onConvertToFlashcards(subject, `${subject} Summary (${format})`)}
                className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-extrabold text-xs shadow-md transition flex items-center gap-2"
              >
                <Layers className="w-4 h-4" />
                <span>Convert to Flashcards</span>
              </button>

              <button
                onClick={() => onAskBuddyAboutSummary(subject, `I just summarized my ${subject} notes on: "${notesText.substring(0, 100)}...". Can you test my understanding with a Socratic question?`)}
                className="px-4 py-2.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 font-extrabold text-xs transition flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>Ask Buddy to Test Me</span>
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
