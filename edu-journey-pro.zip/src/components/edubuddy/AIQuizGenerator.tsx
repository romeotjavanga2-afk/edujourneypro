import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Brain, Sparkles, CheckCircle2, XCircle, ArrowRight, 
  RotateCcw, Trophy, HelpCircle, ShieldCheck, Clock, 
  BookOpen, Plus, Flame, Award, ChevronRight, AlertCircle 
} from 'lucide-react';
import { AIQuiz, AIQuizQuestion } from '../../types.js';

interface AIQuizGeneratorProps {
  onBackToHome: () => void;
  onAskBuddyAboutQuestion: (subject: string, questionText: string) => void;
}

export const AIQuizGenerator: React.FC<AIQuizGeneratorProps> = ({
  onBackToHome,
  onAskBuddyAboutQuestion
}) => {
  const [quizzes, setQuizzes] = useState<AIQuiz[]>([]);
  const [activeQuiz, setActiveQuiz] = useState<AIQuiz | null>(null);
  const [questions, setQuestions] = useState<AIQuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<{ [key: number]: number }>({});
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [scorePercent, setScorePercent] = useState<number>(0);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'create' | 'play' | 'review' | 'list'>('create');

  // Form State
  const [subject, setSubject] = useState<string>('Mathematics');
  const [topic, setTopic] = useState<string>('Quadratic Equations & Functions');
  const [difficulty, setDifficulty] = useState<string>('Medium');
  const [questionType, setQuestionType] = useState<string>('Multiple Choice');
  const [count, setCount] = useState<number>(5);

  const subjectsList = [
    'Mathematics', 'Physical Science', 'Computer Studies', 
    'English First Language', 'Geography', 'History'
  ];

  const difficulties = [
    { id: 'Easy', label: '🟢 Easy (Core Recall)', desc: 'Basic definitions and introductory formulas' },
    { id: 'Medium', label: '🟡 Medium (Application)', desc: 'Standard NSSCO Paper 1 calculation questions' },
    { id: 'Hard', label: '🟠 Hard (Analysis & Word Problems)', desc: 'Multi-step structured scenarios' },
    { id: 'Exam Level', label: '👑 Exam Level (NSSCO Standard)', desc: 'Rigorous national exam style questions with traps' },
  ];

  const loadQuizzes = async () => {
    try {
      const res = await fetch('/api/edubuddy/quizzes');
      const json = await res.json();
      if (json.success) {
        setQuizzes(json.data);
      }
    } catch (e) {
      console.warn("Failed to load quizzes offline:", e);
    }
  };

  useEffect(() => {
    loadQuizzes();
  }, []);

  const handleGenerateQuiz = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;

    setIsGenerating(true);
    try {
      const res = await fetch('/api/edubuddy/quizzes/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject, topic, difficulty, question_type: questionType, count })
      });
      const json = await res.json();
      if (json.success && json.data) {
        const newQ = json.data;
        setQuizzes([newQ, ...quizzes]);
        setActiveQuiz(newQ);
        const parsed: AIQuizQuestion[] = typeof newQ.questions_json === 'string' 
          ? JSON.parse(newQ.questions_json) 
          : (newQ.questions_json || []);
        setQuestions(parsed);
        setCurrentIndex(0);
        setSelectedAnswers({});
        setIsSubmitted(false);
        setViewMode('play');
      }
    } catch (err) {
      console.error("Quiz gen error:", err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSelectOption = (qIdx: number, optIdx: number) => {
    if (isSubmitted) return;
    setSelectedAnswers(prev => ({ ...prev, [qIdx]: optIdx }));
  };

  const handleSubmitQuiz = async () => {
    let correct = 0;
    questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.answer) {
        correct++;
      }
    });

    const percent = Math.round((correct / questions.length) * 100);
    setScorePercent(percent);
    setIsSubmitted(true);
    setViewMode('review');

    if (activeQuiz) {
      try {
        await fetch(`/api/edubuddy/quizzes/${activeQuiz.id}/submit`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ score: percent })
        });
        loadQuizzes();
      } catch (e) {}
    }
  };

  const currentQ = questions[currentIndex];

  return (
    <div className="space-y-6 pb-12 animate-fadeIn">
      
      {/* Top Banner & Mode Switcher */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-500 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Brain className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Interactive Quiz Suite</span>
              <span className="text-xs bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 px-2.5 py-0.5 rounded-full font-extrabold">
                AI Powered
              </span>
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Generate custom practice assessments with instant Socratic feedback
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => setViewMode('create')}
            className={`flex-1 sm:flex-initial px-4 py-2.5 rounded-xl font-extrabold text-xs transition flex items-center justify-center gap-1.5 ${
              viewMode === 'create'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>New Quiz</span>
          </button>

          <button
            onClick={() => setViewMode('list')}
            className={`flex-1 sm:flex-initial px-4 py-2.5 rounded-xl font-extrabold text-xs transition flex items-center justify-center gap-1.5 ${
              viewMode === 'list'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Past Quizzes ({quizzes.length})</span>
          </button>
        </div>
      </div>

      {/* VIEW 1: CREATE FORM */}
      {viewMode === 'create' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-md space-y-6">
            <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
              <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-blue-500" />
                <span>Configure Your Practice Assessment</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Edu Buddy will formulate custom NSSCO-aligned questions tailored to your exact topic and difficulty.
              </p>
            </div>

            <form onSubmit={handleGenerateQuiz} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                    Subject
                  </label>
                  <select
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {subjectsList.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                    Number of Questions
                  </label>
                  <select
                    value={count}
                    onChange={(e) => setCount(Number(e.target.value))}
                    className="w-full px-4 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value={3}>3 Questions (Quick Check)</option>
                    <option value={5}>5 Questions (Standard Review)</option>
                    <option value={10}>10 Questions (Deep Assessment)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                  Topic or Syllabus Chapter
                </label>
                <input
                  type="text"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="e.g., Quadratic Word Problems, Newton's Second Law, Python Dictionaries..."
                  required
                  className="w-full px-4 py-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-semibold text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Difficulty Selection */}
              <div>
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                  Select Difficulty Level
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {difficulties.map((diff) => {
                    const isSel = difficulty === diff.id;
                    return (
                      <div
                        key={diff.id}
                        onClick={() => setDifficulty(diff.id)}
                        className={`p-4 rounded-2xl border cursor-pointer transition ${
                          isSel
                            ? 'bg-blue-500/10 border-blue-500 dark:border-blue-400 shadow-sm'
                            : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/80 hover:border-blue-500/40'
                        }`}
                      >
                        <div className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white flex items-center justify-between">
                          <span>{diff.label}</span>
                          {isSel && <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                          {diff.desc}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <button
                type="submit"
                disabled={isGenerating || !topic.trim()}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-extrabold text-base shadow-xl shadow-blue-500/25 flex items-center justify-center gap-3 transition transform active:scale-98 disabled:opacity-50"
              >
                {isGenerating ? (
                  <>
                    <Sparkles className="w-5 h-5 animate-spin" />
                    <span>Formulating {difficulty} Assessment...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" />
                    <span>Generate Interactive Quiz</span>
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Right Col Info / XP Rewards */}
          <div className="space-y-4">
            <div className="bg-gradient-to-br from-[#0A2540] to-slate-900 rounded-3xl p-6 text-white border border-slate-800 shadow-md space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-bold text-xl">
                🏆
              </div>
              <h3 className="text-lg font-extrabold text-white">
                Earn XP & Build Streaks!
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Completing custom AI assessments rewards you with direct XP bonuses and helps Edu Buddy identify your strong points!
              </p>

              <div className="space-y-2 pt-2 border-t border-slate-800 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Score 90% or higher:</span>
                  <span className="font-extrabold text-emerald-400">+150 XP</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Standard completion:</span>
                  <span className="font-extrabold text-blue-400">+100 XP</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Streak booster:</span>
                  <span className="font-extrabold text-amber-400">+1 Day</span>
                </div>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 text-xs space-y-3">
              <div className="font-extrabold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-500" />
                <span>NSSCO Exam Integrity</span>
              </div>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                Quizzes are designed strictly for self-assessment and practice. Edu Buddy will explain your mistakes in detail so you ace your real school tests!
              </p>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: PLAY QUIZ */}
      {viewMode === 'play' && questions.length > 0 && currentQ && (
        <div className="max-w-3xl mx-auto bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl space-y-6">
          
          {/* Top Progress bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-extrabold">
              <span className="text-blue-600 dark:text-blue-400 uppercase tracking-wider">
                Question {currentIndex + 1} of {questions.length}
              </span>
              <span className="text-slate-500 dark:text-slate-400">
                {activeQuiz?.title || topic}
              </span>
            </div>
            <div className="w-full h-2.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </div>

          {/* Question Title */}
          <div className="py-4">
            <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white leading-relaxed">
              {currentQ.question}
            </h2>
          </div>

          {/* Options Grid */}
          <div className="space-y-3">
            {(currentQ.options || ['True', 'False']).map((opt, optIdx) => {
              const isSelected = selectedAnswers[currentIndex] === optIdx;
              return (
                <div
                  key={optIdx}
                  onClick={() => handleSelectOption(currentIndex, optIdx)}
                  className={`p-4 sm:p-5 rounded-2xl border-2 cursor-pointer transition flex items-center justify-between ${
                    isSelected
                      ? 'bg-blue-500/10 border-blue-600 dark:border-blue-400 text-slate-900 dark:text-white font-bold shadow-md'
                      : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/80 text-slate-700 dark:text-slate-300 hover:border-blue-500/40'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-extrabold shrink-0 ${
                      isSelected 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                    }`}>
                      {String.fromCharCode(65 + optIdx)}
                    </span>
                    <span className="text-sm sm:text-base">{opt}</span>
                  </div>
                  {isSelected && <CheckCircle2 className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" />}
                </div>
              );
            })}
          </div>

          {/* Footer Controls */}
          <div className="pt-6 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4">
            <button
              type="button"
              disabled={currentIndex === 0}
              onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
              className="px-5 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold text-xs hover:bg-slate-200 dark:hover:bg-slate-700 transition disabled:opacity-40"
            >
              Previous
            </button>

            {currentIndex < questions.length - 1 ? (
              <button
                type="button"
                disabled={selectedAnswers[currentIndex] === undefined}
                onClick={() => setCurrentIndex(prev => Math.min(questions.length - 1, prev + 1))}
                className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs shadow-md shadow-blue-500/20 transition flex items-center gap-2 disabled:opacity-50"
              >
                <span>Next Question</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                disabled={selectedAnswers[currentIndex] === undefined}
                onClick={handleSubmitQuiz}
                className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-[#0A2540] font-extrabold text-sm shadow-lg shadow-emerald-500/25 transition flex items-center gap-2 disabled:opacity-50"
              >
                <Trophy className="w-4 h-4" />
                <span>Submit & View Score</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* VIEW 3: REVIEW RESULTS & EXPLANATIONS */}
      {viewMode === 'review' && questions.length > 0 && (
        <div className="max-w-4xl mx-auto space-y-6">
          
          {/* Score Banner */}
          <div className="bg-gradient-to-br from-[#0A2540] via-slate-900 to-blue-950 p-8 rounded-3xl text-white shadow-2xl border border-blue-500/30 text-center space-y-4">
            <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-amber-400 to-orange-500 text-[#0A2540] flex items-center justify-center text-4xl font-black mx-auto shadow-xl shadow-amber-500/30">
              {scorePercent >= 80 ? '👑' : scorePercent >= 60 ? '🌟' : '📚'}
            </div>
            <div>
              <h2 className="text-3xl font-black text-white">
                {scorePercent >= 80 ? 'Outstanding Mastery!' : scorePercent >= 60 ? 'Great Effort!' : 'Keep Practicing!'}
              </h2>
              <p className="text-sm text-slate-300 mt-1">
                You scored <strong className="text-emerald-400 font-extrabold text-lg">{scorePercent}%</strong> on {activeQuiz?.title || topic}
              </p>
            </div>

            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-full border border-white/15 text-xs font-bold text-emerald-300">
              <Award className="w-4 h-4" />
              <span>+100 Mentor XP Awarded!</span>
            </div>

            <div className="pt-4 flex flex-wrap justify-center gap-3">
              <button
                onClick={() => setViewMode('create')}
                className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs shadow-md transition flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Generate Another Quiz</span>
              </button>

              <button
                onClick={() => setViewMode('list')}
                className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-extrabold text-xs border border-white/15 transition"
              >
                View All Past Quizzes
              </button>
            </div>
          </div>

          {/* Detailed Question Review List */}
          <div className="space-y-4">
            <h3 className="text-lg font-extrabold text-slate-900 dark:text-white px-2">
              Detailed Question Analysis & Socratic Explanations
            </h3>

            {questions.map((q, idx) => {
              const userAns = selectedAnswers[idx];
              const isCorrect = userAns === q.answer;

              return (
                <div
                  key={q.id || idx}
                  className={`bg-white dark:bg-slate-900 p-6 rounded-3xl border shadow-sm space-y-4 transition ${
                    isCorrect 
                      ? 'border-emerald-500/40 dark:border-emerald-500/30' 
                      : 'border-rose-500/40 dark:border-rose-500/30'
                  }`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <span className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-black shrink-0 text-white ${
                        isCorrect ? 'bg-emerald-500' : 'bg-rose-500'
                      }`}>
                        {idx + 1}
                      </span>
                      <h4 className="font-extrabold text-base text-slate-900 dark:text-white pt-1">
                        {q.question}
                      </h4>
                    </div>

                    <span className={`px-3 py-1 rounded-full text-xs font-extrabold uppercase shrink-0 ${
                      isCorrect 
                        ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20' 
                        : 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20'
                    }`}>
                      {isCorrect ? 'Correct ✓' : 'Incorrect ✗'}
                    </span>
                  </div>

                  {/* Options display */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pl-11">
                    {(q.options || ['True', 'False']).map((opt, optIdx) => {
                      const isThisUserAns = userAns === optIdx;
                      const isThisCorrect = q.answer === optIdx;

                      return (
                        <div
                          key={optIdx}
                          className={`p-3 rounded-xl text-xs font-semibold flex items-center justify-between border ${
                            isThisCorrect
                              ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-800 dark:text-emerald-300 font-bold'
                              : isThisUserAns
                              ? 'bg-rose-500/10 border-rose-500/40 text-rose-800 dark:text-rose-300'
                              : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700/60 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold">{String.fromCharCode(65 + optIdx)}.</span>
                            <span>{opt}</span>
                          </div>
                          {isThisCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />}
                          {!isThisCorrect && isThisUserAns && <XCircle className="w-4 h-4 text-rose-500 shrink-0" />}
                        </div>
                      );
                    })}
                  </div>

                  {/* Edu Buddy Explanation Box */}
                  <div className="ml-11 p-4 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-xs text-slate-700 dark:text-slate-200 space-y-2">
                    <div className="font-extrabold text-blue-700 dark:text-blue-300 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-blue-500" />
                        <span>Edu Buddy Explanation Note</span>
                      </span>

                      <button
                        onClick={() => onAskBuddyAboutQuestion(activeQuiz?.subject || 'Mathematics', `Can you explain further why ${q.question} has answer option ${q.options?.[q.answer]}?`)}
                        className="text-emerald-600 dark:text-emerald-400 hover:underline font-bold flex items-center gap-1"
                      >
                        <span>Ask Tutor for deeper breakdown</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <p className="leading-relaxed font-medium">
                      {q.explanation || "Always check your intermediate calculations and verify that units match standard NSSCO requirements."}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 4: PAST QUIZZES LIST */}
      {viewMode === 'list' && (
        <div className="max-w-4xl mx-auto space-y-4">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
              Completed Practice Assessments ({quizzes.length})
            </h2>
            <button
              onClick={() => setViewMode('create')}
              className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-extrabold shadow-md hover:bg-blue-500 transition"
            >
              + Generate New Quiz
            </button>
          </div>

          {quizzes.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border border-slate-200 dark:border-slate-800 text-center space-y-3">
              <BookOpen className="w-12 h-12 text-slate-400 mx-auto" />
              <h3 className="font-extrabold text-base text-slate-800 dark:text-white">No quizzes generated yet</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">Create your first custom AI assessment above to start tracking your scores!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {quizzes.map((qz) => {
                const qArr: any[] = typeof qz.questions_json === 'string' ? JSON.parse(qz.questions_json) : (qz.questions_json || []);
                const score = qz.score !== undefined && qz.score >= 0 ? `${qz.score}%` : 'In Progress';
                
                return (
                  <div
                    key={qz.id}
                    onClick={() => {
                      setActiveQuiz(qz);
                      setQuestions(qArr);
                      setIsSubmitted(qz.score !== undefined && qz.score >= 0);
                      setScorePercent(qz.score >= 0 ? qz.score : 0);
                      setViewMode(qz.score >= 0 ? 'review' : 'play');
                    }}
                    className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-blue-500/40 hover:shadow-md cursor-pointer transition flex items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-4 min-w-0">
                      <div className="w-12 h-12 rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold shrink-0 text-lg">
                        🧠
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-extrabold uppercase bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded">
                            {qz.subject}
                          </span>
                          <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400">
                            {qz.difficulty}
                          </span>
                        </div>
                        <h4 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white truncate mt-1">
                          {qz.title}
                        </h4>
                        <div className="text-xs text-slate-400 mt-0.5">
                          {qArr.length} Questions • {qz.question_type}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className={`px-3 py-1.5 rounded-xl font-black text-xs ${
                        qz.score >= 80 ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400' :
                        qz.score >= 50 ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400' :
                        qz.score >= 0 ? 'bg-rose-500/15 text-rose-600 dark:text-rose-400' :
                        'bg-slate-100 dark:bg-slate-800 text-slate-500'
                      }`}>
                        {score}
                      </span>
                      <ChevronRight className="w-4 h-4 text-slate-400" />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
