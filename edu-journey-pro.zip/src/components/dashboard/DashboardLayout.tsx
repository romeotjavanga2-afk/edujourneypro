import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { DashboardData, DashboardNavTab } from '../../types.js';

// Layout shell components
import { TopNavbar } from './TopNavbar.js';
import { LeftSidebar } from './LeftSidebar.js';
import { BottomNavbar } from './BottomNavbar.js';

// Dashboard section components
import { WelcomeSection } from './WelcomeSection.js';
import { EduBuddyWelcomeCard } from './EduBuddyWelcomeCard.js';
import { TodaysOverview } from './TodaysOverview.js';
import { LearningProgress } from './LearningProgress.js';
import { QuickActions } from './QuickActions.js';
import { RecentActivity } from './RecentActivity.js';
import { UpcomingEvents } from './UpcomingEvents.js';
import { StudyPlannerPreview } from './StudyPlannerPreview.js';
import { AchievementsSection } from './AchievementsSection.js';
import { MotivationSection } from './MotivationSection.js';

// Views & Modals
import { SettingsView } from './SettingsView.js';
import { ComingSoonView } from './ComingSoonView.js';
import { AssignmentsView } from './AssignmentsView.js';
import { CalendarView } from './CalendarView.js';
import { StudyPlannerView } from './StudyPlannerView.js';
import { EduBuddyAIView } from '../edubuddy/EduBuddyAIView.js';
import { GlobalSearchModal } from './GlobalSearchModal.js';
import { EduBuddyQuickChatModal } from './EduBuddyQuickChatModal.js';
import { NotificationsPanel } from './NotificationsPanel.js';
import { OfflineCurriculumModal } from '../common/OfflineCurriculumModal.js';
import { OfflinePracticeQuizModal } from '../quiz/OfflinePracticeQuizModal.js';

export const DashboardLayout: React.FC = () => {
  const { user, activeDashboardTab = 'dashboard', setActiveDashboardTab } = useAuth();

  // Local shell UI states
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isOfflineHubOpen, setIsOfflineHubOpen] = useState(false);
  const [isPracticeQuizOpen, setIsPracticeQuizOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);

  // Default fallback data for seamless rendering
  const fallbackData: DashboardData = {
    user: user || { id: 1, email: 'student@edujourney.na', role: 'student', fullName: 'Tangi Amukwaya', grade: 'Grade 11', school: 'Delta Secondary School Windhoek', status: 'active', createdAt: new Date().toISOString(), isEmailVerified: true },
    eduBuddy: { aiName: 'Edu Buddy', aiAvatar: 'robot-emerald', greetingStyle: 'Let\'s conquer today\'s lessons!' },
    streak: { currentStreak: 7, longestStreak: 12, lastActivityDate: 'Today', xpTotal: 2450, badges: ['Early Bird', 'Math Whiz', 'Consistent Learner', 'AI Explorer'] },
    overview: { todaysAssignments: 3, studySessions: 2, upcomingEvents: 4, learningTimeMinutes: 165, completedTasks: 12, currentStreak: 7 },
    progress: [
      { id: 1, subject: 'Mathematics', progress: 84, trend: '+5% this week ↗', color: 'emerald', icon: '📐' },
      { id: 2, subject: 'Physical Science', progress: 78, trend: '+3% this week ↗', color: 'blue', icon: '🔬' },
      { id: 3, subject: 'English First Language', progress: 92, trend: '+4% this week ↗', color: 'purple', icon: '📚' },
      { id: 4, subject: 'Geography', progress: 88, trend: '+6% this week ↗', color: 'amber', icon: '🌍' },
      { id: 5, subject: 'History', progress: 74, trend: '+2% this week ↗', color: 'rose', icon: '🏛️' },
      { id: 6, subject: 'Computer Studies', progress: 95, trend: '+8% this week ↗', color: 'cyan', icon: '💻' }
    ],
    recentActivity: [
      { id: 1, activityType: 'quiz', title: 'Completed Practice Quiz', subtitle: 'Algebra Level 1 - 95% Score achieved', xpEarned: 150, timestamp: '2 hours ago' },
      { id: 2, activityType: 'session', title: 'Started Study Session', subtitle: '45m Physical Science revision session', xpEarned: 100, timestamp: 'Yesterday' },
      { id: 3, activityType: 'profile', title: 'Updated Profile', subtitle: 'Selected Mathematics & Science academic goals', xpEarned: 50, timestamp: '2 days ago' },
      { id: 4, activityType: 'school', title: 'Joined School', subtitle: 'Delta Secondary School Windhoek registry linked', xpEarned: 50, timestamp: '3 days ago' },
      { id: 5, activityType: 'edubuddy', title: 'Created Edu Buddy', subtitle: 'Configured Emerald Spark AI study mentor', xpEarned: 100, timestamp: '3 days ago' }
    ],
    upcomingEvents: [
      { id: 1, title: 'Algebra Polynomials Practice', type: 'Homework', subject: 'Mathematics', date: 'Tomorrow, 14:00', time: '14:00', badgeColor: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20' },
      { id: 2, title: 'NSSCO Mock Exam prep', type: 'Test', subject: 'Physical Science', date: 'Friday, 09:00', time: '09:00', badgeColor: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20' },
      { id: 3, title: 'Essay Submission: Modern Africa', type: 'Deadline', subject: 'English First Language', date: 'Next Monday', time: '23:59', badgeColor: 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20' },
      { id: 4, title: 'Windhoek High School Science Fair', type: 'School Event', subject: 'General', date: 'In 2 weeks', time: '10:00', badgeColor: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20' }
    ],
    plannerPreview: {
      todaysGoal: 'Complete 2 Mathematics practice quizzes & read Physical Science Chapter 4',
      timeTargetMinutes: 180,
      timeCompletedMinutes: 165,
      nextReminder: '16:30 - Physical Science Revision',
      weeklyGoalHours: 15,
      weeklyCompletedHours: 12.5
    },
    achievements: [
      { id: 1, title: '7-Day Learning Streak 🔥', description: 'Log in and study 7 days in a row without breaking streak', icon: '🔥', isLocked: false, progress: 7, maxProgress: 7, xp: 500 },
      { id: 2, title: 'Early Bird Learner 🌅', description: 'Complete a morning study session before 08:00 AM', icon: '🌅', isLocked: false, progress: 1, maxProgress: 1, xp: 250 },
      { id: 3, title: 'Math Whiz 📐', description: 'Achieve 90%+ on 5 consecutive Mathematics practice quizzes', icon: '📐', isLocked: false, progress: 5, maxProgress: 5, xp: 600 },
      { id: 4, title: 'Consistent Learner ⭐', description: 'Log at least 15 hours of study time in a single week', icon: '⭐', isLocked: false, progress: 12.5, maxProgress: 15, xp: 400 },
      { id: 5, title: '30-Day Master 🏆', description: 'Maintain an active learning streak for 30 consecutive days', icon: '🏆', isLocked: true, progress: 7, maxProgress: 30, xp: 1500 },
      { id: 6, title: 'Exam Conqueror 👑', description: 'Score Top 5% in all NSSCO national simulated mock assessments', icon: '👑', isLocked: true, progress: 2, maxProgress: 5, xp: 2000 }
    ],
    widgets: [
      { id: 1, widgetId: 'overview', title: "Today's Overview", isEnabled: true, position: 1 },
      { id: 2, widgetId: 'progress', title: 'Learning Progress', isEnabled: true, position: 2 },
      { id: 3, widgetId: 'actions', title: 'Quick Actions', isEnabled: true, position: 3 },
      { id: 4, widgetId: 'activity', title: 'Recent Activity', isEnabled: true, position: 4 },
      { id: 5, widgetId: 'upcoming', title: 'Upcoming Events', isEnabled: true, position: 5 },
      { id: 6, widgetId: 'planner', title: 'Study Planner Preview', isEnabled: true, position: 6 }
    ],
    notifications: [
      { id: 1, title: 'Welcome to Edu Journey Pro! 🎉', message: 'Your personal student dashboard and learning workspace is live and ready for action.', type: 'welcome', isRead: false, createdAt: 'Just now' },
      { id: 2, title: 'Student Profile Initialized ⭐', message: 'Your Namibian school registry profile at Delta Secondary School Windhoek is verified.', type: 'profile', isRead: false, createdAt: '1 hour ago' },
      { id: 3, title: 'Edu Buddy AI Ready 🤖', message: 'Emerald Spark is configured with motivational conversation style. Click Ask Edu Buddy anytime!', type: 'edubuddy', isRead: false, createdAt: '2 hours ago' }
    ],
    motivationalQuote: {
      quote: "One lesson today brings you closer to your dreams.",
      author: "Edu Journey Mentor"
    }
  };

  const fetchDashboardData = useCallback(async () => {
    try {
      const res = await fetch('/api/dashboard');
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          setDashboardData(json.data);
          setLoading(false);
          return;
        }
      }
    } catch (e) {
      console.warn('Dashboard live fetch failed, using local offline sync:', e);
    }
    setDashboardData(fallbackData);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchDashboardData();
  }, [fetchDashboardData]);

  // Keyboard shortcut listener for global search Cmd+K / Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleMarkAllRead = async () => {
    try {
      await fetch('/api/notifications/mark-read', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) });
    } catch (e) {}

    if (dashboardData) {
      setDashboardData({
        ...dashboardData,
        notifications: dashboardData.notifications.map(n => ({ ...n, isRead: true }))
      });
    }
  };

  const currentData = dashboardData || fallbackData;

  const renderContent = () => {
    if (activeDashboardTab === 'settings') {
      return <SettingsView onBackToDashboard={() => setActiveDashboardTab('dashboard')} />;
    }

    if (activeDashboardTab === 'assignments') {
      return (
        <AssignmentsView
          onBackToDashboard={() => setActiveDashboardTab('dashboard')}
          onOpenPlanner={() => setActiveDashboardTab('planner')}
          onOpenCalendar={() => setActiveDashboardTab('calendar')}
        />
      );
    }

    if (activeDashboardTab === 'calendar') {
      return (
        <CalendarView
          onBackToDashboard={() => setActiveDashboardTab('dashboard')}
          onOpenAssignments={() => setActiveDashboardTab('assignments')}
        />
      );
    }

    if (activeDashboardTab === 'planner') {
      return <StudyPlannerView onBackToDashboard={() => setActiveDashboardTab('dashboard')} />;
    }

    if (activeDashboardTab === 'buddy') {
      return <EduBuddyAIView onBackToDashboard={() => setActiveDashboardTab('dashboard')} />;
    }

    if (activeDashboardTab !== 'dashboard') {
      const moduleName = 
        activeDashboardTab === 'feed' ? 'Edu Feed' :
        activeDashboardTab === 'chat' ? 'Edu Chat' :
        activeDashboardTab === 'library' ? 'Edu Library' :
        activeDashboardTab === 'market' ? 'Edu Market' :
        activeDashboardTab === 'workspace' ? 'Workspace' :
        activeDashboardTab === 'scanner' ? 'AI Scanner' :
        activeDashboardTab === 'career' ? 'Career Hub' : activeDashboardTab;

      return (
        <ComingSoonView 
          moduleName={moduleName} 
          onBackToDashboard={() => setActiveDashboardTab('dashboard')} 
        />
      );
    }

    // Main Dashboard View
    return (
      <div className="space-y-6 animate-fadeIn">
        {/* 1. Welcome Section */}
        <WelcomeSection 
          user={currentData.user} 
          streak={currentData.streak} 
          motivationalQuote={currentData.motivationalQuote} 
        />

        {/* 2. Edu Buddy Welcome Card */}
        <EduBuddyWelcomeCard 
          user={currentData.user} 
          eduBuddy={currentData.eduBuddy} 
          onOpenChat={() => setActiveDashboardTab('buddy')} 
          onOpenPlanner={() => setActiveDashboardTab('planner')} 
        />

        {/* 3. Today's Overview */}
        <TodaysOverview 
          stats={currentData.overview} 
          onTabChange={(tab) => setActiveDashboardTab(tab)} 
        />

        {/* 4. Learning Progress */}
        <LearningProgress items={currentData.progress} />

        {/* 5. Quick Actions */}
        <QuickActions 
          onTabChange={(tab) => setActiveDashboardTab(tab)} 
          onOpenChat={() => setIsChatOpen(true)}
          onOpenOfflineQuiz={() => setIsPracticeQuizOpen(true)}
        />

        {/* 6. Two Column Grid: Recent Activity & Upcoming Events */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <RecentActivity items={currentData.recentActivity} />
          <UpcomingEvents 
            items={currentData.upcomingEvents} 
            onTabChange={(tab) => setActiveDashboardTab(tab)} 
          />
        </div>

        {/* 7. Study Planner Preview */}
        <StudyPlannerPreview 
          data={currentData.plannerPreview} 
          onTabChange={(tab) => setActiveDashboardTab(tab)} 
        />

        {/* 8. Achievements Section */}
        <AchievementsSection 
          achievements={currentData.achievements} 
          streak={currentData.streak} 
        />

        {/* 9. Motivation Section */}
        <MotivationSection initialQuote={currentData.motivationalQuote} />
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-1 animate-spin shadow-lg shadow-emerald-500/30 mb-4">
          <div className="w-full h-full bg-[#0A2540] rounded-[22px]" />
        </div>
        <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
          Loading Student Workspace...
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Synchronizing NSSCO curriculum stats and Edu Buddy mentor profile
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col selection:bg-emerald-500 selection:text-white">
      {/* Top Navigation */}
      <TopNavbar
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenChat={() => setIsChatOpen(true)}
        onOpenOfflineHub={() => setIsOfflineHubOpen(true)}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        isSidebarOpen={isSidebarOpen}
        notifications={currentData.notifications}
        onMarkAllRead={handleMarkAllRead}
        onToggleNotifications={() => setIsNotificationsOpen(!isNotificationsOpen)}
        isNotificationsOpen={isNotificationsOpen}
        onSelectTab={(tab) => setActiveDashboardTab(tab)}
      />

      {/* Main Body Container with Left Sidebar */}
      <div className="flex-1 flex">
        {/* Left Sidebar (Desktop & Tablet collapsible) */}
        <LeftSidebar
          activeTab={activeDashboardTab}
          onSelectTab={(tab) => setActiveDashboardTab(tab)}
          isOpen={isSidebarOpen}
          onCloseMobile={() => setIsSidebarOpen(false)}
          streak={currentData.streak}
        />

        {/* Main Content Area */}
        <main className="flex-1 lg:pl-64 sm:lg:pl-72 pt-4 pb-24 lg:pb-12 px-4 sm:px-6 md:px-8 max-w-7xl mx-auto w-full transition-all duration-300">
          {renderContent()}
        </main>
      </div>

      {/* Bottom Navigation (Mobile ONLY) */}
      <BottomNavbar
        activeTab={activeDashboardTab}
        onSelectTab={(tab) => setActiveDashboardTab(tab)}
        onOpenChat={() => setIsChatOpen(true)}
        onToggleSidebar={() => setIsSidebarOpen(true)}
      />

      {/* Global Search Modal */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectTab={(tab) => setActiveDashboardTab(tab)}
        onOpenChat={() => setIsChatOpen(true)}
      />

      {/* Edu Buddy Quick Chat Modal */}
      <EduBuddyQuickChatModal
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        eduBuddy={currentData.eduBuddy}
        onLaunchFullSuite={() => { setIsChatOpen(false); setActiveDashboardTab('buddy'); }}
      />

      {/* Notifications Panel */}
      <NotificationsPanel
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={currentData.notifications}
        onMarkAllRead={handleMarkAllRead}
      />

      {/* Offline Curriculum Hub Modal */}
      <OfflineCurriculumModal
        isOpen={isOfflineHubOpen}
        onClose={() => setIsOfflineHubOpen(false)}
      />

      {/* Offline Practice Quiz Modal */}
      <OfflinePracticeQuizModal
        isOpen={isPracticeQuizOpen}
        onClose={() => setIsPracticeQuizOpen(false)}
      />
    </div>
  );
};
