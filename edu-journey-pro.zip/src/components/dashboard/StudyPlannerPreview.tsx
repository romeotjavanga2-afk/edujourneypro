import React from 'react';
import { motion } from 'motion/react';
import { Clock, CheckCircle2, Calendar, Target, Bell, ArrowRight, Sparkles } from 'lucide-react';
import { StudyPlannerPreviewData } from '../../types.js';

interface StudyPlannerPreviewProps {
  data: StudyPlannerPreviewData;
  onTabChange: (tab: any) => void;
}

export const StudyPlannerPreview: React.FC<StudyPlannerPreviewProps> = ({ data, onTabChange }) => {
  const dailyPercent = Math.min(100, Math.round((data.timeCompletedMinutes / data.timeTargetMinutes) * 100));
  const weeklyPercent = Math.min(100, Math.round((data.weeklyCompletedHours / data.weeklyGoalHours) * 100));

  return (
    <div className="bg-gradient-to-br from-slate-900 via-[#0A2540] to-emerald-950 rounded-3xl p-6 md:p-8 text-white shadow-xl border border-emerald-500/20 my-6 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg md:text-xl font-extrabold tracking-tight">
                Study Planner Preview
              </h2>
              <p className="text-xs text-slate-300">
                Your structured daily and weekly academic roadmap
              </p>
            </div>
          </div>

          <button
            onClick={() => onTabChange('planner')}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition transform active:scale-95 self-start sm:self-auto"
          >
            <span>Open Interactive Planner</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Left: Today's Goal & Reminder */}
          <div className="bg-white/10 backdrop-blur-md p-5 rounded-2xl border border-white/10 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between text-xs font-bold text-emerald-300 mb-2 uppercase tracking-wider">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>Today's Study Goal</span>
                </span>
                <span className="bg-emerald-500/20 px-2 py-0.5 rounded-md text-[10px]">
                  Priority
                </span>
              </div>
              <p className="text-sm md:text-base font-extrabold leading-snug text-white">
                "{data.todaysGoal}"
              </p>
            </div>

            <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs font-medium text-slate-300">
              <span className="flex items-center gap-1.5 text-amber-300 font-bold">
                <Bell className="w-3.5 h-3.5 animate-bounce" style={{ animationDuration: '3s' }} />
                <span>Next Reminder:</span>
              </span>
              <span className="bg-white/10 px-2.5 py-1 rounded-lg text-white font-extrabold">
                {data.nextReminder}
              </span>
            </div>
          </div>

          {/* Right: Progress Bars */}
          <div className="space-y-4">
            {/* Daily Target */}
            <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-bold text-slate-200 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Today's Time Target</span>
                </span>
                <span className="font-extrabold text-white">
                  {Math.floor(data.timeCompletedMinutes / 60)}h {data.timeCompletedMinutes % 60}m / {Math.floor(data.timeTargetMinutes / 60)}h ({dailyPercent}%)
                </span>
              </div>
              <div className="w-full h-2.5 bg-white/10 rounded-full overflow-hidden p-0.5 border border-white/15">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${dailyPercent}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-300"
                />
              </div>
            </div>

            {/* Weekly Goal */}
            <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-bold text-slate-200 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-blue-400" />
                  <span>Weekly Target Progress</span>
                </span>
                <span className="font-extrabold text-white">
                  {data.weeklyCompletedHours}h / {data.weeklyGoalHours}h ({weeklyPercent}%)
                </span>
              </div>
              <div className="w-full h-2.5 bg-white/10 rounded-full overflow-hidden p-0.5 border border-white/15">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${weeklyPercent}%` }}
                  transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
                  className="h-full rounded-full bg-gradient-to-r from-blue-400 to-indigo-300"
                />
              </div>
            </div>
          </div>

        </div>

        <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-400 font-medium">
          <span>* Note: Interactive study session scheduling and custom reminder triggers will unlock in upcoming Phase modules.</span>
          <span className="hidden sm:inline text-emerald-400 font-bold">Phase 3 UI Live</span>
        </div>
      </div>
    </div>
  );
};
