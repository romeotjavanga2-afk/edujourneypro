import React from 'react';
import { motion } from 'motion/react';
import { TrendingUp, BookOpen, Award, ArrowUpRight } from 'lucide-react';
import { LearningProgressItem } from '../../types.js';

interface LearningProgressProps {
  items: LearningProgressItem[];
}

export const LearningProgress: React.FC<LearningProgressProps> = ({ items }) => {
  return (
    <div className="space-y-4 my-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="w-2 h-6 rounded-full bg-blue-600"></span>
          <h2 className="text-lg md:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Learning Progress
          </h2>
        </div>
        <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-3 py-1 rounded-full border border-emerald-200 dark:border-emerald-800">
          <TrendingUp className="w-3.5 h-3.5" />
          <span>All Subjects Trending Up</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((item, idx) => {
          const colorClass = 
            item.color === 'emerald' ? 'from-emerald-500 to-teal-600 text-emerald-500 bg-emerald-500' :
            item.color === 'blue' ? 'from-blue-500 to-indigo-600 text-blue-500 bg-blue-500' :
            item.color === 'purple' ? 'from-purple-500 to-violet-600 text-purple-500 bg-purple-500' :
            item.color === 'amber' ? 'from-amber-500 to-orange-600 text-amber-500 bg-amber-500' :
            item.color === 'rose' ? 'from-rose-500 to-pink-600 text-rose-500 bg-rose-500' :
            'from-cyan-500 to-blue-600 text-cyan-500 bg-cyan-500';

          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.05 }}
              className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all duration-200 group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-lg shadow-inner">
                      {item.icon || '📚'}
                    </span>
                    <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white line-clamp-1 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                      {item.subject}
                    </h3>
                  </div>
                  <span className="text-sm font-extrabold text-slate-900 dark:text-white bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-lg">
                    {item.progress}%
                  </span>
                </div>

                <div className="mt-4">
                  <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-semibold mb-1.5">
                    <span>NSSCO Mastery Target</span>
                    <span>{item.progress}/100</span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-200/50 dark:border-slate-700/50">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${item.progress}%` }}
                      transition={{ duration: 1, delay: idx * 0.1, ease: "easeOut" }}
                      className={`h-full rounded-full bg-gradient-to-r ${colorClass.split(' ')[0]} ${colorClass.split(' ')[1]}`}
                    />
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                  <span>{item.trend}</span>
                </span>
                <button className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 font-bold inline-flex items-center gap-0.5 transition-colors">
                  <span>Practice</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
