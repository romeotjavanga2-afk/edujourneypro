import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X, BookOpen, Clock, Bot, Award, Calendar, ArrowRight, WifiOff, FileText, Sparkles } from 'lucide-react';
import { searchOfflineCurriculum } from '../../lib/offlineStorage.js';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTab: (tab: any) => void;
  onOpenChat: () => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectTab,
  onOpenChat
}) => {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'lessons' | 'assignments' | 'ai'>('all');

  if (!isOpen) return null;

  interface GlobalSearchResult {
    id: string;
    title: string;
    type: string;
    category: string;
    icon: React.FC<{ className?: string }>;
    action: () => void;
    badge?: string;
    snippet?: string;
  }

  const defaultResults: GlobalSearchResult[] = [
    { id: 'def-1', title: 'Algebra Polynomials Practice', type: 'Assignment', category: 'assignments', icon: BookOpen as any, action: () => { onSelectTab('assignments'); onClose(); } },
    { id: 'def-2', title: 'Physical Science Chapter 4: Newton Laws', type: 'Lesson Note', category: 'lessons', icon: Clock as any, action: () => { onSelectTab('planner'); onClose(); } },
    { id: 'def-3', title: 'Ask Edu Buddy about Algebra level 1', type: 'AI Mentor Prompt', category: 'ai', icon: Bot as any, action: () => { onOpenChat(); onClose(); } },
    { id: 'def-4', title: 'NSSCO Mock Exam prep schedule', type: 'Calendar Event', category: 'assignments', icon: Calendar as any, action: () => { onSelectTab('calendar'); onClose(); } },
    { id: 'def-5', title: 'English First Language Essay Rubric', type: 'Study Resource', category: 'lessons', icon: BookOpen as any, action: () => { onSelectTab('assignments'); onClose(); } },
  ].filter(r => {
    const matchesCat = activeCategory === 'all' || r.category === activeCategory;
    const matchesQuery = !query.trim() || r.title.toLowerCase().includes(query.toLowerCase()) || r.type.toLowerCase().includes(query.toLowerCase());
    return matchesCat && matchesQuery;
  });

  // Calculate local offline curriculum matches if query is present
  const offlineMatches: GlobalSearchResult[] = query.trim()
    ? searchOfflineCurriculum(query).map((res) => ({
        id: res.id,
        title: `${res.subjectName}: ${res.title}`,
        type: `Offline ${res.matchedField}`,
        category: 'lessons',
        icon: (res.type === 'note' ? FileText : BookOpen) as any,
        badge: 'Offline Cache',
        snippet: res.snippet,
        action: () => {
          onSelectTab('planner');
          onClose();
        },
      }))
    : [];

  const combinedResults = [...offlineMatches, ...defaultResults];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: -20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -20 }}
          className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden"
        >
          {/* Search Bar Input */}
          <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center gap-3">
            <Search className="w-6 h-6 text-emerald-500 shrink-0" />
            <input
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search lessons, assignments, quizzes, or ask Edu Buddy..."
              className="flex-1 bg-transparent text-slate-900 dark:text-white font-bold text-base sm:text-lg focus:outline-none placeholder-slate-400"
            />
            {query && (
              <button onClick={() => setQuery('')} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                <X className="w-5 h-5" />
              </button>
            )}
            <button
              onClick={onClose}
              className="px-3 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition"
            >
              ESC
            </button>
          </div>

          {/* Category Filter Pills */}
          <div className="px-5 py-3 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2 overflow-x-auto no-scrollbar">
            {[
              { id: 'all', label: 'All Results' },
              { id: 'lessons', label: 'Lessons & Notes' },
              { id: 'assignments', label: 'Assignments & Exams' },
              { id: 'ai', label: 'Edu Buddy AI' }
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id as any)}
                className={`text-xs font-bold px-3 py-1.5 rounded-xl border transition whitespace-nowrap ${
                  activeCategory === cat.id
                    ? 'bg-emerald-500 text-white border-emerald-500 shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-slate-300'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Results List */}
          <div className="max-h-80 overflow-y-auto p-4 space-y-2">
            {combinedResults.length > 0 ? (
              combinedResults.map((r) => {
                const Icon = r.icon;
                return (
                  <div
                    key={r.id}
                    onClick={r.action}
                    className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 border border-transparent hover:border-emerald-500/30 flex items-center justify-between gap-3 cursor-pointer group transition"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="w-10 h-10 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-emerald-500 shadow-sm group-hover:scale-110 transition-transform">
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-extrabold text-sm text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                            {r.title}
                          </h4>
                          {r.badge && (
                            <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                              {r.badge}
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] font-semibold text-slate-400 dark:text-slate-500 block">
                          {r.type}
                        </span>
                        {r.snippet && (
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-1">
                            {r.snippet}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="text-slate-400 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                      <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="py-12 text-center text-slate-400 font-medium text-sm">
                No matching lessons or study materials found for "{query}".
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-5 py-3 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
            <span>Press <kbd className="font-mono font-bold bg-white dark:bg-slate-900 px-1.5 py-0.5 rounded border">ESC</kbd> to close</span>
            <span className="font-bold text-emerald-600 dark:text-emerald-400">Namibian Curriculum Search</span>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
