import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, Sparkles, MessageSquare, BookOpen, X, ArrowRight } from 'lucide-react';
import { User } from '../../types.js';

interface EduBuddyWelcomeCardProps {
  user: User;
  eduBuddy: {
    aiName: string;
    aiAvatar: string;
    greetingStyle?: string;
  };
  onOpenChat: () => void;
  onOpenPlanner: () => void;
}

export const EduBuddyWelcomeCard: React.FC<EduBuddyWelcomeCardProps> = ({
  user,
  eduBuddy,
  onOpenChat,
  onOpenPlanner
}) => {
  const [isVisible, setIsVisible] = useState<boolean>(true);

  if (!isVisible) return null;

  const firstName = user.fullName ? user.fullName.split(' ')[0] : 'Student';

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, height: 0, marginBottom: 0 }}
        className="bg-gradient-to-br from-emerald-900/90 via-slate-900 to-[#0A2540] rounded-3xl p-6 border border-emerald-500/30 shadow-lg relative overflow-hidden text-white my-6"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          
          <div className="flex items-start sm:items-center gap-4">
            {/* AI Avatar */}
            <div className="relative shrink-0">
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-300 p-0.5 shadow-lg shadow-emerald-500/30">
                <div className="w-full h-full bg-[#0A2540] rounded-[14px] flex items-center justify-center text-3xl">
                  {eduBuddy.aiAvatar === 'cyber-owl' ? '🦉' :
                   eduBuddy.aiAvatar === 'astro-guide' ? '👩‍🚀' :
                   eduBuddy.aiAvatar === 'safari-cheetah' ? '🐆' :
                   eduBuddy.aiAvatar === 'quantum-leopard' ? '🐯' :
                   eduBuddy.aiAvatar === 'digital-mentor' ? '🌟' : '🤖'}
                </div>
              </div>
              <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-emerald-400 border-2 border-[#0A2540] flex items-center justify-center">
                <Sparkles className="w-3 h-3 text-[#0A2540] animate-spin" style={{ animationDuration: '6s' }} />
              </span>
            </div>

            {/* Welcome Text */}
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-lg sm:text-xl text-white flex items-center gap-1.5">
                  <span>{eduBuddy.aiName || 'Edu Buddy'}</span>
                  <span className="text-xs font-bold bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
                    AI Tutor
                  </span>
                </h3>
              </div>
              <p className="text-slate-200 font-medium text-sm sm:text-base mt-1">
                "Hi <span className="text-emerald-300 font-bold">{firstName}</span>! Ready to continue learning today? Let's make today productive."
              </p>
              <p className="text-xs text-slate-400 mt-1">
                Based on your NSSCO curriculum goals and recent study sessions.
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-3 w-full md:w-auto shrink-0 justify-end">
            <button
              type="button"
              onClick={onOpenChat}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-[#0A2540] font-extrabold text-xs shadow-lg shadow-emerald-500/20 transition transform active:scale-95"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Ask Edu Buddy</span>
            </button>

            <button
              type="button"
              onClick={onOpenPlanner}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs border border-white/15 transition"
            >
              <BookOpen className="w-4 h-4 text-emerald-400" />
              <span>Study Plan</span>
            </button>

            <button
              type="button"
              onClick={() => setIsVisible(false)}
              className="p-3 rounded-xl bg-white/5 hover:bg-white/15 text-slate-400 hover:text-white transition"
              title="Hide Card for today"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

        </div>
      </motion.div>
    </AnimatePresence>
  );
};
