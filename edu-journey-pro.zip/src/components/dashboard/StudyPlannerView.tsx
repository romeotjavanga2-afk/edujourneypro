import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Clock, CheckCircle2, Circle, Play, Pause, RotateCcw, Award,
  Sparkles, Bot, Target, Plus, Trash2, Calendar as CalendarIcon,
  BookOpen, ArrowLeft, Flame, TrendingUp, ShieldCheck, CheckSquare, Square
} from 'lucide-react';
import { StudyPlan, StudySession, StudentGoal } from '../../types.js';

interface StudyPlannerViewProps {
  onBackToDashboard: () => void;
}

export const StudyPlannerView: React.FC<StudyPlannerViewProps> = ({
  onBackToDashboard
}) => {
  const [plans, setPlans] = useState<StudyPlan[]>([]);
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [goals, setGoals] = useState<StudentGoal[]>([]);
  const [loading, setLoading] = useState(true);

  // Active Tab within Planner
  const [activeTab, setActiveTab] = useState<'timetable' | 'timer' | 'goals'>('timetable');

  // New Plan Modal State
  const [isPlanModalOpen, setIsPlanModalOpen] = useState(false);
  const [planTitle, setPlanTitle] = useState('NSSCO Intensive Focus Timetable');
  const [planType, setPlanType] = useState<'Daily Study Plan' | 'Weekly Study Plan' | 'Revision Schedule'>('Weekly Study Plan');
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(['Mathematics', 'Physical Science', 'English First Language']);
  const [dailyHours, setDailyHours] = useState(2.0);
  const [generating, setGenerating] = useState(false);

  // Focus Timer State
  const [timerMode, setTimerMode] = useState<'pomodoro' | 'deep' | 'exam'>('pomodoro');
  const [timerSubject, setTimerSubject] = useState('Mathematics');
  const [timerTitle, setTimerTitle] = useState('Quadratic Equations Revision');
  const [timeLeft, setTimeLeft] = useState(25 * 60); // 25 minutes
  const [isRunning, setIsRunning] = useState(false);

  // New Goal Modal State
  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [goalTitle, setGoalTitle] = useState('');
  const [goalType, setGoalType] = useState<'Daily Goal' | 'Weekly Goal' | 'Monthly Goal'>('Daily Goal');
  const [goalTargetVal, setGoalTargetVal] = useState(2);

  useEffect(() => {
    fetchPlannerData();
  }, []);

  // Timer interval
  useEffect(() => {
    let interval: any = null;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isRunning) {
      setIsRunning(false);
      handleCompleteSession();
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft]);

  const fetchPlannerData = async () => {
    try {
      setLoading(true);
      const [plansRes, sessionsRes, goalsRes] = await Promise.all([
        fetch('/api/study-planner').then(r => r.json()),
        fetch('/api/study-sessions').then(r => r.json()),
        fetch('/api/goals').then(r => r.json())
      ]);

      if (plansRes.success) setPlans(plansRes.data);
      if (sessionsRes.success) setSessions(sessionsRes.data);
      if (goalsRes.success) setGoals(goalsRes.data);
    } catch (e) {
      console.error('Failed to load study planner data', e);
    } finally {
      setLoading(false);
    }
  };

  const handleGeneratePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedSubjects.length === 0) {
      alert('Please select at least one subject');
      return;
    }

    try {
      setGenerating(true);
      const res = await fetch('/api/study-planner', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: planTitle,
          plan_type: planType,
          subjects: selectedSubjects,
          daily_hours: dailyHours,
          target_date: new Date().toISOString().split('T')[0]
        })
      });
      const json = await res.json();
      if (json.success) {
        setPlans([json.data, ...plans]);
        setIsPlanModalOpen(false);
      }
    } catch (e) {
      console.error('Failed to generate AI study plan', e);
    } finally {
      setGenerating(false);
    }
  };

  const handleDeletePlan = async (id: number | string) => {
    if (!window.confirm('Delete this study plan timetable?')) return;
    try {
      await fetch(`/api/study-planner/${id}`, { method: 'DELETE' });
      setPlans(plans.filter(p => p.id !== id));
    } catch (e) {
      console.error('Failed to delete study plan', e);
    }
  };

  const handleToggleTaskInPlan = async (plan: StudyPlan, dayIdx: number, taskIdx: number) => {
    const newSchedule = JSON.parse(JSON.stringify(plan.schedule_json));
    if (newSchedule[dayIdx] && newSchedule[dayIdx].tasks[taskIdx]) {
      newSchedule[dayIdx].tasks[taskIdx].completed = !newSchedule[dayIdx].tasks[taskIdx].completed;
      
      try {
        const res = await fetch(`/api/study-planner/${plan.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ schedule_json: newSchedule })
        });
        const json = await res.json();
        if (json.success) {
          setPlans(plans.map(p => p.id === plan.id ? json.data : p));
        }
      } catch (e) {
        console.error('Failed to toggle task in plan', e);
      }
    }
  };

  const handleStartTimerMode = (mode: 'pomodoro' | 'deep' | 'exam') => {
    setTimerMode(mode);
    setIsRunning(false);
    if (mode === 'pomodoro') setTimeLeft(25 * 60);
    else if (mode === 'deep') setTimeLeft(45 * 60);
    else if (mode === 'exam') setTimeLeft(60 * 60);
  };

  const handleCompleteSession = async () => {
    const totalMinutes = timerMode === 'pomodoro' ? 25 : timerMode === 'deep' ? 45 : 60;
    try {
      const res = await fetch('/api/study-sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: timerTitle || `${timerSubject} Focus`,
          subject: timerSubject,
          duration_minutes: totalMinutes,
          mode: timerMode,
          status: 'completed'
        })
      });
      const json = await res.json();
      if (json.success) {
        setSessions([json.data, ...sessions]);
        alert(json.message || `Session completed! +${json.xpEarned} XP earned! 🎉`);
      }
    } catch (e) {
      console.error('Failed to record session', e);
    }
  };

  const handleCreateGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalTitle) return;
    try {
      const res = await fetch('/api/goals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: goalTitle,
          goal_type: goalType,
          target_value: goalTargetVal
        })
      });
      const json = await res.json();
      if (json.success) {
        setGoals([json.data, ...goals]);
        setIsGoalModalOpen(false);
        setGoalTitle('');
      }
    } catch (e) {
      console.error('Failed to set goal', e);
    }
  };

  const handleToggleGoal = async (goal: StudentGoal) => {
    try {
      const res = await fetch(`/api/goals/${goal.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_completed: !goal.is_completed })
      });
      const json = await res.json();
      if (json.success) {
        setGoals(goals.map(g => g.id === goal.id ? json.data : g));
        if (json.data.is_completed) {
          alert('🏆 Goal Achieved! +150 XP awarded to your streak!');
        }
      }
    } catch (e) {
      console.error('Failed to toggle goal', e);
    }
  };

  const formatTimer = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const subjectsList = ['Mathematics', 'Physical Science', 'English First Language', 'Computer Studies', 'Geography', 'History'];

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#0A2540] via-slate-900 to-purple-950 rounded-3xl p-6 md:p-8 text-white shadow-xl border border-purple-500/20 relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-60 h-60 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-bold uppercase tracking-wider mb-3 border border-purple-500/30">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Phase 4 AI Study Planner</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">
              AI Study Planner & Focus Hub
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-xl">
              Let Edu Buddy generate intelligent study schedules tailored to your NSSCO syllabus, track learning goals, and log XP with the Pomodoro focus timer.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsPlanModalOpen(true)}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white font-extrabold text-sm shadow-lg shadow-purple-500/25 transition transform active:scale-95"
            >
              <Bot className="w-4 h-4 animate-bounce" style={{ animationDuration: '3s' }} />
              <span>Generate AI Timetable</span>
            </button>
            <button
              onClick={onBackToDashboard}
              className="inline-flex items-center gap-2 px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-sm transition"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </button>
          </div>
        </div>

        {/* Quick Stats Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-white/10 text-center">
          <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
            <div className="text-xl md:text-2xl font-extrabold text-white">2.5 hrs</div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Daily Target</div>
          </div>
          <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
            <div className="text-xl md:text-2xl font-extrabold text-emerald-400">
              {sessions.reduce((acc, s) => acc + (s.duration_minutes || 0), 165)}m
            </div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Total Logged</div>
          </div>
          <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
            <div className="text-xl md:text-2xl font-extrabold text-amber-400">7 Days 🔥</div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Study Streak</div>
          </div>
          <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
            <div className="text-xl md:text-2xl font-extrabold text-purple-400">
              {goals.filter(g => g.is_completed).length} / {goals.length || 3}
            </div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Goals Achieved</div>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 bg-white dark:bg-slate-900 p-2 rounded-2xl border border-slate-200 dark:border-slate-800 w-fit">
        <button
          onClick={() => setActiveTab('timetable')}
          className={`px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-2 ${
            activeTab === 'timetable'
              ? 'bg-[#0A2540] dark:bg-purple-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>AI Study Timetables</span>
        </button>
        <button
          onClick={() => setActiveTab('timer')}
          className={`px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-2 ${
            activeTab === 'timer'
              ? 'bg-[#0A2540] dark:bg-purple-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Play className="w-4 h-4 text-emerald-500" />
          <span>Pomodoro Focus Timer</span>
        </button>
        <button
          onClick={() => setActiveTab('goals')}
          className={`px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-2 ${
            activeTab === 'goals'
              ? 'bg-[#0A2540] dark:bg-purple-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Award className="w-4 h-4 text-amber-500" />
          <span>Student Goals ({goals.filter(g => !g.is_completed).length})</span>
        </button>
      </div>

      {/* TAB 1: AI STUDY TIMETABLES */}
      {activeTab === 'timetable' && (
        <div className="space-y-6 animate-fadeIn">
          {loading ? (
            <div className="p-12 text-center text-slate-500 text-xs">Loading AI timetables...</div>
          ) : plans.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-12 text-center border border-slate-200 dark:border-slate-800">
              <Bot className="w-12 h-12 text-purple-500 mx-auto mb-3" />
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">No AI Timetables Generated Yet</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                Click "Generate AI Timetable" above and let Edu Buddy build a customized study schedule for your grade 11 subjects!
              </p>
            </div>
          ) : (
            <div className="space-y-8">
              {plans.map((plan) => (
                <div
                  key={plan.id}
                  className="bg-white dark:bg-slate-900 rounded-3xl p-6 md:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="px-2.5 py-0.5 rounded-md bg-purple-500/10 text-purple-600 dark:text-purple-400 text-[10px] font-extrabold uppercase tracking-wider">
                          {plan.plan_type}
                        </span>
                        {plan.ai_generated && (
                          <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[10px] font-extrabold flex items-center gap-1">
                            <Bot className="w-3 h-3" />
                            <span>Edu Buddy AI</span>
                          </span>
                        )}
                      </div>
                      <h3 className="text-lg md:text-xl font-extrabold text-slate-900 dark:text-white">
                        {plan.title}
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Target Daily Study: <strong>{plan.daily_hours} hours</strong> • Subjects: {plan.subjects_included.join(', ')}
                      </p>
                    </div>

                    <button
                      onClick={() => handleDeletePlan(plan.id)}
                      className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-rose-500 transition self-start sm:self-auto"
                      title="Delete Plan"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Day by Day Schedule Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                    {plan.schedule_json && plan.schedule_json.map((dayObj: any, dIdx: number) => (
                      <div
                        key={dIdx}
                        className="bg-slate-50 dark:bg-slate-800/50 p-5 rounded-2xl border border-slate-200 dark:border-slate-700/80 space-y-3 flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-center justify-between mb-3 border-b border-slate-200/60 dark:border-slate-700/60 pb-2">
                            <h4 className="text-sm font-extrabold text-[#0A2540] dark:text-purple-300">
                              📅 {dayObj.day}
                            </h4>
                            <span className="text-[10px] font-bold text-slate-400">
                              {dayObj.tasks?.length || 0} tasks
                            </span>
                          </div>

                          <div className="space-y-2.5">
                            {dayObj.tasks && dayObj.tasks.map((task: any, tIdx: number) => (
                              <div
                                key={tIdx}
                                onClick={() => handleToggleTaskInPlan(plan, dIdx, tIdx)}
                                className={`p-3 rounded-xl border transition cursor-pointer flex items-start gap-2.5 ${
                                  task.completed
                                    ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-500/30 text-slate-400'
                                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:border-purple-500/50'
                                }`}
                              >
                                {task.completed ? (
                                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                                ) : (
                                  <Square className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                                )}
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between text-[10px] font-extrabold uppercase text-purple-600 dark:text-purple-400">
                                    <span>{task.subject}</span>
                                    <span>⏱️ {task.duration}</span>
                                  </div>
                                  <p className={`text-xs font-bold mt-0.5 leading-snug ${task.completed ? 'line-through' : ''}`}>
                                    {task.topic}
                                  </p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="pt-2 text-right">
                          <span className="text-[10px] font-bold text-slate-400">
                            Click checkbox to track completion
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: POMODORO FOCUS TIMER */}
      {activeTab === 'timer' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fadeIn">
          
          {/* Left: The Interactive Timer Box (7 Cols) */}
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col items-center justify-center text-center space-y-6">
            
            {/* Mode selector */}
            <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700">
              <button
                onClick={() => handleStartTimerMode('pomodoro')}
                className={`px-4 py-2 rounded-xl text-xs font-extrabold transition ${
                  timerMode === 'pomodoro' ? 'bg-emerald-500 text-white shadow-sm' : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                🍅 Pomodoro (25m)
              </button>
              <button
                onClick={() => handleStartTimerMode('deep')}
                className={`px-4 py-2 rounded-xl text-xs font-extrabold transition ${
                  timerMode === 'deep' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                ⚡ Deep Work (45m)
              </button>
              <button
                onClick={() => handleStartTimerMode('exam')}
                className={`px-4 py-2 rounded-xl text-xs font-extrabold transition ${
                  timerMode === 'exam' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                🚨 Exam Sim (60m)
              </button>
            </div>

            {/* Subject & Topic input */}
            <div className="w-full max-w-sm space-y-3">
              <select
                value={timerSubject}
                onChange={(e) => setTimerSubject(e.target.value)}
                disabled={isRunning}
                className="w-full px-4 py-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-extrabold text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                {subjectsList.map(sub => (
                  <option key={sub} value={sub}>{sub}</option>
                ))}
              </select>

              <input
                type="text"
                placeholder="Session focus (e.g. Solving Quadratic Equations)..."
                value={timerTitle}
                onChange={(e) => setTimerTitle(e.target.value)}
                disabled={isRunning}
                className="w-full px-4 py-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 text-center"
              />
            </div>

            {/* Huge Clock Display */}
            <div className="relative my-4">
              <div className="w-64 h-64 sm:w-72 sm:h-72 rounded-full border-8 border-slate-100 dark:border-slate-800 flex flex-col items-center justify-center relative shadow-inner">
                <div className={`text-5xl sm:text-6xl font-black font-mono tracking-tighter ${
                  isRunning ? 'text-emerald-500 dark:text-emerald-400 animate-pulse' : 'text-slate-900 dark:text-white'
                }`}>
                  {formatTimer(timeLeft)}
                </div>
                <span className="text-xs font-bold uppercase tracking-widest text-slate-400 mt-2">
                  {timerMode.toUpperCase()} FOCUS
                </span>
              </div>
            </div>

            {/* Play / Pause / Reset Controls */}
            <div className="flex items-center gap-4">
              <button
                onClick={() => setIsRunning(!isRunning)}
                className={`px-8 py-4 rounded-2xl font-black text-sm shadow-xl transition transform active:scale-95 flex items-center gap-2 ${
                  isRunning
                    ? 'bg-amber-500 hover:bg-amber-400 text-[#0A2540]'
                    : 'bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-[#0A2540]'
                }`}
              >
                {isRunning ? (
                  <>
                    <Pause className="w-5 h-5 fill-current" />
                    <span>Pause Timer</span>
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 fill-current" />
                    <span>Start Session</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  setIsRunning(false);
                  handleStartTimerMode(timerMode);
                }}
                title="Reset Timer"
                className="p-4 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300 transition font-bold"
              >
                <RotateCcw className="w-5 h-5" />
              </button>

              <button
                onClick={handleCompleteSession}
                title="Finish Early & Log XP"
                className="px-4 py-4 rounded-2xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-600 dark:text-purple-300 font-extrabold text-xs transition"
              >
                Log XP Now
              </button>
            </div>

            <p className="text-xs text-slate-400 max-w-sm">
              💡 Completing focus sessions adds study time directly to your dashboard summary and increments your 7-day streak!
            </p>
          </div>

          {/* Right: Recent Study Sessions Log (5 Cols) */}
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col space-y-4">
            <h3 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-emerald-500" />
              <span>Recent Focus Sessions ({sessions.length})</span>
            </h3>

            <div className="space-y-3 overflow-y-auto max-h-[500px] pr-1">
              {sessions.length === 0 ? (
                <p className="text-xs text-slate-400 italic py-8 text-center">No study sessions completed yet today. Start the Pomodoro timer above!</p>
              ) : (
                sessions.map((ses) => (
                  <div
                    key={ses.id}
                    className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                          {ses.subject}
                        </span>
                        <span className="text-[10px] text-slate-400 font-bold">{ses.mode?.toUpperCase()}</span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white mt-1">
                        {ses.title}
                      </h4>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="text-sm font-black text-emerald-600 dark:text-emerald-400">
                        +{ses.xp_earned || 50} XP
                      </div>
                      <div className="text-[10px] text-slate-400 font-bold">
                        {ses.duration_minutes} mins
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: STUDENT GOALS TRACKER */}
      {activeTab === 'goals' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
                Academic Goal Tracker
              </h2>
              <p className="text-xs text-slate-500">
                Set and conquer daily, weekly, and monthly milestones to earn bonus XP badges.
              </p>
            </div>
            <button
              onClick={() => setIsGoalModalOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-[#0A2540] dark:bg-purple-600 text-white font-extrabold text-xs shadow-md transition hover:opacity-90 flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Set New Goal</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {goals.map((goal) => (
              <motion.div
                key={goal.id}
                whileHover={{ y: -2 }}
                onClick={() => handleToggleGoal(goal)}
                className={`p-6 rounded-3xl border transition cursor-pointer flex flex-col justify-between ${
                  goal.is_completed
                    ? 'bg-emerald-50/30 dark:bg-emerald-950/10 border-emerald-500/30'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-purple-500/40 shadow-sm'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-600 dark:text-amber-400 text-[10px] font-extrabold uppercase tracking-wider">
                      {goal.goal_type}
                    </span>
                    {goal.is_completed ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-400" />
                    )}
                  </div>

                  <h3 className={`text-base font-extrabold leading-snug mb-2 ${
                    goal.is_completed ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'
                  }`}>
                    {goal.title}
                  </h3>
                </div>

                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-500">Target Date: {goal.target_date}</span>
                  <span className={goal.is_completed ? 'text-emerald-500' : 'text-purple-600 dark:text-purple-400'}>
                    {goal.is_completed ? 'Achieved! +150 XP' : 'Click to Complete ->'}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* GENERATE AI STUDY PLAN MODAL */}
      {/* ========================================================= */}
      <AnimatePresence>
        {isPlanModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-lg w-full p-6 sm:p-8 space-y-6 overflow-hidden"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-600 dark:text-purple-300 flex items-center justify-center font-extrabold">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
                      Generate AI Study Timetable
                    </h3>
                    <p className="text-xs text-slate-500">
                      Edu Buddy customizes schedules based on your assignments
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsPlanModalOpen(false)}
                  className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-white transition font-bold text-xs"
                >
                  Cancel
                </button>
              </div>

              <form onSubmit={handleGeneratePlan} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                    Timetable Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={planTitle}
                    onChange={(e) => setPlanTitle(e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                      Plan Type
                    </label>
                    <select
                      value={planType}
                      onChange={(e: any) => setPlanType(e.target.value)}
                      className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    >
                      <option value="Weekly Study Plan">Weekly Timetable 📅</option>
                      <option value="Daily Study Plan">Daily Focus Schedule ⚡</option>
                      <option value="Revision Schedule">Exam Revision Schedule 👑</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                      Daily Study Target
                    </label>
                    <select
                      value={dailyHours}
                      onChange={(e) => setDailyHours(Number(e.target.value))}
                      className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    >
                      <option value={1.5}>1.5 hours / day (Moderate)</option>
                      <option value={2.0}>2.0 hours / day (Recommended)</option>
                      <option value={2.5}>2.5 hours / day (Intensive)</option>
                      <option value={3.0}>3.0+ hours / day (Exam Prep)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
                    Select Subjects to Include *
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {subjectsList.map((sub) => {
                      const isSel = selectedSubjects.includes(sub);
                      return (
                        <div
                          key={sub}
                          onClick={() => {
                            if (isSel) setSelectedSubjects(selectedSubjects.filter(s => s !== sub));
                            else setSelectedSubjects([...selectedSubjects, sub]);
                          }}
                          className={`p-2.5 rounded-xl border text-xs font-bold cursor-pointer transition flex items-center gap-2 ${
                            isSel
                              ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-500 text-purple-700 dark:text-purple-300'
                              : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isSel}
                            onChange={() => {}}
                            className="rounded text-purple-600 focus:ring-0 cursor-pointer"
                          />
                          <span className="truncate">{sub}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsPlanModalOpen(false)}
                    className="px-5 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold text-xs hover:bg-slate-200 transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={generating}
                    className="px-6 py-3 rounded-2xl bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-extrabold text-xs shadow-lg shadow-purple-500/25 hover:from-purple-400 hover:to-indigo-500 transition transform active:scale-95 disabled:opacity-50 flex items-center gap-2"
                  >
                    {generating ? 'Generating AI Timetable...' : 'Generate with Edu Buddy'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ========================================================= */}
      {/* SET NEW GOAL MODAL */}
      {/* ========================================================= */}
      <AnimatePresence>
        {isGoalModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-md w-full p-6 sm:p-8 space-y-5 overflow-hidden"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">Set Academic Goal</h3>
                <button onClick={() => setIsGoalModalOpen(false)} className="text-xs font-bold text-slate-400 hover:text-white">Cancel</button>
              </div>

              <form onSubmit={handleCreateGoal} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">Goal Description *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Complete 5 practice quizzes this week"
                    value={goalTitle}
                    onChange={(e) => setGoalTitle(e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">Goal Type</label>
                    <select
                      value={goalType}
                      onChange={(e: any) => setGoalType(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    >
                      <option value="Daily Goal">Daily Goal ⚡</option>
                      <option value="Weekly Goal">Weekly Goal 📅</option>
                      <option value="Monthly Goal">Monthly Goal 🏆</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">Target Count</label>
                    <input
                      type="number"
                      value={goalTargetVal}
                      onChange={(e) => setGoalTargetVal(Number(e.target.value))}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-extrabold text-xs shadow-md transition"
                >
                  Save Goal (+150 XP Reward)
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
