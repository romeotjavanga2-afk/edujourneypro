import React from 'react';
import { motion } from 'motion/react';
import { 
  CheckCircle2, Clock, Calendar, BookOpen, Flame, Award, 
  ArrowUpRight, Sparkles, ChevronRight, AlertCircle 
} from 'lucide-react';
import { OverviewStats } from '../../types.js';

interface TodaysOverviewProps {
  stats: OverviewStats;
  onTabChange: (tab: any) => void;
}

export const TodaysOverview: React.FC<TodaysOverviewProps> = ({ stats, onTabChange }) => {
  const cards = [
    {
      id: 'assignments',
      title: "Today's Assignments",
      value: `${stats.todaysAssignments} Pending`,
      subtitle: "2 Mathematics, 1 Science",
      icon: BookOpen,
      color: "from-blue-500 to-indigo-600",
      bgColor: "bg-blue-50 dark:bg-blue-950/40",
      borderColor: "border-blue-200 dark:border-blue-800",
      textColor: "text-blue-600 dark:text-blue-400",
      tab: 'assignments'
    },
    {
      id: 'sessions',
      title: "Study Sessions",
      value: `${stats.studySessions} Scheduled`,
      subtitle: "Next: 16:30 Physical Science",
      icon: Clock,
      color: "from-emerald-500 to-teal-600",
      bgColor: "bg-emerald-50 dark:bg-emerald-950/40",
      borderColor: "border-emerald-200 dark:border-emerald-800",
      textColor: "text-emerald-600 dark:text-emerald-400",
      tab: 'planner'
    },
    {
      id: 'events',
      title: "Upcoming Events",
      value: `${stats.upcomingEvents} Deadlines`,
      subtitle: "Math Quiz tomorrow 09:00",
      icon: Calendar,
      color: "from-purple-500 to-violet-600",
      bgColor: "bg-purple-50 dark:bg-purple-950/40",
      borderColor: "border-purple-200 dark:border-purple-800",
      textColor: "text-purple-600 dark:text-purple-400",
      tab: 'calendar'
    },
    {
      id: 'time',
      title: "Learning Time",
      value: `${Math.floor(stats.learningTimeMinutes / 60)}h ${stats.learningTimeMinutes % 60}m Today`,
      subtitle: "+35m more than yesterday",
      icon: Award,
      color: "from-amber-500 to-orange-600",
      bgColor: "bg-amber-50 dark:bg-amber-950/40",
      borderColor: "border-amber-200 dark:border-amber-800",
      textColor: "text-amber-600 dark:text-amber-400",
      tab: 'planner'
    },
    {
      id: 'tasks',
      title: "Completed Tasks",
      value: `${stats.completedTasks} Tasks`,
      subtitle: "85% weekly completion rate",
      icon: CheckCircle2,
      color: "from-teal-500 to-cyan-600",
      bgColor: "bg-teal-50 dark:bg-teal-950/40",
      borderColor: "border-teal-200 dark:border-teal-800",
      textColor: "text-teal-600 dark:text-teal-400",
      tab: 'assignments'
    },
    {
      id: 'streak',
      title: "Current Streak",
      value: `${stats.currentStreak} Days 🔥`,
      subtitle: "Level 8 Student • 2,450 XP",
      icon: Flame,
      color: "from-rose-500 to-pink-600",
      bgColor: "bg-rose-50 dark:bg-rose-950/40",
      borderColor: "border-rose-200 dark:border-rose-800",
      textColor: "text-rose-600 dark:text-rose-400",
      tab: 'dashboard'
    }
  ];

  return (
    <div className="space-y-4 my-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="w-2 h-6 rounded-full bg-emerald-500"></span>
          <h2 className="text-lg md:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Today's Overview
          </h2>
        </div>
        <span className="text-xs font-bold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full">
          Live Sync • Phase 3
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {cards.map((card, idx) => {
          const Icon = card.icon;
          return (
            <motion.div
              key={card.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              onClick={() => onTabChange(card.tab)}
              className={`p-5 rounded-2xl ${card.bgColor} border ${card.borderColor} shadow-sm hover:shadow-md transition-all duration-200 group cursor-pointer relative overflow-hidden`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${card.color} text-white flex items-center justify-center shadow-md transform group-hover:scale-110 transition-transform duration-300 shrink-0`}>
                  <Icon className="w-6 h-6" />
                </div>
                
                <span className="text-slate-400 dark:text-slate-500 group-hover:text-slate-600 dark:group-hover:text-slate-300 transition-colors">
                  <ArrowUpRight className="w-5 h-5 transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </span>
              </div>

              <div className="mt-4">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  {card.title}
                </h3>
                <div className="text-xl md:text-2xl font-extrabold text-slate-900 dark:text-white mt-1">
                  {card.value}
                </div>
                <p className={`text-xs font-semibold mt-1.5 ${card.textColor}`}>
                  {card.subtitle}
                </p>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
