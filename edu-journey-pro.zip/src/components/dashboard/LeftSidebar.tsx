import React from 'react';
import { motion } from 'motion/react';
import { 
  LayoutDashboard, BookOpen, Clock, Calendar, MessageSquare, 
  Library, ShoppingBag, Briefcase, Compass, Scan, Settings, 
  LogOut, Sparkles, Lock, ChevronRight, Award, Flame 
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { DashboardNavTab, LearningStreak } from '../../types.js';

interface LeftSidebarProps {
  activeTab: DashboardNavTab;
  onSelectTab: (tab: DashboardNavTab) => void;
  isOpen: boolean;
  onCloseMobile: () => void;
  streak: LearningStreak;
}

export const LeftSidebar: React.FC<LeftSidebarProps> = ({
  activeTab,
  onSelectTab,
  isOpen,
  onCloseMobile,
  streak
}) => {
  const { logout, user } = useAuth();

  const menuGroups = [
    {
      title: 'Core Study Workspace',
      items: [
        { id: 'dashboard' as DashboardNavTab, label: 'Dashboard Home', icon: LayoutDashboard, isSoon: false },
        { id: 'buddy' as DashboardNavTab, label: 'Edu Buddy AI', icon: Sparkles, badge: 'MENTOR', isSoon: false },
        { id: 'assignments' as DashboardNavTab, label: 'Assignments', icon: BookOpen, badge: '3 Due', isSoon: false },
        { id: 'planner' as DashboardNavTab, label: 'Study Planner', icon: Clock, isSoon: false },
        { id: 'calendar' as DashboardNavTab, label: 'School Calendar', icon: Calendar, isSoon: false },
      ]
    },
    {
      title: 'AI & Social Learning',
      items: [
        { id: 'feed' as DashboardNavTab, label: 'Edu Feed', icon: MessageSquare, badge: 'PRO', isSoon: true },
        { id: 'chat' as DashboardNavTab, label: 'Edu Chat', icon: MessageSquare, badge: 'PRO', isSoon: true },
        { id: 'library' as DashboardNavTab, label: 'Edu Library', icon: Library, badge: '1000+ Docs', isSoon: true },
        { id: 'market' as DashboardNavTab, label: 'Edu Market', icon: ShoppingBag, badge: 'Rewards', isSoon: true },
      ]
    },
    {
      title: 'Specialized Tools',
      items: [
        { id: 'workspace' as DashboardNavTab, label: 'Workspace Canvas', icon: Briefcase, isSoon: true },
        { id: 'scanner' as DashboardNavTab, label: 'AI Math Scanner', icon: Scan, isSoon: true },
        { id: 'career' as DashboardNavTab, label: 'Career Hub', icon: Compass, isSoon: true },
      ]
    }
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden" 
          onClick={onCloseMobile} 
        />
      )}

      <aside className={`fixed top-16 sm:top-20 bottom-0 left-0 z-40 w-64 sm:w-72 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col justify-between transition-transform duration-300 ease-in-out ${
        isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
      }`}>
        {/* Navigation List */}
        <div className="flex-1 overflow-y-auto py-4 px-3 sm:px-4 space-y-6 no-scrollbar">
          
          {/* Quick Streak & Rank Banner */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-[#0A2540] to-emerald-950 text-white border border-emerald-500/20 shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center font-extrabold text-sm border border-amber-500/30">
                <Flame className="w-4 h-4 text-amber-400 fill-amber-400" />
              </div>
              <div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-300">
                  {streak.currentStreak} Day Streak 🔥
                </div>
                <div className="text-xs font-extrabold text-white">
                  Level 8 • {streak.xpTotal} XP
                </div>
              </div>
            </div>
          </div>

          {menuGroups.map((group, gIdx) => (
            <div key={gIdx} className="space-y-1.5">
              <h3 className="px-3 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                {group.title}
              </h3>

              <div className="space-y-1">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;

                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onSelectTab(item.id);
                        if (isOpen) onCloseMobile();
                      }}
                      className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition group ${
                        isActive
                          ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md shadow-emerald-500/20'
                          : item.isSoon
                          ? 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                          : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-3 truncate">
                        <Icon className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                          isActive ? 'text-white' : 'text-emerald-600 dark:text-emerald-400'
                        }`} />
                        <span className="truncate">{item.label}</span>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        {item.badge && (
                          <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                            isActive
                              ? 'bg-white/20 text-white'
                              : item.isSoon
                              ? 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                              : 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20'
                          }`}>
                            {item.badge}
                          </span>
                        )}
                        {item.isSoon && !item.badge && (
                          <Lock className="w-3 h-3 text-slate-400" />
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

        </div>

        {/* Bottom Sidebar Actions */}
        <div className="p-3 sm:p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 space-y-1">
          <button
            onClick={() => {
              onSelectTab('settings');
              if (isOpen) onCloseMobile();
            }}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'settings'
                ? 'bg-slate-900 text-white dark:bg-slate-800 shadow-md'
                : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800'
            }`}
          >
            <Settings className="w-4 h-4 text-slate-500 dark:text-slate-400" />
            <span>Dashboard Settings</span>
          </button>

          <button
            onClick={() => {
              logout();
              if (isOpen) onCloseMobile();
            }}
            className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition"
          >
            <LogOut className="w-4 h-4" />
            <span>Log Out</span>
          </button>
        </div>

      </aside>
    </>
  );
};
