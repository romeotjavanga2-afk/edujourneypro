import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  User, Moon, Sun, Lock, Bell, Globe, HelpCircle, 
  Check, ArrowLeft, Shield, Smartphone, Mail, LogOut,
  Eye, Glasses, Type, Sparkles, RotateCcw, ZapOff
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { useAccessibility, ContrastPreset, TextScaling } from '../../context/AccessibilityContext.js';

interface SettingsViewProps {
  onBackToDashboard: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onBackToDashboard }) => {
  const { user, logout } = useAuth();
  const { 
    isHighContrast, 
    contrastPreset, 
    textSize, 
    isDyslexicFont, 
    reduceMotion,
    setContrastPreset, 
    setTextSize, 
    setIsDyslexicFont, 
    setReduceMotion,
    resetAccessibilitySettings 
  } = useAccessibility();

  const [activeTab, setActiveTab] = useState<'account' | 'appearance' | 'accessibility' | 'privacy' | 'notifications'>('account');
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>('system');
  const [emailNotifs, setEmailNotifs] = useState(true);
  const [pushNotifs, setPushNotifs] = useState(true);
  const [privacy, setPrivacy] = useState('Friends Only');

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-5xl mx-auto py-6 sm:py-10 px-4 sm:px-6"
    >
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToDashboard}
            className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 transition shadow-sm"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Dashboard Settings
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              Manage your student account preferences, theme & notifications
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Settings Sidebar */}
        <div className="bg-white dark:bg-slate-900 p-3 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-1 h-fit">
          <button
            onClick={() => setActiveTab('account')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'account' 
                ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20' 
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <User className="w-4 h-4" />
            <span>Account Profile</span>
          </button>

          <button
            onClick={() => setActiveTab('appearance')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'appearance' 
                ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20' 
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <Sun className="w-4 h-4" />
            <span>Appearance & Theme</span>
          </button>

          <button
            onClick={() => setActiveTab('accessibility')}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'accessibility' 
                ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20' 
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <Eye className="w-4 h-4 text-amber-400" />
              <span>Accessibility & High Contrast</span>
            </div>
            {isHighContrast && (
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('notifications')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'notifications' 
                ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20' 
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <Bell className="w-4 h-4" />
            <span>Notifications</span>
          </button>

          <button
            onClick={() => setActiveTab('privacy')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'privacy' 
                ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20' 
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>Privacy & Safety</span>
          </button>

          <div className="pt-3 mt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={logout}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs sm:text-sm font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition"
            >
              <LogOut className="w-4 h-4" />
              <span>Log Out</span>
            </button>
          </div>
        </div>

        {/* Settings Content */}
        <div className="md:col-span-3 bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
          
          {activeTab === 'account' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">Account Information</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">Your registered Namibian school registry profile</p>
              </div>

              <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white text-2xl font-extrabold shadow-md">
                  {user?.fullName ? user.fullName[0] : 'S'}
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900 dark:text-white">{user?.fullName || 'Tangi Amukwaya'}</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{user?.email || 'student@edujourney.na'}</p>
                  <span className="inline-block mt-1 px-2.5 py-0.5 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold border border-emerald-500/20">
                    Verified Student • Grade 11
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">School</label>
                  <input
                    type="text"
                    disabled
                    value="Delta Secondary School Windhoek"
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-xs font-semibold border border-slate-200 dark:border-slate-700 cursor-not-allowed"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Region</label>
                  <input
                    type="text"
                    disabled
                    value="Khomas Region"
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-xs font-semibold border border-slate-200 dark:border-slate-700 cursor-not-allowed"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end">
                <button
                  onClick={() => alert('Profile update saved successfully!')}
                  className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold text-xs shadow-md transition"
                >
                  Save Profile Changes
                </button>
              </div>
            </div>
          )}

          {activeTab === 'appearance' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">Appearance & Theme</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">Customize how Edu Journey Pro looks on your device</p>
              </div>

              <div className="grid grid-cols-3 gap-4">
                {(['light', 'dark', 'system'] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setTheme(t)}
                    className={`p-4 rounded-2xl border-2 text-center font-bold text-xs capitalize transition ${
                      theme === t 
                        ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400' 
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
                    }`}
                  >
                    {t === 'light' ? '☀️ Light' : t === 'dark' ? '🌙 Dark' : '💻 System'}
                  </button>
                ))}
              </div>

              {/* Quick Prompt to High Contrast */}
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <Glasses className="w-5 h-5 text-amber-500 shrink-0" />
                  <div>
                    <h4 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white">Looking for High Contrast Mode?</h4>
                    <p className="text-[11px] text-slate-600 dark:text-slate-400">Switch to the Accessibility & High Contrast tab for WCAG AAA low-vision options.</p>
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab('accessibility')}
                  className="px-3.5 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-extrabold text-xs shrink-0 hover:bg-amber-400 transition"
                >
                  Configure
                </button>
              </div>
            </div>
          )}

          {activeTab === 'accessibility' && (
            <div className="space-y-8">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">Inclusive Design & Accessibility</h2>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                      WCAG AAA Standard
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Empowering students with visual impairments, dyslexia, and low vision with high contrast reading tools.
                  </p>
                </div>

                <button
                  onClick={resetAccessibilitySettings}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 transition shrink-0"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Default</span>
                </button>
              </div>

              {/* 1. Contrast Presets */}
              <div className="space-y-3">
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-2">
                  <Eye className="w-4 h-4 text-emerald-500" />
                  <span>High Contrast Color Profile</span>
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  
                  {/* Standard */}
                  <button
                    type="button"
                    onClick={() => setContrastPreset('standard')}
                    className={`p-4 rounded-2xl border-2 text-left transition flex items-start justify-between ${
                      contrastPreset === 'standard'
                        ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/20 ring-2 ring-emerald-500/20'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                    }`}
                  >
                    <div>
                      <div className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white flex items-center gap-2">
                        <span>Standard Colors</span>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300">Default</span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">Standard vibrant theme with balanced contrast.</p>
                    </div>
                    {contrastPreset === 'standard' && <Check className="w-5 h-5 text-emerald-500 shrink-0 ml-2" />}
                  </button>

                  {/* Yellow on Black */}
                  <button
                    type="button"
                    onClick={() => setContrastPreset('yellow-on-black')}
                    className={`p-4 rounded-2xl border-2 text-left transition flex items-start justify-between ${
                      contrastPreset === 'yellow-on-black'
                        ? 'border-amber-400 bg-black text-amber-300 ring-2 ring-amber-400'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                    }`}
                  >
                    <div>
                      <div className="font-extrabold text-xs sm:text-sm text-amber-300 flex items-center gap-2">
                        <span>Yellow on Black</span>
                        <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-amber-400 text-slate-950">WCAG 19:1</span>
                      </div>
                      <p className="text-[11px] text-amber-200/80 mt-1">Maximum legibility for low vision & photo-sensitivity.</p>
                    </div>
                    {contrastPreset === 'yellow-on-black' && <Check className="w-5 h-5 text-amber-400 shrink-0 ml-2" />}
                  </button>

                  {/* High Contrast Dark */}
                  <button
                    type="button"
                    onClick={() => setContrastPreset('high-contrast-dark')}
                    className={`p-4 rounded-2xl border-2 text-left transition flex items-start justify-between ${
                      contrastPreset === 'high-contrast-dark'
                        ? 'border-emerald-400 bg-slate-950 text-emerald-400 ring-2 ring-emerald-400'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                    }`}
                  >
                    <div>
                      <div className="font-extrabold text-xs sm:text-sm text-emerald-400 flex items-center gap-2">
                        <span>Vivid High Contrast Dark</span>
                        <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">15:1</span>
                      </div>
                      <p className="text-[11px] text-slate-300 mt-1">Ultra-deep dark canvas with bright emerald & white text.</p>
                    </div>
                    {contrastPreset === 'high-contrast-dark' && <Check className="w-5 h-5 text-emerald-400 shrink-0 ml-2" />}
                  </button>

                  {/* High Contrast Light */}
                  <button
                    type="button"
                    onClick={() => setContrastPreset('high-contrast-light')}
                    className={`p-4 rounded-2xl border-2 text-left transition flex items-start justify-between ${
                      contrastPreset === 'high-contrast-light'
                        ? 'border-black bg-white text-black ring-2 ring-black'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                    }`}
                  >
                    <div>
                      <div className="font-extrabold text-xs sm:text-sm text-black flex items-center gap-2">
                        <span>Bold High Contrast Light</span>
                        <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-slate-900 text-white">21:1</span>
                      </div>
                      <p className="text-[11px] text-slate-800 mt-1">Pure white background with thick pitch-black text & borders.</p>
                    </div>
                    {contrastPreset === 'high-contrast-light' && <Check className="w-5 h-5 text-black shrink-0 ml-2" />}
                  </button>

                </div>
              </div>

              {/* 2. Text Scaling */}
              <div className="space-y-3">
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-2">
                  <Type className="w-4 h-4 text-emerald-500" />
                  <span>Text Size & Reader Scale</span>
                </label>

                <div className="grid grid-cols-3 gap-3">
                  {(['normal', 'large', 'xlarge'] as const).map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setTextSize(s)}
                      className={`p-3.5 rounded-2xl border-2 text-center font-extrabold text-xs transition ${
                        textSize === s
                          ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400'
                          : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
                      }`}
                    >
                      <div className={s === 'xlarge' ? 'text-lg' : s === 'large' ? 'text-base' : 'text-sm'}>
                        {s === 'normal' ? '100% (Default)' : s === 'large' ? '115% (Large)' : '125% (X-Large)'}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* 3. Specialized Reading Options */}
              <div className="space-y-3">
                <label className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-2">
                  <Glasses className="w-4 h-4 text-emerald-500" />
                  <span>Specialized Cognitive & Dyslexia Support</span>
                </label>

                <div className="space-y-3">
                  <label className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 cursor-pointer">
                    <div className="space-y-0.5">
                      <div className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white flex items-center gap-2">
                        <span>Dyslexia-Friendly High-Legibility Font</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">Hyperlegible</span>
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        Increases character distinction and letter spacing to prevent visual crowding while reading curriculum text.
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={isDyslexicFont}
                      onChange={(e) => setIsDyslexicFont(e.target.checked)}
                      className="w-5 h-5 rounded text-emerald-600 focus:ring-emerald-500 accent-emerald-500 shrink-0 ml-4"
                    />
                  </label>

                  <label className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 cursor-pointer">
                    <div className="space-y-0.5">
                      <div className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white flex items-center gap-2">
                        <span>Reduce Motion & Animations</span>
                        <ZapOff className="w-3.5 h-3.5 text-slate-400" />
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        Disables decorative transitions and floating background graphics for students with motion sensitivity or visual fatigue.
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={reduceMotion}
                      onChange={(e) => setReduceMotion(e.target.checked)}
                      className="w-5 h-5 rounded text-emerald-600 focus:ring-emerald-500 accent-emerald-500 shrink-0 ml-4"
                    />
                  </label>
                </div>
              </div>

              {/* Live Curriculum Reading Preview */}
              <div className="p-5 rounded-3xl bg-slate-900 text-white border-2 border-slate-700 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-[11px] font-black uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    Live Curriculum Contrast Preview (NSSCO Grade 11)
                  </span>
                  <span className="text-[10px] text-slate-400">Active Preset: {contrastPreset}</span>
                </div>

                <div className="space-y-2 text-xs leading-relaxed">
                  <h4 className="font-extrabold text-sm text-white">Mathematics Paper 2 Example Question:</h4>
                  <p className="text-slate-200">
                    Solve the quadratic equation <strong className="text-amber-300 font-mono">2x² + 5x - 3 = 0</strong> using the quadratic formula or factorisation method. Show all steps clearly.
                  </p>
                </div>

                <div className="pt-2 flex items-center justify-between text-[11px] border-t border-slate-800">
                  <span className="text-emerald-400 font-bold">✓ High-Contrast Assist Active</span>
                  <span className="text-slate-400">Focus Ring: 3px Bright Outline</span>
                </div>
              </div>

            </div>
          )}

          {activeTab === 'notifications' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">Notification Preferences</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">Control study reminders, assignment alerts, and streak reminders</p>
              </div>

              <div className="space-y-4">
                <label className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 cursor-pointer">
                  <div>
                    <div className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white">Email Study Reminders</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">Receive daily summary of pending homework</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={emailNotifs}
                    onChange={(e) => setEmailNotifs(e.target.checked)}
                    className="w-5 h-5 rounded text-emerald-600 focus:ring-emerald-500"
                  />
                </label>

                <label className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 cursor-pointer">
                  <div>
                    <div className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white">Streak Protection Alerts</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">Notify if your 7-day learning streak is about to break</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={pushNotifs}
                    onChange={(e) => setPushNotifs(e.target.checked)}
                    className="w-5 h-5 rounded text-emerald-600 focus:ring-emerald-500"
                  />
                </label>
              </div>
            </div>
          )}

          {activeTab === 'privacy' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">Privacy & Safety</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">Manage who can view your study progress and XP rank</p>
              </div>

              <div className="space-y-3">
                {['Public (School Only)', 'Friends Only', 'Private (Only Me)'].map((p) => (
                  <label
                    key={p}
                    onClick={() => setPrivacy(p)}
                    className={`flex items-center justify-between p-4 rounded-2xl border-2 cursor-pointer transition ${
                      privacy === p 
                        ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/30' 
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                    }`}
                  >
                    <span className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">{p}</span>
                    {privacy === p && <Check className="w-5 h-5 text-emerald-500" />}
                  </label>
                ))}
              </div>
            </div>
          )}

        </div>
      </div>
    </motion.div>
  );
};
