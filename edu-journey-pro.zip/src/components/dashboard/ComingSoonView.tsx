import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Sparkles, Bell, ArrowLeft, Lock, BookOpen, MessageSquare, 
  Library, ShoppingBag, Briefcase, Compass, Scan, Calendar, CheckCircle2 
} from 'lucide-react';

interface ComingSoonViewProps {
  moduleName: string;
  onBackToDashboard: () => void;
}

export const ComingSoonView: React.FC<ComingSoonViewProps> = ({ moduleName, onBackToDashboard }) => {
  const [notified, setNotified] = useState(false);

  const getModuleDetails = (name: string) => {
    switch (name.toLowerCase()) {
      case 'assignments':
        return {
          title: 'Assignments & Grade Feedback',
          desc: 'Submit homework, upload essays, take NSSCO mock quizzes, and receive instant AI teacher feedback and rubric grading.',
          icon: BookOpen,
          color: 'from-blue-600 to-indigo-600',
          phase: 'Phase 4: Academic Execution'
        };
      case 'calendar':
        return {
          title: 'Smart School Calendar',
          desc: 'Manage study timetable schedules, track national exam dates, sync school events, and set custom study reminder alerts.',
          icon: Calendar,
          color: 'from-purple-600 to-violet-600',
          phase: 'Phase 4: Academic Execution'
        };
      case 'edu feed':
      case 'feed':
        return {
          title: 'Edu Feed Community',
          desc: 'Connect with classmates across Namibia, share revision notes, discuss NSSCO topics, and celebrate learning streaks.',
          icon: MessageSquare,
          color: 'from-emerald-600 to-teal-600',
          phase: 'Phase 5: Social Learning & Community'
        };
      case 'edu chat':
      case 'chat':
        return {
          title: 'Edu Chat Study Groups',
          desc: 'Real-time peer study chats, group video study sessions, and moderated classroom discussion forums.',
          icon: MessageSquare,
          color: 'from-cyan-600 to-blue-600',
          phase: 'Phase 5: Social Learning & Community'
        };
      case 'edu library':
      case 'library':
        return {
          title: 'Edu Library & Resource Vault',
          desc: 'Access 1,000+ NSSCO syllabus guides, downloadable past exam papers, interactive flashcards, and video lessons.',
          icon: Library,
          color: 'from-amber-500 to-orange-600',
          phase: 'Phase 6: Resource Library & Study Tools'
        };
      case 'edu market':
      case 'market':
        return {
          title: 'Edu Market Rewards Store',
          desc: 'Redeem your earned study XP for cool digital avatar accessories, custom themes, scholarship raffle tickets, and stationery vouchers.',
          icon: ShoppingBag,
          color: 'from-rose-500 to-pink-600',
          phase: 'Phase 7: Gamification & Rewards'
        };
      case 'workspace':
        return {
          title: 'Collaborative Study Workspace',
          desc: 'Digital whiteboard canvas, markdown note taker with equation editor, and real-time collaborative study documents.',
          icon: Briefcase,
          color: 'from-teal-600 to-emerald-600',
          phase: 'Phase 6: Resource Library & Study Tools'
        };
      case 'career hub':
      case 'career':
        return {
          title: 'Namibian Career & Scholarship Hub',
          desc: 'Explore UNAM & NUST university degree requirements, discover scholarship bursaries, and match your strengths with future careers.',
          icon: Compass,
          color: 'from-indigo-600 to-purple-600',
          phase: 'Phase 8: Career Exploration Hub'
        };
      case 'scanner':
      case 'ai scanner':
        return {
          title: 'AI Homework & Math Scanner',
          desc: 'Use your device camera to scan handwritten math equations or science questions for step-by-step AI explanation.',
          icon: Scan,
          color: 'from-slate-700 to-slate-900',
          phase: 'Phase 6: Resource Library & Study Tools'
        };
      default:
        return {
          title: `${moduleName} Module`,
          desc: 'This specialized student feature is currently in active development and will be released in an upcoming update.',
          icon: Lock,
          color: 'from-emerald-600 to-blue-600',
          phase: 'Upcoming Release'
        };
    }
  };

  const details = getModuleDetails(moduleName);
  const Icon = details.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto py-8 sm:py-12 px-4 sm:px-6"
    >
      <button
        onClick={onBackToDashboard}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/80 font-bold text-xs shadow-sm mb-6 transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Dashboard</span>
      </button>

      <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 sm:p-12 border border-slate-200 dark:border-slate-800 shadow-xl text-center relative overflow-hidden">
        {/* Background Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-gradient-to-br from-emerald-500/10 via-blue-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col items-center max-w-2xl mx-auto space-y-6">
          <div className={`w-20 h-20 sm:w-24 sm:h-24 rounded-3xl bg-gradient-to-tr ${details.color} text-white flex items-center justify-center shadow-xl shadow-emerald-500/20 transform hover:rotate-6 transition-transform duration-300`}>
            <Icon className="w-10 h-10 sm:w-12 sm:h-12" />
          </div>

          <div className="space-y-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-extrabold text-xs border border-emerald-500/20">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{details.phase}</span>
            </span>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              {details.title}
            </h1>
          </div>

          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
            {details.desc}
          </p>

          <div className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700/80 w-full text-left">
            <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
              Why is this locked in Phase 3?
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              In accordance with our strict step-by-step modular architecture, Phase 3 focuses entirely on perfecting the **Student Dashboard & Core Navigation Shell**. Once you verify the layout, responsiveness, and widget synergy of this phase, we will unlock the interactive study modules in subsequent updates!
            </p>
          </div>

          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3 w-full sm:w-auto">
            {notified ? (
              <button
                disabled
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-emerald-500 text-white font-extrabold text-sm shadow-md cursor-default"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>You're on the VIP Launch List!</span>
              </button>
            ) : (
              <button
                onClick={() => setNotified(true)}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-extrabold text-sm shadow-lg shadow-emerald-500/25 transition transform active:scale-95"
              >
                <Bell className="w-4 h-4 animate-bounce" style={{ animationDuration: '2s' }} />
                <span>Notify Me When Released</span>
              </button>
            )}

            <button
              onClick={onBackToDashboard}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-sm transition"
            >
              <span>Return Home</span>
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
