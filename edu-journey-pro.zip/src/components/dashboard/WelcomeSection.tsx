import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Flame, Award, BookOpen, Clock } from 'lucide-react';
import { User, LearningStreak } from '../../types.js';
import { NamibianGreeting } from './NamibianGreeting.js';

interface WelcomeSectionProps {
  user: User;
  streak: LearningStreak;
  motivationalQuote: {
    quote: string;
    author: string;
  };
}

export const WelcomeSection: React.FC<WelcomeSectionProps> = ({ user, streak, motivationalQuote }) => {
  const firstName = user.fullName ? user.fullName.split(' ')[0] : 'Student';

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-r from-[#0A2540] via-[#0F3558] to-emerald-900 rounded-3xl p-6 md:p-8 text-white shadow-xl relative overflow-hidden border border-emerald-500/20"
    >
      {/* Background Decorative Elements */}
      <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-0 right-1/4 w-48 h-48 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
        
        {/* Left Info */}
        <div className="space-y-4 max-w-2xl">
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-emerald-300 text-xs font-bold border border-white/15">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Phase 3 Dashboard Active</span>
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 backdrop-blur-md text-amber-300 text-xs font-extrabold border border-amber-500/30">
              <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400 animate-bounce" style={{ animationDuration: '2s' }} />
              <span>{streak.currentStreak} Day Streak 🔥</span>
            </span>
            {user.grade && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 text-blue-200 text-xs font-medium border border-blue-400/20">
                <BookOpen className="w-3.5 h-3.5" />
                <span>{user.grade}</span>
              </span>
            )}
          </div>

          {/* Multilingual Cycling Namibian Greeting */}
          <NamibianGreeting userName={firstName} />

          <p className="text-slate-200 text-sm md:text-base leading-relaxed italic border-l-2 border-emerald-400 pl-3.5 py-0.5">
            "{motivationalQuote.quote}"
          </p>
          <p className="text-xs text-slate-400 font-medium pl-3.5">
            — {motivationalQuote.author}
          </p>
        </div>

        {/* Right Stats Pills */}
        <div className="flex sm:flex-col justify-end gap-3 shrink-0">
          <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/10 flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-300">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-300 font-medium">Total XP Earned</div>
              <div className="text-base font-extrabold text-white">{streak.xpTotal.toLocaleString()} XP</div>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/10 flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center text-blue-300">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-300 font-medium">Today's Target</div>
              <div className="text-base font-extrabold text-white">2.5h / 3.0h</div>
            </div>
          </div>
        </div>

      </div>
    </motion.div>
  );
};
