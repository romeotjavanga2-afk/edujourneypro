import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Globe, Volume2, Sparkles, Pause, Play, ChevronRight, RefreshCw } from 'lucide-react';

export interface NamibianGreetingItem {
  id: string;
  language: string;
  nativeName: string;
  greetingMorning: string;
  greetingAfternoon: string;
  greetingEvening: string;
  pronunciation: string;
  region: string;
  culturalNote: string;
}

export const NAMIBIAN_LANGUAGES: NamibianGreetingItem[] = [
  {
    id: 'en',
    language: 'English',
    nativeName: 'English',
    greetingMorning: 'Good Morning',
    greetingAfternoon: 'Good Afternoon',
    greetingEvening: 'Good Evening',
    pronunciation: 'Good Mor-ning',
    region: 'Official Language • Nationwide',
    culturalNote: 'Official language of instruction in Namibian schools.',
  },
  {
    id: 'oshiwambo',
    language: 'Oshiwambo',
    nativeName: 'Oshiwambo',
    greetingMorning: 'Wa lele po',
    greetingAfternoon: 'Wa uhala po',
    greetingEvening: 'Wa tokwa po',
    pronunciation: 'Wah-leh-leh-po / Wah-oo-hah-lah-po',
    region: 'Northern & Central Namibia',
    culturalNote: 'Spoken by over 50% of the Namibian population.',
  },
  {
    id: 'otjiherero',
    language: 'Otjiherero',
    nativeName: 'Otjiherero',
    greetingMorning: 'Moro',
    greetingAfternoon: 'Tjerve',
    greetingEvening: 'Tjiperke',
    pronunciation: 'Moh-roh / Tcher-veh',
    region: 'Omaheke, Otjozondjupa & Erongo',
    culturalNote: 'Rich oral tradition and heritage across central Namibia.',
  },
  {
    id: 'khoekhoegowab',
    language: 'Khoekhoegowab',
    nativeName: 'Khoekhoegowab',
    greetingMorning: '!Gâi ǁgoas',
    greetingAfternoon: '!Gâi tsês',
    greetingEvening: '!Gâi ǃoes',
    pronunciation: 'Gai-tsh-es (Damara/Nama click language)',
    region: 'Hardap, ǁKaras, Erongo & Kunene',
    culturalNote: 'Indigenous Khoisan language family with distinct click sounds.',
  },
  {
    id: 'silozi',
    language: 'Silozi',
    nativeName: 'Silozi',
    greetingMorning: 'Muzuhile',
    greetingAfternoon: 'Mwatolela',
    greetingEvening: 'Manani',
    pronunciation: 'Moo-zoo-hee-leh / Mwah-toh-leh-lah',
    region: 'Zambezi Region & Caprivi Strip',
    culturalNote: 'Vibrant lingua franca of northeastern Namibia.',
  },
];

interface NamibianGreetingProps {
  userName: string;
  className?: string;
  compact?: boolean;
}

export const NamibianGreeting: React.FC<NamibianGreetingProps> = ({
  userName,
  className = '',
  compact = false,
}) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [timeOfDay, setTimeOfDay] = useState<'morning' | 'afternoon' | 'evening'>('morning');

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 12) setTimeOfDay('morning');
    else if (hour < 17) setTimeOfDay('afternoon');
    else setTimeOfDay('evening');
  }, []);

  // Cycle languages every 4 seconds unless paused
  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % NAMIBIAN_LANGUAGES.length);
    }, 4000);

    return () => clearInterval(interval);
  }, [isPaused]);

  const currentLang = NAMIBIAN_LANGUAGES[currentIndex];

  const getGreetingText = (item: NamibianGreetingItem) => {
    if (timeOfDay === 'morning') return item.greetingMorning;
    if (timeOfDay === 'afternoon') return item.greetingAfternoon;
    return item.greetingEvening;
  };

  const activeGreeting = getGreetingText(currentLang);

  if (compact) {
    return (
      <div className={`flex items-center gap-2 ${className}`}>
        <AnimatePresence mode="wait">
          <motion.span
            key={currentLang.id}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.3 }}
            className="font-extrabold text-white"
          >
            {activeGreeting}, <span className="text-emerald-300">{userName}</span>!
          </motion.span>
        </AnimatePresence>
        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
          {currentLang.language}
        </span>
      </div>
    );
  }

  return (
    <div className={`space-y-3.5 ${className}`}>
      {/* Top Language Ribbon & Multi-language Badge */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 backdrop-blur-md text-emerald-300 text-xs font-bold border border-emerald-500/30">
            <Globe className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>Inclusive Namibian Education 🇳🇦</span>
          </span>
          <button
            onClick={() => setIsPaused(!isPaused)}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md text-slate-200 hover:text-white text-[11px] font-medium transition border border-white/10"
            title={isPaused ? "Resume auto-cycling" : "Pause auto-cycling"}
          >
            {isPaused ? <Play className="w-3 h-3 text-emerald-400" /> : <Pause className="w-3 h-3 text-amber-300" />}
            <span>{isPaused ? "Play Cycle" : "Auto"}</span>
          </button>
        </div>

        {/* Language selector chips */}
        <div className="flex items-center gap-1 bg-black/20 backdrop-blur-md p-1 rounded-full border border-white/10">
          {NAMIBIAN_LANGUAGES.map((lang, idx) => {
            const isActive = idx === currentIndex;
            return (
              <button
                key={lang.id}
                onClick={() => {
                  setCurrentIndex(idx);
                  setIsPaused(true);
                }}
                className={`px-2.5 py-0.5 text-[11px] font-extrabold rounded-full transition-all duration-200 ${
                  isActive
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-[#0A2540] shadow-md scale-105'
                    : 'text-slate-300 hover:text-white hover:bg-white/10'
                }`}
                title={`${lang.language}: ${getGreetingText(lang)}`}
              >
                {lang.language === 'English' ? 'EN' : lang.language}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Animated Greeting Headline */}
      <div className="relative min-h-[44px] flex items-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentLang.id + timeOfDay}
            initial={{ opacity: 0, y: 12, filter: 'blur(4px)' }}
            animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
            exit={{ opacity: 0, y: -12, filter: 'blur(4px)' }}
            transition={{ duration: 0.35, ease: 'easeOut' }}
            className="w-full flex flex-col sm:flex-row sm:items-baseline gap-2 sm:gap-3"
          >
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight text-white flex flex-wrap items-center gap-2">
              <span className="bg-gradient-to-r from-white via-slate-100 to-emerald-200 bg-clip-text text-transparent">
                {activeGreeting},
              </span>
              <span className="text-emerald-300 drop-shadow-sm">{userName}!</span>
              <span className="inline-block animate-wave text-2xl sm:text-3xl">👋</span>
            </h1>

            {/* Language Tag Badge next to greeting */}
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-white/10 backdrop-blur-sm text-emerald-300 text-xs font-bold border border-white/15 w-fit">
              <Sparkles className="w-3 h-3 text-amber-300" />
              <span>{currentLang.language} ({currentLang.nativeName})</span>
            </span>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Pronunciation & Region Subtitle Ribbon */}
      <AnimatePresence mode="wait">
        <motion.div
          key={`sub-${currentLang.id}`}
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 10 }}
          transition={{ duration: 0.25 }}
          className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-300 font-medium bg-white/5 backdrop-blur-sm px-3.5 py-1.5 rounded-xl border border-white/10 w-fit"
        >
          <div className="flex items-center gap-1 text-emerald-300">
            <Volume2 className="w-3.5 h-3.5" />
            <span className="font-semibold">{currentLang.pronunciation}</span>
          </div>
          <span className="text-slate-500">•</span>
          <div className="text-slate-300">
            <span>{currentLang.region}</span>
          </div>
          <span className="hidden sm:inline text-slate-500">•</span>
          <div className="hidden sm:inline text-slate-400 italic">
            {currentLang.culturalNote}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
