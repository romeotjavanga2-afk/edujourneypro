import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, CheckCircle2, Bot, User, BookOpen, Sparkles, X, Check } from 'lucide-react';
import { NotificationItem } from '../../types.js';

interface NotificationsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  onMarkAllRead: () => void;
}

export const NotificationsPanel: React.FC<NotificationsPanelProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAllRead
}) => {
  if (!isOpen) return null;

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-40 bg-transparent" onClick={onClose} />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        className="absolute right-4 top-16 z-50 w-full max-w-sm sm:max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[480px]"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 to-[#0A2540] text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base flex items-center gap-2">
                <span>Notifications</span>
                {unreadCount > 0 && (
                  <span className="bg-emerald-500 text-[#0A2540] text-[10px] font-extrabold px-2 py-0.5 rounded-full">
                    {unreadCount} New
                  </span>
                )}
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {unreadCount > 0 && (
              <button
                onClick={onMarkAllRead}
                className="text-xs font-bold text-emerald-300 hover:text-white px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 transition flex items-center gap-1"
                title="Mark all as read"
              >
                <Check className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Mark read</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2 divide-y divide-slate-100 dark:divide-slate-800/60">
          {notifications.length > 0 ? (
            notifications.map((n) => {
              const isWelcome = n.type === 'welcome';
              const isBuddy = n.type === 'edubuddy';
              const isProfile = n.type === 'profile';
              
              const Icon = isWelcome ? Sparkles : isBuddy ? Bot : isProfile ? User : BookOpen;
              const color = isWelcome ? 'bg-amber-500 text-white' : isBuddy ? 'bg-emerald-500 text-white' : 'bg-blue-500 text-white';

              return (
                <div
                  key={n.id}
                  className={`p-3.5 rounded-2xl flex items-start gap-3.5 transition ${
                    n.isRead 
                      ? 'bg-transparent opacity-80' 
                      : 'bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-500/20'
                  }`}
                >
                  <div className={`w-9 h-9 rounded-xl ${color} flex items-center justify-center shrink-0 shadow-sm mt-0.5`}>
                    <Icon className="w-4 h-4" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white truncate">
                        {n.title}
                      </h4>
                      {!n.isRead && (
                        <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                      )}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed line-clamp-2">
                      {n.message}
                    </p>
                    <span className="text-[10px] text-slate-400 dark:text-slate-500 mt-1.5 block font-medium">
                      {n.createdAt || 'Recent'}
                    </span>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="py-12 text-center text-slate-400 font-medium text-xs">
              No notifications yet. You're all caught up! 🎉
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 text-center">
          <span className="text-[11px] font-bold text-slate-400">
            Edu Journey Pro • Live Alerts
          </span>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
