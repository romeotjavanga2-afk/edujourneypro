import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  BookOpen, Plus, Search, Filter, Clock, AlertCircle, CheckCircle2,
  ChevronRight, Sparkles, Bot, FileText, Link as LinkIcon, Paperclip,
  Trash2, Edit3, Send, MessageSquare, ShieldCheck, ArrowLeft, CheckSquare,
  Square, Pin, Bookmark, Mic, AlertTriangle, ExternalLink, Calendar as CalendarIcon
} from 'lucide-react';
import { Assignment, AssignmentChecklistItem, AssignmentNote } from '../../types.js';

interface AssignmentsViewProps {
  onBackToDashboard: () => void;
  onOpenPlanner?: () => void;
  onOpenCalendar?: () => void;
}

export const AssignmentsView: React.FC<AssignmentsViewProps> = ({
  onBackToDashboard,
  onOpenPlanner,
  onOpenCalendar
}) => {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');
  
  // Modals & Active State
  const [activeAssignment, setActiveAssignment] = useState<Assignment | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  
  // New assignment form state
  const [newTitle, setNewTitle] = useState('');
  const [newSubject, setNewSubject] = useState('Mathematics');
  const [newTeacher, setNewTeacher] = useState('');
  const [newDueDate, setNewDueDate] = useState('');
  const [newPriority, setNewPriority] = useState<'Low' | 'Medium' | 'High'>('Medium');
  const [newEstimatedTime, setNewEstimatedTime] = useState(60);
  const [newDifficulty, setNewDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Medium');
  const [newInstructions, setNewInstructions] = useState('');
  const [newTeacherNotes, setNewTeacherNotes] = useState('');

  // AI Assist state in Workspace
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState<{
    title?: string;
    text?: string;
    suggestedChecklist?: string[];
    suggestedResources?: Array<{ title: string; url: string }>;
  } | null>(null);
  const [customAiPrompt, setCustomAiPrompt] = useState('');

  // New checklist item state
  const [newChecklistTitle, setNewChecklistTitle] = useState('');
  // New note state
  const [newNoteContent, setNewNoteContent] = useState('');
  const [newNoteType, setNewNoteType] = useState<'student' | 'voice'>('student');

  useEffect(() => {
    fetchAssignments();
  }, []);

  const fetchAssignments = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/assignments');
      const json = await res.json();
      if (json.success) {
        setAssignments(json.data);
      }
    } catch (e) {
      console.error('Failed to load assignments', e);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateAssignment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newDueDate) return;

    try {
      const res = await fetch('/api/assignments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newTitle,
          subject: newSubject,
          teacher: newTeacher || 'Class Teacher',
          due_date: newDueDate,
          priority: newPriority,
          estimated_time: newEstimatedTime,
          difficulty: newDifficulty,
          instructions: newInstructions,
          teacher_notes: newTeacherNotes,
          status: 'Not Started'
        })
      });
      const json = await res.json();
      if (json.success) {
        setAssignments([json.data, ...assignments]);
        setIsCreateModalOpen(false);
        // reset form
        setNewTitle('');
        setNewInstructions('');
        setNewTeacherNotes('');
      }
    } catch (e) {
      console.error('Failed to create assignment', e);
    }
  };

  const handleUpdateStatus = async (id: number | string, status: string, progressVal?: number) => {
    try {
      const res = await fetch(`/api/assignments/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status,
          progress: progressVal !== undefined ? progressVal : status === 'Completed' ? 100 : status === 'In Progress' ? 50 : 0
        })
      });
      const json = await res.json();
      if (json.success) {
        const updatedList = assignments.map(a => a.id === json.data.id ? json.data : a);
        setAssignments(updatedList);
        if (activeAssignment?.id === json.data.id) {
          setActiveAssignment(json.data);
        }
      }
    } catch (e) {
      console.error('Failed to update status', e);
    }
  };

  const handleDeleteAssignment = async (id: number | string) => {
    if (!window.confirm('Are you sure you want to delete this assignment?')) return;
    try {
      await fetch(`/api/assignments/${id}`, { method: 'DELETE' });
      setAssignments(assignments.filter(a => a.id !== id));
      if (activeAssignment?.id === id) setActiveAssignment(null);
    } catch (e) {
      console.error('Failed to delete assignment', e);
    }
  };

  // Checklist actions
  const handleAddChecklist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeAssignment || !newChecklistTitle.trim()) return;
    try {
      const res = await fetch(`/api/assignments/${activeAssignment.id}/checklist`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: newChecklistTitle, checklist_type: 'todo' })
      });
      const json = await res.json();
      if (json.success) {
        const updatedChecklist = [...(activeAssignment.checklist || []), json.data];
        const updated = { ...activeAssignment, checklist: updatedChecklist };
        setActiveAssignment(updated);
        setAssignments(assignments.map(a => a.id === updated.id ? updated : a));
        setNewChecklistTitle('');
      }
    } catch (e) {
      console.error('Failed to add checklist item', e);
    }
  };

  const handleToggleChecklist = async (itemId: number | string) => {
    if (!activeAssignment) return;
    try {
      const res = await fetch(`/api/assignments/${activeAssignment.id}/checklist/${itemId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' }
      });
      const json = await res.json();
      if (json.success) {
        // Refresh active assignment to get recalculated progress
        const refreshRes = await fetch(`/api/assignments/${activeAssignment.id}`);
        const refreshJson = await refreshRes.json();
        if (refreshJson.success) {
          setActiveAssignment(refreshJson.data);
          setAssignments(assignments.map(a => a.id === refreshJson.data.id ? refreshJson.data : a));
        }
      }
    } catch (e) {
      console.error('Failed to toggle checklist', e);
    }
  };

  // Note actions
  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeAssignment || !newNoteContent.trim()) return;
    try {
      const res = await fetch(`/api/assignments/${activeAssignment.id}/notes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: newNoteContent, note_type: newNoteType, is_pinned: false })
      });
      const json = await res.json();
      if (json.success) {
        const updatedNotes = [json.data, ...(activeAssignment.notes || [])];
        const updated = { ...activeAssignment, notes: updatedNotes };
        setActiveAssignment(updated);
        setAssignments(assignments.map(a => a.id === updated.id ? updated : a));
        setNewNoteContent('');
      }
    } catch (e) {
      console.error('Failed to add note', e);
    }
  };

  // AI Assistance action
  const handleAiAssist = async (action: string, promptText = '') => {
    if (!activeAssignment) return;
    try {
      setAiLoading(true);
      const res = await fetch(`/api/assignments/${activeAssignment.id}/ai-assist`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, customPrompt: promptText })
      });
      const json = await res.json();
      if (json.success) {
        setAiResponse(json.data);
        if (json.data.updatedAssignment) {
          setActiveAssignment(json.data.updatedAssignment);
          setAssignments(assignments.map(a => a.id === json.data.updatedAssignment.id ? json.data.updatedAssignment : a));
        }
      }
    } catch (e) {
      console.error('AI assist failed', e);
    } finally {
      setAiLoading(false);
    }
  };

  // Filtered assignments
  const filteredAssignments = assignments.filter(a => {
    const matchesSearch = a.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (a.teacher && a.teacher.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesSubject = selectedSubject === 'All' || a.subject === selectedSubject;
    const matchesStatus = selectedStatus === 'All' || a.status === selectedStatus;
    return matchesSearch && matchesSubject && matchesStatus;
  });

  const subjectsList = ['All', 'Mathematics', 'Physical Science', 'English First Language', 'Computer Studies', 'Geography', 'History'];
  const statusList = ['All', 'In Progress', 'Not Started', 'Draft', 'Completed', 'Reviewed'];

  const getPriorityBadge = (p?: string) => {
    switch (p) {
      case 'High':
        return 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20';
      case 'High':
      case 'Medium':
        return 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20';
      default:
        return 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20';
    }
  };

  const getStatusBadge = (s?: string) => {
    switch (s) {
      case 'Completed':
      case 'Reviewed':
        return 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20';
      case 'In Progress':
        return 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20';
      case 'Draft':
        return 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20';
      default:
        return 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/20';
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner & Header */}
      <div className="bg-gradient-to-r from-[#0A2540] via-slate-900 to-emerald-950 rounded-3xl p-6 md:p-8 text-white shadow-xl border border-emerald-500/20 relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-60 h-60 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-3 border border-emerald-500/30">
              <BookOpen className="w-3.5 h-3.5" />
              <span>Phase 4 Academic Workspace</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">
              Assignment System & Workspace
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-xl">
              Manage your NSSCO school deadlines, break tasks into milestones with AI assistance, and track your study progress.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-[#0A2540] font-extrabold text-sm shadow-lg shadow-emerald-500/25 transition transform active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Assignment</span>
            </button>
            <button
              onClick={onBackToDashboard}
              className="inline-flex items-center gap-2 px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-sm transition"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </button>
          </div>
        </div>

        {/* Quick Summary Badges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-white/10 text-center">
          <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
            <div className="text-xl md:text-2xl font-extrabold text-white">{assignments.length}</div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Total Assigned</div>
          </div>
          <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
            <div className="text-xl md:text-2xl font-extrabold text-amber-400">
              {assignments.filter(a => a.status === 'In Progress' || a.status === 'Draft').length}
            </div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">In Progress</div>
          </div>
          <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
            <div className="text-xl md:text-2xl font-extrabold text-rose-400">
              {assignments.filter(a => a.priority === 'High' && a.status !== 'Completed').length}
            </div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">High Priority</div>
          </div>
          <div className="bg-white/5 rounded-2xl p-3 border border-white/5">
            <div className="text-xl md:text-2xl font-extrabold text-emerald-400">
              {assignments.filter(a => a.status === 'Completed' || a.status === 'Reviewed').length}
            </div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Completed</div>
          </div>
        </div>
      </div>

      {/* Filters & Search Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search assignments by title, subject, or teacher..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 max-w-full">
            {subjectsList.slice(0, 4).map(sub => (
              <button
                key={sub}
                onClick={() => setSelectedSubject(sub)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                  selectedSubject === sub
                    ? 'bg-[#0A2540] text-white dark:bg-emerald-600'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {sub}
              </button>
            ))}
          </div>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold border-0 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            {statusList.map(st => (
              <option key={st} value={st}>Status: {st}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Assignment List */}
      {loading ? (
        <div className="p-12 text-center text-slate-500">Loading assignments...</div>
      ) : filteredAssignments.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-12 text-center border border-slate-200 dark:border-slate-800">
          <div className="w-16 h-16 rounded-3xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto mb-4 text-slate-400">
            <BookOpen className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-slate-800 dark:text-white">No assignments found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
            We couldn't find any assignments matching your current search or filter criteria. Try selecting "All" subjects.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredAssignments.map((item) => {
            const isDone = item.status === 'Completed' || item.status === 'Reviewed';
            return (
              <motion.div
                key={item.id}
                whileHover={{ y: -3 }}
                onClick={() => {
                  setActiveAssignment(item);
                  setAiResponse(null);
                }}
                className={`bg-white dark:bg-slate-900 rounded-3xl p-6 border transition cursor-pointer flex flex-col justify-between shadow-sm hover:shadow-md ${
                  isDone
                    ? 'border-emerald-500/30 bg-emerald-50/20 dark:bg-emerald-950/10'
                    : 'border-slate-200 dark:border-slate-800'
                }`}
              >
                <div>
                  {/* Card Header: Subject & Priority */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider truncate">
                      {item.subject}
                    </span>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border ${getPriorityBadge(item.priority)}`}>
                        {item.priority} Priority
                      </span>
                      <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border ${getStatusBadge(item.status)}`}>
                        {item.status}
                      </span>
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className={`text-base font-extrabold tracking-tight mb-2 leading-snug ${
                    isDone ? 'line-through text-slate-500 dark:text-slate-400' : 'text-slate-900 dark:text-white'
                  }`}>
                    {item.title}
                  </h3>

                  {/* Teacher & Difficulty */}
                  <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400 mb-4">
                    <span>👨‍🏫 {item.teacher || 'Class Teacher'}</span>
                    <span>•</span>
                    <span>⚡ {item.difficulty}</span>
                    <span>•</span>
                    <span>⏱️ ~{item.estimated_time}m</span>
                  </div>
                </div>

                <div>
                  {/* Progress bar */}
                  <div className="space-y-1.5 mb-4">
                    <div className="flex items-center justify-between text-[11px] font-bold">
                      <span className="text-slate-500">Milestone Progress</span>
                      <span className="text-emerald-600 dark:text-emerald-400">{item.progress}%</span>
                    </div>
                    <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full transition-all duration-500"
                        style={{ width: `${item.progress}%` }}
                      />
                    </div>
                  </div>

                  {/* Footer: Due date & Open Workspace button */}
                  <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800/80">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600 dark:text-slate-300">
                      <CalendarIcon className="w-3.5 h-3.5 text-emerald-500" />
                      <span>Due: {item.due_date}</span>
                    </div>
                    <span className="inline-flex items-center gap-1 text-xs font-extrabold text-emerald-600 dark:text-emerald-400 group-hover:underline">
                      <span>Workspace</span>
                      <ChevronRight className="w-4 h-4" />
                    </span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* ========================================================= */}
      {/* IMMERSIVE ASSIGNMENT WORKSPACE MODAL */}
      {/* ========================================================= */}
      <AnimatePresence>
        {activeAssignment && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col"
            >
              {/* Modal Header */}
              <div className="p-6 bg-gradient-to-r from-[#0A2540] to-slate-900 text-white flex items-start justify-between gap-4 shrink-0 border-b border-emerald-500/20">
                <div>
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[11px] font-bold uppercase tracking-wider">
                      {activeAssignment.subject}
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${getPriorityBadge(activeAssignment.priority)}`}>
                      {activeAssignment.priority} Priority
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${getStatusBadge(activeAssignment.status)}`}>
                      {activeAssignment.status}
                    </span>
                  </div>
                  <h2 className="text-xl md:text-2xl font-extrabold tracking-tight">
                    {activeAssignment.title}
                  </h2>
                  <div className="flex items-center gap-4 text-xs text-slate-300 mt-1">
                    <span>👨‍🏫 Teacher: {activeAssignment.teacher || 'Class Teacher'}</span>
                    <span>•</span>
                    <span>📅 Due Date: {activeAssignment.due_date}</span>
                    <span>•</span>
                    <span>⏱️ Est: {activeAssignment.estimated_time} mins</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleDeleteAssignment(activeAssignment.id)}
                    title="Delete Assignment"
                    className="p-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setActiveAssignment(null)}
                    className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition"
                  >
                    Close Workspace
                  </button>
                </div>
              </div>

              {/* Modal Body (Scrollable Split View) */}
              <div className="flex-1 overflow-y-auto p-6 space-y-8">
                
                {/* Status & Progress Quick Changer */}
                <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-500 dark:text-slate-400">Update Status:</span>
                    <div className="flex flex-wrap gap-1.5">
                      {['Not Started', 'In Progress', 'Draft', 'Completed'].map(st => (
                        <button
                          key={st}
                          onClick={() => handleUpdateStatus(activeAssignment.id, st)}
                          className={`px-3 py-1 rounded-xl text-xs font-extrabold transition ${
                            activeAssignment.status === st
                              ? 'bg-emerald-600 text-white shadow-sm'
                              : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          {st}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-slate-500 dark:text-slate-400">Progress:</span>
                    <span className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400">{activeAssignment.progress}%</span>
                  </div>
                </div>

                {/* Instructions & Teacher Notes */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white dark:bg-slate-800/40 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                    <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-emerald-500" />
                      <span>Assignment Instructions</span>
                    </h4>
                    <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                      {activeAssignment.instructions || 'No specific instructions provided. Complete the assigned topic in your syllabus.'}
                    </p>
                  </div>

                  <div className="bg-amber-50/50 dark:bg-amber-950/10 p-5 rounded-2xl border border-amber-500/20 space-y-2">
                    <h4 className="text-xs font-extrabold uppercase tracking-wider text-amber-600 dark:text-amber-400 flex items-center gap-1.5">
                      <AlertCircle className="w-4 h-4 text-amber-500" />
                      <span>Teacher Notes & Tips ({activeAssignment.teacher})</span>
                    </h4>
                    <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                      {activeAssignment.teacher_notes || 'Focus on clarity, show all calculation steps, and double-check your final answers before handing in.'}
                    </p>
                  </div>
                </div>

                {/* ========================================================= */}
                {/* 🤖 EDU BUDDY AI ACADEMIC ASSISTANT PANEL */}
                {/* ========================================================= */}
                <div className="bg-gradient-to-br from-emerald-950/40 via-[#0A2540]/60 to-slate-900 p-6 rounded-3xl border border-emerald-500/30 text-white space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-[#0A2540] flex items-center justify-center font-extrabold shadow-md">
                        <Bot className="w-6 h-6 animate-pulse" />
                      </div>
                      <div>
                        <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                          <span>Edu Buddy AI Study Mentor</span>
                          <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] uppercase font-bold">Live Guidance</span>
                        </h3>
                        <p className="text-xs text-slate-300">
                          Interactive tutor trained on Namibian NSSCO standards
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* ETHICS GUARANTEE BANNER */}
                  <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-3 flex items-start gap-3 text-xs text-emerald-200">
                    <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>
                      <strong>Academic Honor Guarantee:</strong> Edu Buddy will teach, explain concepts, and structure your study plan. It will never generate answers that encourage cheating.
                    </span>
                  </div>

                  {/* AI Quick Prompt Pills */}
                  <div className="flex flex-wrap gap-2 pt-1">
                    <button
                      onClick={() => handleAiAssist('explain')}
                      disabled={aiLoading}
                      className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold transition flex items-center gap-1.5"
                    >
                      <span>📖 Explain Objective</span>
                    </button>
                    <button
                      onClick={() => handleAiAssist('breakdown')}
                      disabled={aiLoading}
                      className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold transition flex items-center gap-1.5"
                    >
                      <span>⚡ Actionable Task Breakdown</span>
                    </button>
                    <button
                      onClick={() => handleAiAssist('estimate')}
                      disabled={aiLoading}
                      className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold transition flex items-center gap-1.5"
                    >
                      <span>⏱️ Pomodoro Strategy</span>
                    </button>
                    <button
                      onClick={() => handleAiAssist('resources')}
                      disabled={aiLoading}
                      className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold transition flex items-center gap-1.5"
                    >
                      <span>📚 Suggest Resources</span>
                    </button>
                    <button
                      onClick={() => handleAiAssist('encourage')}
                      disabled={aiLoading}
                      className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold transition flex items-center gap-1.5"
                    >
                      <span>🌟 Give Me Motivation</span>
                    </button>
                  </div>

                  {/* Custom AI Chat Input */}
                  <div className="relative flex items-center">
                    <input
                      type="text"
                      placeholder="Ask Edu Buddy anything about this assignment (e.g. 'How do I factor quadratic polynomials?')..."
                      value={customAiPrompt}
                      onChange={(e) => setCustomAiPrompt(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && customAiPrompt.trim()) {
                          handleAiAssist('custom', customAiPrompt);
                          setCustomAiPrompt('');
                        }
                      }}
                      className="w-full pl-4 pr-24 py-3 rounded-2xl bg-white/10 border border-white/20 text-sm font-medium text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-400"
                    />
                    <button
                      onClick={() => {
                        if (customAiPrompt.trim()) {
                          handleAiAssist('custom', customAiPrompt);
                          setCustomAiPrompt('');
                        }
                      }}
                      disabled={aiLoading || !customAiPrompt.trim()}
                      className="absolute right-2 px-4 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 text-[#0A2540] font-extrabold text-xs transition transform active:scale-95 disabled:opacity-50"
                    >
                      {aiLoading ? 'Thinking...' : 'Ask AI'}
                    </button>
                  </div>

                  {/* AI Response Display Box */}
                  {aiLoading && (
                    <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-3 animate-pulse text-xs text-slate-300">
                      <Sparkles className="w-4 h-4 text-emerald-400 animate-spin" />
                      <span>Edu Buddy is analyzing curriculum guidelines and preparing study advice...</span>
                    </div>
                  )}

                  {aiResponse && !aiLoading && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-5 rounded-2xl bg-white/10 border border-emerald-500/30 space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-extrabold text-emerald-300 flex items-center gap-1.5">
                          <Sparkles className="w-4 h-4 text-amber-300" />
                          <span>{aiResponse.title || 'Edu Buddy Guidance'}</span>
                        </h4>
                        <button
                          onClick={() => setAiResponse(null)}
                          className="text-xs text-slate-400 hover:text-white"
                        >
                          Dismiss
                        </button>
                      </div>

                      <div className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-wrap font-sans">
                        {aiResponse.text}
                      </div>

                      {/* If checklist items suggested, show auto-add button */}
                      {aiResponse.suggestedChecklist && aiResponse.suggestedChecklist.length > 0 && (
                        <div className="pt-3 border-t border-white/10 flex items-center justify-between">
                          <span className="text-xs font-bold text-emerald-300">
                            💡 {aiResponse.suggestedChecklist.length} action milestones suggested!
                          </span>
                          <button
                            onClick={() => handleAiAssist('checklist')}
                            className="px-3 py-1.5 rounded-xl bg-emerald-500 text-[#0A2540] font-extrabold text-xs hover:bg-emerald-400 transition"
                          >
                            + Add All to Assignment Checklist
                          </button>
                        </div>
                      )}
                    </motion.div>
                  )}
                </div>

                {/* ========================================================= */}
                {/* INTERACTIVE CHECKLIST SECTION */}
                {/* ========================================================= */}
                <div className="bg-white dark:bg-slate-800/40 p-6 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                      <CheckSquare className="w-5 h-5 text-emerald-500" />
                      <span>Milestone Checklist ({activeAssignment.checklist?.filter(i => i.is_completed).length || 0} / {activeAssignment.checklist?.length || 0})</span>
                    </h3>
                    <span className="text-xs font-bold text-slate-500">
                      Checking items automatically updates your progress percentage!
                    </span>
                  </div>

                  <div className="space-y-2">
                    {activeAssignment.checklist && activeAssignment.checklist.length > 0 ? (
                      activeAssignment.checklist.map((item) => (
                        <div
                          key={item.id}
                          onClick={() => handleToggleChecklist(item.id)}
                          className={`flex items-center justify-between p-3.5 rounded-2xl border transition cursor-pointer ${
                            item.is_completed
                              ? 'bg-emerald-50/30 dark:bg-emerald-950/10 border-emerald-500/30 text-slate-500 dark:text-slate-400'
                              : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            {item.is_completed ? (
                              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                            ) : (
                              <Square className="w-5 h-5 text-slate-400 shrink-0" />
                            )}
                            <span className={`text-sm font-bold ${item.is_completed ? 'line-through' : ''}`}>
                              {item.title}
                            </span>
                          </div>
                          <span className="text-[10px] uppercase font-extrabold px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                            {item.checklist_type || 'todo'}
                          </span>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-slate-400 italic">No checklist items yet. Ask Edu Buddy for a Task Breakdown or add a custom item below!</p>
                    )}
                  </div>

                  {/* Add Checklist Form */}
                  <form onSubmit={handleAddChecklist} className="flex gap-2 pt-2">
                    <input
                      type="text"
                      placeholder="Add a milestone task (e.g. 'Solve Exercise 1 to 5')..."
                      value={newChecklistTitle}
                      onChange={(e) => setNewChecklistTitle(e.target.value)}
                      className="flex-1 px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                    <button
                      type="submit"
                      disabled={!newChecklistTitle.trim()}
                      className="px-4 py-2.5 rounded-xl bg-[#0A2540] dark:bg-emerald-600 text-white font-bold text-xs transition hover:opacity-90 disabled:opacity-50"
                    >
                      + Add Item
                    </button>
                  </form>
                </div>

                {/* ========================================================= */}
                {/* STUDY NOTES & VOICE REMINDERS SECTION */}
                {/* ========================================================= */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white dark:bg-slate-800/40 p-6 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-4 flex flex-col justify-between">
                    <div>
                      <h3 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2 mb-3">
                        <Bookmark className="w-5 h-5 text-purple-500" />
                        <span>Study Notes & Reminders ({activeAssignment.notes?.length || 0})</span>
                      </h3>

                      <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
                        {activeAssignment.notes && activeAssignment.notes.length > 0 ? (
                          activeAssignment.notes.map((note) => (
                            <div key={note.id} className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 space-y-1.5">
                              <div className="flex items-center justify-between">
                                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-purple-500/10 text-purple-600 dark:text-purple-400">
                                  {note.note_type === 'voice' ? '🎙️ Voice Note' : '📝 Student Note'}
                                </span>
                                {note.is_pinned && <Pin className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />}
                              </div>
                              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">{note.content}</p>
                            </div>
                          ))
                        ) : (
                          <p className="text-xs text-slate-400 italic">No notes saved yet. Add your study reminders below.</p>
                        )}
                      </div>
                    </div>

                    <form onSubmit={handleAddNote} className="flex gap-2 pt-4 border-t border-slate-100 dark:border-slate-700/80 mt-4">
                      <input
                        type="text"
                        placeholder="Add study reminder or note..."
                        value={newNoteContent}
                        onChange={(e) => setNewNoteContent(e.target.value)}
                        className="flex-1 px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                      <button
                        type="submit"
                        disabled={!newNoteContent.trim()}
                        className="px-4 py-2 rounded-xl bg-purple-600 text-white font-bold text-xs transition hover:bg-purple-500 disabled:opacity-50"
                      >
                        Add Note
                      </button>
                    </form>
                  </div>

                  {/* Reference Resources & Attachments */}
                  <div className="bg-white dark:bg-slate-800/40 p-6 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-4">
                    <h3 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                      <LinkIcon className="w-5 h-5 text-blue-500" />
                      <span>Resources & Attachments</span>
                    </h3>

                    <div className="space-y-3">
                      <div>
                        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Web References</h4>
                        <div className="space-y-1.5">
                          {activeAssignment.resources && activeAssignment.resources.length > 0 ? (
                            activeAssignment.resources.map((res: any, idx: number) => (
                              <a
                                key={idx}
                                href={res.url || '#'}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-between p-2.5 rounded-xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-500/20 text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
                              >
                                <span className="truncate">{res.title || 'Resource Link'}</span>
                                <ExternalLink className="w-3.5 h-3.5 shrink-0 ml-2" />
                              </a>
                            ))
                          ) : (
                            <p className="text-xs text-slate-400 italic">No web links attached.</p>
                          )}
                        </div>
                      </div>

                      <div className="pt-2 border-t border-slate-100 dark:border-slate-700/80">
                        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Uploaded Files</h4>
                        <div className="space-y-1.5">
                          {activeAssignment.attachments && activeAssignment.attachments.length > 0 ? (
                            activeAssignment.attachments.map((att: any, idx: number) => (
                              <div key={idx} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300">
                                <span className="flex items-center gap-2 truncate">
                                  <Paperclip className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                                  <span className="truncate">{att.title || 'Document.pdf'}</span>
                                </span>
                                <span className="text-[10px] text-slate-400">{att.size || '120 KB'}</span>
                              </div>
                            ))
                          ) : (
                            <p className="text-xs text-slate-400 italic">No file attachments.</p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ========================================================= */}
      {/* CREATE NEW ASSIGNMENT MODAL */}
      {/* ========================================================= */}
      <AnimatePresence>
        {isCreateModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-2xl w-full p-6 sm:p-8 space-y-6 overflow-hidden"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div>
                  <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
                    Create New Assignment
                  </h3>
                  <p className="text-xs text-slate-500">
                    Add school homework, project deadlines, or lab reports to your workspace
                  </p>
                </div>
                <button
                  onClick={() => setIsCreateModalOpen(false)}
                  className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-white transition font-bold text-xs"
                >
                  Cancel
                </button>
              </div>

              <form onSubmit={handleCreateAssignment} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                    Assignment Title *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Algebra Exercise 42 or Lab Report on Newton's Laws"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                      Subject *
                    </label>
                    <select
                      value={newSubject}
                      onChange={(e) => setNewSubject(e.target.value)}
                      className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="Mathematics">Mathematics</option>
                      <option value="Physical Science">Physical Science</option>
                      <option value="English First Language">English First Language</option>
                      <option value="Computer Studies">Computer Studies</option>
                      <option value="Geography">Geography</option>
                      <option value="History">History</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                      Due Date *
                    </label>
                    <input
                      type="date"
                      required
                      value={newDueDate}
                      onChange={(e) => setNewDueDate(e.target.value)}
                      className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                      Priority Level
                    </label>
                    <select
                      value={newPriority}
                      onChange={(e: any) => setNewPriority(e.target.value)}
                      className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="High">High Priority 🔥</option>
                      <option value="Medium">Medium Priority ⭐</option>
                      <option value="Low">Low Priority 💡</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                      Difficulty
                    </label>
                    <select
                      value={newDifficulty}
                      onChange={(e: any) => setNewDifficulty(e.target.value)}
                      className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="Easy">Easy 🟢</option>
                      <option value="Medium">Medium 🟡</option>
                      <option value="Hard">Hard 🔴</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                      Est. Time (Mins)
                    </label>
                    <input
                      type="number"
                      value={newEstimatedTime}
                      onChange={(e) => setNewEstimatedTime(Number(e.target.value))}
                      className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                    Teacher Name (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Mr. Kandjii or Ms. Van Zyl"
                    value={newTeacher}
                    onChange={(e) => setNewTeacher(e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                    Specific Instructions / Homework Details
                  </label>
                  <textarea
                    rows={3}
                    placeholder="e.g. Complete questions 1 to 15 on page 42. Show all calculation steps."
                    value={newInstructions}
                    onChange={(e) => setNewInstructions(e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                  />
                </div>

                <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsCreateModalOpen(false)}
                    className="px-5 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold text-xs hover:bg-slate-200 transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 text-[#0A2540] font-extrabold text-xs shadow-lg shadow-emerald-500/25 hover:from-emerald-400 hover:to-teal-500 transition transform active:scale-95"
                  >
                    Save Assignment
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
