import React from 'react';
import { motion } from 'motion/react';
import { Award, Flame, Lock, Sparkles, CheckCircle2, ChevronRight } from 'lucide-react';
import { AchievementItem, LearningStreak } from '../../types.js';

interface AchievementsSectionProps {
  achievements: AchievementItem[];
  streak: LearningStreak;
}

export const AchievementsSection: React.FC<AchievementsSectionProps> = ({ achievements, streak }) => {
  const earnedCount = achievements.filter(a => !a.isLocked).length;

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm my-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-2">
          <span className="w-2 h-6 rounded-full bg-amber-500"></span>
          <div>
            <h2 className="text-lg md:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
              <span>Achievements & Badges</span>
              <span className="text-xs font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 px-2.5 py-0.5 rounded-full border border-amber-500/20">
                {earnedCount} / {achievements.length} Unlocked
              </span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Celebrate your academic milestones and level up your student rank
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 bg-amber-50 dark:bg-amber-950/40 px-4 py-2 rounded-2xl border border-amber-200 dark:border-amber-800/60 self-start sm:self-auto">
          <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center font-extrabold text-sm shadow-sm">
            8
          </div>
          <div>
            <div className="text-[10px] font-extrabold uppercase tracking-wider text-amber-600 dark:text-amber-400">
              Current Rank
            </div>
            <div className="text-xs font-extrabold text-slate-900 dark:text-white">
              Level 8 Student • {streak.xpTotal} XP
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {achievements.map((item, idx) => {
          const isLocked = item.isLocked;
          const progressPercent = Math.min(100, Math.round((item.progress / item.maxProgress) * 100));

          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.05 }}
              className={`p-5 rounded-2xl border transition-all relative overflow-hidden flex flex-col justify-between ${
                isLocked 
                  ? 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 opacity-75' 
                  : 'bg-gradient-to-br from-amber-50/50 via-white to-emerald-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-emerald-950/20 border-amber-200/80 dark:border-amber-800/50 shadow-sm hover:shadow-md'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-inner ${
                    isLocked ? 'bg-slate-200 dark:bg-slate-800 text-slate-400' : 'bg-gradient-to-tr from-amber-400 to-yellow-300 shadow-amber-500/20'
                  }`}>
                    {item.icon}
                  </div>

                  <span className={`text-xs font-extrabold px-2.5 py-1 rounded-full border flex items-center gap-1 ${
                    isLocked ? 'bg-slate-200 dark:bg-slate-800 text-slate-500 border-slate-300 dark:border-slate-700' : 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30'
                  }`}>
                    {isLocked ? (
                      <>
                        <Lock className="w-3 h-3" />
                        <span>Locked</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3 h-3 text-amber-500 fill-amber-500" />
                        <span>+{item.xp} XP</span>
                      </>
                    )}
                  </span>
                </div>

                <div className="mt-3">
                  <h3 className={`font-extrabold text-base ${isLocked ? 'text-slate-600 dark:text-slate-400' : 'text-slate-900 dark:text-white'}`}>
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 font-medium">
                    {item.description}
                  </p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80">
                <div className="flex items-center justify-between text-xs font-bold mb-1 text-slate-500 dark:text-slate-400">
                  <span>Progress</span>
                  <span>{item.progress} / {item.maxProgress} ({progressPercent}%)</span>
                </div>
                <div className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden p-0.5">
                  <div 
                    className={`h-full rounded-full transition-all duration-500 ${
                      isLocked ? 'bg-slate-400 dark:bg-slate-600' : 'bg-gradient-to-r from-amber-500 to-emerald-500'
                    }`}
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
