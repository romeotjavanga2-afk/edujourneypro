import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, Bell, Bot, User, Settings, LogOut, Home, 
  Sparkles, ChevronDown, Menu, X, Shield, Eye 
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { useAccessibility } from '../../context/AccessibilityContext.js';
import { NotificationItem } from '../../types.js';
import { OfflineStatusBadge } from '../common/OfflineStatusBadge.js';

interface TopNavbarProps {
  onOpenSearch: () => void;
  onOpenChat: () => void;
  onOpenOfflineHub: () => void;
  onToggleSidebar: () => void;
  isSidebarOpen: boolean;
  notifications: NotificationItem[];
  onMarkAllRead: () => void;
  onToggleNotifications: () => void;
  isNotificationsOpen: boolean;
  onSelectTab: (tab: any) => void;
}

export const TopNavbar: React.FC<TopNavbarProps> = ({
  onOpenSearch,
  onOpenChat,
  onOpenOfflineHub,
  onToggleSidebar,
  isSidebarOpen,
  notifications,
  onToggleNotifications,
  isNotificationsOpen,
  onSelectTab
}) => {
  const { user, logout, setCurrentView } = useAuth();
  const { isHighContrast, toggleHighContrast } = useAccessibility();
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);

  const unreadCount = notifications.filter(n => !n.isRead).length;
  const firstName = user?.fullName ? user.fullName.split(' ')[0] : 'Student';
  const initial = user?.fullName ? user.fullName[0] : 'S';

  return (
    <header className="sticky top-0 z-30 w-full bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-center justify-between gap-3 sm:gap-4">
        
        {/* Left: Hamburger (mobile/tablet) & Brand Logo */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleSidebar}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition lg:hidden"
            aria-label="Toggle navigation menu"
          >
            {isSidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          <div 
            onClick={() => onSelectTab('dashboard')} 
            className="flex items-center gap-2.5 cursor-pointer group shrink-0"
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#0A2540] via-[#0F3558] to-emerald-600 flex items-center justify-center shadow-md transform group-hover:scale-105 transition-transform">
              <span className="text-white font-extrabold text-lg">E</span>
            </div>
            <div className="hidden sm:block">
              <span className="text-base font-extrabold tracking-tight text-slate-900 dark:text-white">
                Edu Journey <span className="text-emerald-600 dark:text-emerald-400">Pro</span>
              </span>
              <span className="block text-[10px] font-extrabold uppercase tracking-widest text-emerald-600 dark:text-emerald-400">
                Namibian Academy
              </span>
            </div>
          </div>
        </div>

        {/* Center: Interactive Search Trigger */}
        <div className="flex-1 max-w-md mx-2 sm:mx-6">
          <button
            onClick={onOpenSearch}
            className="w-full flex items-center justify-between px-4 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800/80 hover:bg-slate-200/70 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 text-xs sm:text-sm font-semibold border border-transparent hover:border-emerald-500/30 transition shadow-inner group"
          >
            <div className="flex items-center gap-2.5 truncate">
              <Search className="w-4 h-4 text-emerald-500 shrink-0 group-hover:scale-110 transition-transform" />
              <span className="truncate">Search lessons, quizzes, or ask Edu Buddy...</span>
            </div>
            <span className="hidden md:inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-white dark:bg-slate-900 text-[10px] font-mono font-bold text-slate-400 border border-slate-200 dark:border-slate-700 shrink-0">
              ⌘K
            </span>
          </button>
        </div>

        {/* Right: Actions & User Avatar */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          
          {/* High Contrast Mode Quick Toggle Button */}
          <button
            type="button"
            onClick={toggleHighContrast}
            aria-pressed={isHighContrast}
            title={isHighContrast ? "High Contrast Mode Active (Click to disable)" : "Enable High Contrast Mode for low vision"}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border font-bold text-xs transition ${
              isHighContrast
                ? 'bg-amber-400 text-slate-950 border-amber-400 shadow-md ring-2 ring-amber-400/40'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-200'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden lg:inline">{isHighContrast ? 'Contrast ON' : 'High Contrast'}</span>
          </button>

          {/* Offline Ready & Storage Badge */}
          <OfflineStatusBadge onOpenOfflineHub={onOpenOfflineHub} />

          {/* Ask Edu Buddy AI Button */}
          <button
            onClick={onOpenChat}
            className="hidden sm:inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-[#0A2540] font-extrabold text-xs shadow-md shadow-emerald-500/20 transition transform active:scale-95"
            title="Chat with Edu Buddy AI mentor"
          >
            <Bot className="w-4 h-4 animate-bounce" style={{ animationDuration: '3s' }} />
            <span>Ask Edu Buddy</span>
          </button>

          {/* Notification Bell */}
          <div className="relative">
            <button
              onClick={onToggleNotifications}
              className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-emerald-50 hover:text-emerald-600 dark:hover:bg-emerald-950/40 dark:hover:text-emerald-400 transition relative"
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] font-extrabold flex items-center justify-center border-2 border-white dark:border-slate-900 animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>
          </div>

          {/* Settings shortcut button */}
          <button
            onClick={() => onSelectTab('settings')}
            className="hidden md:flex p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition"
            title="Dashboard Settings"
          >
            <Settings className="w-5 h-5" />
          </button>

          {/* User Profile Avatar & Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="flex items-center gap-2 p-1.5 sm:p-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
            >
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-[#0A2540] to-emerald-600 text-white font-extrabold text-sm flex items-center justify-center shadow-sm">
                {initial}
              </div>
              <div className="hidden lg:block text-left">
                <div className="text-xs font-extrabold text-slate-900 dark:text-white leading-tight">
                  {firstName}
                </div>
                <div className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                  Grade 11 Student
                </div>
              </div>
              <ChevronDown className="w-4 h-4 text-slate-400 hidden lg:block" />
            </button>

            {/* Profile Dropdown Menu */}
            <AnimatePresence>
              {isProfileMenuOpen && (
                <>
                  <div className="fixed inset-0 z-40 bg-transparent" onClick={() => setIsProfileMenuOpen(false)} />
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 10 }}
                    className="absolute right-0 top-14 z-50 w-64 bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden py-2"
                  >
                    <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
                      <div className="font-extrabold text-sm text-slate-900 dark:text-white">
                        {user?.fullName || 'Tangi Amukwaya'}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {user?.email || 'student@edujourney.na'}
                      </div>
                      <span className="inline-block mt-1 px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold">
                        Delta Secondary School
                      </span>
                    </div>

                    <div className="p-2 space-y-1">
                      <button
                        onClick={() => { onSelectTab('settings'); setIsProfileMenuOpen(false); }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                      >
                        <User className="w-4 h-4 text-emerald-500" />
                        <span>Account Profile</span>
                      </button>

                      <button
                        onClick={() => { onSelectTab('settings'); setIsProfileMenuOpen(false); }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                      >
                        <Settings className="w-4 h-4 text-blue-500" />
                        <span>Preferences & Theme</span>
                      </button>

                      <button
                        onClick={() => { setCurrentView('landing'); setIsProfileMenuOpen(false); }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-950/30 transition"
                      >
                        <Home className="w-4 h-4" />
                        <span>Switch to Landing Page</span>
                      </button>
                    </div>

                    <div className="p-2 border-t border-slate-100 dark:border-slate-800 mt-1">
                      <button
                        onClick={() => { logout(); setIsProfileMenuOpen(false); }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Log Out</span>
                      </button>
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>

        </div>

      </div>
    </header>
  );
};
