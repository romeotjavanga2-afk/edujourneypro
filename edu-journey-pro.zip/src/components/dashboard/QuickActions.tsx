import React from 'react';
import { motion } from 'motion/react';
import { 
  BookOpen, Calendar, Clock, MessageSquare, Briefcase, 
  Scan, ArrowRight, Sparkles, Lock, Brain, WifiOff
} from 'lucide-react';

interface QuickActionsProps {
  onTabChange: (tab: any) => void;
  onOpenChat: () => void;
  onOpenOfflineQuiz?: () => void;
}

export const QuickActions: React.FC<QuickActionsProps> = ({ onTabChange, onOpenChat, onOpenOfflineQuiz }) => {
  const actions = [
    {
      id: 'practice-quiz',
      title: 'Practice Quiz',
      desc: 'Test your knowledge offline from cached curriculum',
      icon: Brain,
      color: 'from-emerald-600 to-teal-600',
      action: onOpenOfflineQuiz || (() => onTabChange('planner')),
      badge: 'Offline Mode',
      isOffline: true
    },
    {
      id: 'assignments',
      title: 'Assignments',
      desc: 'Submit homework & check grade feedback',
      icon: BookOpen,
      color: 'from-blue-600 to-indigo-600',
      action: () => onTabChange('assignments'),
      badge: '3 Due'
    },
    {
      id: 'planner',
      title: 'Study Planner',
      desc: 'Organize daily study goals & revision times',
      icon: Clock,
      color: 'from-emerald-600 to-teal-600',
      action: () => onTabChange('planner'),
      badge: 'Active'
    },
    {
      id: 'calendar',
      title: 'Calendar',
      desc: 'View exam dates, school tests & reminders',
      icon: Calendar,
      color: 'from-purple-600 to-violet-600',
      action: () => onTabChange('calendar'),
      badge: 'Events'
    },
    {
      id: 'edubuddy',
      title: 'Ask Edu Buddy',
      desc: 'Get instant AI help with tough questions',
      icon: MessageSquare,
      color: 'from-amber-500 to-orange-600',
      action: onOpenChat,
      badge: 'AI Tutor',
      isAi: true
    },
    {
      id: 'workspace',
      title: 'Workspace',
      desc: 'Collaborative study documents & note tools',
      icon: Briefcase,
      color: 'from-slate-600 to-slate-700',
      action: () => onTabChange('workspace'),
      badge: 'Coming Soon',
      isComingSoon: true
    },
    {
      id: 'scanner',
      title: 'AI Scanner',
      desc: 'Scan notes & equations for instant solutions',
      icon: Scan,
      color: 'from-slate-600 to-slate-700',
      action: () => onTabChange('scanner'),
      badge: 'Coming Soon',
      isComingSoon: true
    }
  ];

  return (
    <div className="space-y-4 my-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="w-2 h-6 rounded-full bg-amber-500"></span>
          <h2 className="text-lg md:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Quick Actions
          </h2>
        </div>
        <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
          Fast Access Tools
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {actions.map((item, idx) => {
          const Icon = item.icon;
          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              onClick={item.action}
              className={`p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all duration-200 group cursor-pointer relative overflow-hidden flex flex-col justify-between ${
                item.isComingSoon ? 'opacity-85 hover:opacity-100' : ''
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${item.color} text-white flex items-center justify-center shadow-md transform group-hover:scale-110 transition-transform duration-300 shrink-0`}>
                  <Icon className="w-5 h-5" />
                </div>

                <span className={`text-xs font-extrabold px-2.5 py-1 rounded-full border ${
                  item.isAi ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30' :
                  item.isComingSoon ? 'bg-slate-100 dark:bg-slate-800 text-slate-500 border-slate-300 dark:border-slate-700' :
                  'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20'
                }`}>
                  {item.badge}
                </span>
              </div>

              <div className="mt-4">
                <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-1.5 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                  <span>{item.title}</span>
                  {item.isComingSoon && <Lock className="w-3.5 h-3.5 text-slate-400" />}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1 line-clamp-2">
                  {item.desc}
                </p>
              </div>

              <div className="mt-4 pt-2.5 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs font-bold text-slate-400 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                <span>{item.isComingSoon ? 'Preview Module' : 'Launch Tool'}</span>
                <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
