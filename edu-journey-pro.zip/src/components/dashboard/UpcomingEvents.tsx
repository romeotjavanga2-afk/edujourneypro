import React from 'react';
import { motion } from 'motion/react';
import { Calendar, Clock, BookOpen, AlertCircle, ChevronRight, Check } from 'lucide-react';
import { UpcomingEventItem } from '../../types.js';

interface UpcomingEventsProps {
  items: UpcomingEventItem[];
  onTabChange: (tab: any) => void;
}

export const UpcomingEvents: React.FC<UpcomingEventsProps> = ({ items, onTabChange }) => {
  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm my-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <span className="w-2 h-6 rounded-full bg-rose-500"></span>
          <div>
            <h2 className="text-lg md:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Upcoming Events & Deadlines
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Stay ahead of school tests, homework & assignments
            </p>
          </div>
        </div>
        <button
          onClick={() => onTabChange('calendar')}
          className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-500 inline-flex items-center gap-1 transition-colors"
        >
          <span>Full Calendar</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {items.map((item, idx) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: idx * 0.05 }}
            onClick={() => onTabChange('calendar')}
            className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 hover:border-emerald-500/50 transition-all cursor-pointer group flex items-start justify-between gap-3"
          >
            <div className="flex items-start gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex flex-col items-center justify-center text-center shadow-sm shrink-0">
                <span className="text-[10px] font-extrabold uppercase text-rose-500">
                  {item.type === 'Homework' ? 'HW' : item.type === 'Test' ? 'TEST' : item.type === 'Exam' ? 'EXAM' : 'DUE'}
                </span>
                <Clock className="w-3.5 h-3.5 text-slate-400 mt-0.5" />
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-md border ${item.badgeColor || 'bg-blue-500/10 text-blue-600 border-blue-500/20'}`}>
                    {item.type}
                  </span>
                  <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                    • {item.subject}
                  </span>
                </div>
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white mt-1 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                  {item.title}
                </h3>
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 dark:text-slate-400 mt-1">
                  <Calendar className="w-3.5 h-3.5 text-emerald-500" />
                  <span>{item.date} at {item.time}</span>
                </div>
              </div>
            </div>

            <div className="shrink-0 self-center">
              <div className="w-8 h-8 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-400 group-hover:text-emerald-600 group-hover:border-emerald-500 transition-all">
                <ChevronRight className="w-4 h-4" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
