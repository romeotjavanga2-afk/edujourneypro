import React from 'react';
import { motion } from 'motion/react';
import { 
  CheckCircle2, Clock, User, School, Bot, Award, 
  BookOpen, Sparkles, ChevronRight 
} from 'lucide-react';
import { RecentActivityItem } from '../../types.js';

interface RecentActivityProps {
  items: RecentActivityItem[];
}

export const RecentActivity: React.FC<RecentActivityProps> = ({ items }) => {
  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm my-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <span className="w-2 h-6 rounded-full bg-purple-600"></span>
          <div>
            <h2 className="text-lg md:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Recent Activity
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Your latest learning milestones & XP gains
            </p>
          </div>
        </div>
        <span className="text-xs font-bold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/50 px-3 py-1 rounded-full border border-purple-200 dark:border-purple-800">
          Timeline
        </span>
      </div>

      <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200 dark:before:bg-slate-800">
        {items.map((item, idx) => {
          const isQuiz = item.activityType === 'quiz';
          const isSession = item.activityType === 'session';
          const isProfile = item.activityType === 'profile';
          const isSchool = item.activityType === 'school';
          const isBuddy = item.activityType === 'edubuddy';

          const Icon = isQuiz ? Award : isSession ? Clock : isProfile ? User : isSchool ? School : isBuddy ? Bot : BookOpen;
          const colorBg = isQuiz ? 'bg-emerald-500 text-white' : isSession ? 'bg-blue-500 text-white' : isProfile ? 'bg-purple-500 text-white' : isSchool ? 'bg-amber-500 text-white' : 'bg-teal-500 text-white';

          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="relative flex items-start justify-between gap-4 group"
            >
              {/* Timeline dot icon */}
              <div className={`absolute -left-6 top-0 w-6 h-6 rounded-full ${colorBg} flex items-center justify-center shadow-md ring-4 ring-white dark:ring-slate-900 z-10`}>
                <Icon className="w-3.5 h-3.5" />
              </div>

              {/* Content */}
              <div className="flex-1 bg-slate-50 dark:bg-slate-800/50 p-3.5 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-colors">
                <div className="flex items-center justify-between gap-2">
                  <h4 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white">
                    {item.title}
                  </h4>
                  <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 shrink-0">
                    {item.timestamp}
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 font-medium mt-1">
                  {item.subtitle}
                </p>
              </div>

              {/* XP Pill */}
              {item.xpEarned > 0 && (
                <div className="shrink-0 self-center">
                  <span className="inline-flex items-center gap-1 text-xs font-extrabold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-2.5 py-1 rounded-full border border-amber-500/20 shadow-sm">
                    <Sparkles className="w-3 h-3 text-amber-500 fill-amber-500" />
                    <span>+{item.xpEarned} XP</span>
                  </span>
                </div>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
