import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, Sparkles, Send, X, Smile, BookOpen, Lightbulb, CheckCircle2 } from 'lucide-react';

interface EduBuddyQuickChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  eduBuddy?: {
    aiName: string;
    aiAvatar: string;
  };
  onLaunchFullSuite?: () => void;
}

export const EduBuddyQuickChatModal: React.FC<EduBuddyQuickChatModalProps> = ({
  isOpen,
  onClose,
  eduBuddy = { aiName: 'Edu Buddy', aiAvatar: 'robot-emerald' },
  onLaunchFullSuite
}) => {
  const [messages, setMessages] = useState<Array<{ sender: 'ai' | 'user'; text: string; time: string }>>([
    {
      sender: 'ai',
      text: `Hello! I'm ${eduBuddy.aiName}, your personal study mentor. How can I assist with your lessons or assignments today?`,
      time: 'Just now'
    }
  ]);
  const [input, setInput] = useState('');
  const [isThinking, setIsThinking] = useState(false);

  if (!isOpen) return null;

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isThinking) return;

    const userMsg = input.trim();
    const newMsgs = [...messages, { sender: 'user' as const, text: userMsg, time: 'Now' }];
    setMessages(newMsgs);
    setInput('');
    setIsThinking(true);

    setTimeout(() => {
      let aiReply = "That's a great question! For NSSCO Mathematics and Science, remember to break down complex formulas into smaller steps. Would you like me to generate a 5-question practice quiz on this topic?";
      if (userMsg.toLowerCase().includes('algebra') || userMsg.toLowerCase().includes('math')) {
        aiReply = "In Algebra, always balance both sides of the equation! Remember: whatever operation you perform on the left side, apply equally to the right side.";
      } else if (userMsg.toLowerCase().includes('science') || userMsg.toLowerCase().includes('physics')) {
        aiReply = "For Physical Science, Newton's Laws are fundamental! Remember that force equals mass times acceleration (F = m × a). Shall we do a practice calculation?";
      } else if (userMsg.toLowerCase().includes('thank') || userMsg.toLowerCase().includes('hi')) {
        aiReply = "You're very welcome! Keep up that amazing 7-day learning streak. Let's conquer today's study planner goals together!";
      }

      setMessages([...newMsgs, { sender: 'ai' as const, text: aiReply, time: 'Just now' }]);
      setIsThinking(false);
    }, 1000);
  };

  const quickPrompts = [
    "Explain Algebra Polynomials",
    "How to prepare for NSSCO Mock exams?",
    "Generate a quick math quiz",
    "Summarize Physical Science Chapter 4"
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col h-[560px] overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-[#0A2540] via-[#0F3558] to-emerald-900 p-4 sm:p-5 text-white flex items-center justify-between shrink-0 border-b border-emerald-500/20">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-400 to-teal-300 p-0.5 shadow-md">
                <div className="w-full h-full bg-[#0A2540] rounded-[14px] flex items-center justify-center text-xl">
                  {eduBuddy.aiAvatar === 'cyber-owl' ? '🦉' :
                   eduBuddy.aiAvatar === 'astro-guide' ? '👩‍🚀' :
                   eduBuddy.aiAvatar === 'safari-cheetah' ? '🐆' :
                   eduBuddy.aiAvatar === 'quantum-leopard' ? '🐯' : '🤖'}
                </div>
              </div>
              <div>
                <h3 className="font-extrabold text-sm sm:text-base flex items-center gap-1.5">
                  <span>{eduBuddy.aiName}</span>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold border border-emerald-500/30">
                    AI Tutor Live
                  </span>
                </h3>
                <p className="text-[11px] text-slate-300">Namibian Curriculum Mentor</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Full Suite Launch Banner */}
          {onLaunchFullSuite && (
            <div className="bg-emerald-500/15 border-b border-emerald-500/30 px-4 py-2.5 flex items-center justify-between text-xs text-emerald-800 dark:text-emerald-300 shrink-0">
              <span className="font-bold flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-500" />
                <span>Want AI Quizzes, Flashcards & Summarizers?</span>
              </span>
              <button
                onClick={() => { onClose(); onLaunchFullSuite(); }}
                className="font-extrabold text-[#0A2540] dark:text-emerald-300 underline hover:no-underline flex items-center gap-1"
              >
                <span>Launch Full Suite →</span>
              </button>
            </div>
          )}

          {/* Messages Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50 dark:bg-slate-900/50">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-sm ${
                    msg.sender === 'user'
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-br-none font-medium'
                      : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-bl-none font-normal'
                  }`}
                >
                  {msg.text}
                </div>
                <span className="text-[10px] text-slate-400 mt-1 px-1">
                  {msg.time}
                </span>
              </div>
            ))}

            {isThinking && (
              <div className="flex items-start">
                <div className="bg-white dark:bg-slate-800 p-3.5 rounded-2xl rounded-bl-none border border-slate-200 dark:border-slate-700 flex items-center gap-2 text-xs text-slate-500 font-semibold shadow-sm">
                  <Sparkles className="w-4 h-4 text-emerald-500 animate-spin" />
                  <span>{eduBuddy.aiName} is analyzing your curriculum...</span>
                </div>
              </div>
            )}
          </div>

          {/* Quick Prompts */}
          <div className="px-4 py-2 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800/80 flex items-center gap-2 overflow-x-auto shrink-0 no-scrollbar">
            <span className="text-[10px] font-bold text-slate-400 uppercase shrink-0">Ask:</span>
            {quickPrompts.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => { setInput(prompt); }}
                className="text-xs font-semibold px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-slate-600 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 border border-slate-200 dark:border-slate-700 hover:border-emerald-500/30 whitespace-nowrap transition shrink-0"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Input Form */}
          <form onSubmit={handleSend} className="p-3.5 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2 shrink-0">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask anything about math, science, essays..."
              className="flex-1 px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 text-xs sm:text-sm font-medium border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <button
              type="submit"
              disabled={!input.trim() || isThinking}
              className="p-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-[#0A2540] font-bold shadow-md transition transform active:scale-95 disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
