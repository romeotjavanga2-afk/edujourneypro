import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Quote, Sparkles, RefreshCw, Share2, Heart } from 'lucide-react';

interface MotivationSectionProps {
  initialQuote: {
    quote: string;
    author: string;
  };
}

const QUOTE_LIBRARY = [
  { quote: "One lesson today brings you closer to your dreams.", author: "Edu Journey Mentor" },
  { quote: "Success is built one study session at a time.", author: "Nelson Mandela" },
  { quote: "Education is the most powerful weapon which you can use to change the world.", author: "Nelson Mandela" },
  { quote: "The beautiful thing about learning is that no one can take it away from you.", author: "B.B. King" },
  { quote: "Do not let what you cannot do interfere with what you can do.", author: "John Wooden" },
  { quote: "Your future is created by what you do today, not tomorrow.", author: "Robert Kiyosaki" },
  { quote: "Small daily improvements over time lead to stunning results.", author: "Robin Sharma" },
  { quote: "Strive for progress, not perfection in your studies.", author: "Academic Guide" }
];

export const MotivationSection: React.FC<MotivationSectionProps> = ({ initialQuote }) => {
  const [currentQuote, setCurrentQuote] = useState(initialQuote);
  const [isLiked, setIsLiked] = useState(false);
  const [isSpinning, setIsSpinning] = useState(false);

  const handleNewQuote = () => {
    setIsSpinning(true);
    setTimeout(() => {
      const randomIndex = Math.floor(Math.random() * QUOTE_LIBRARY.length);
      setCurrentQuote(QUOTE_LIBRARY[randomIndex]);
      setIsSpinning(false);
    }, 300);
  };

  return (
    <div className="bg-gradient-to-r from-purple-900/90 via-slate-900 to-[#0A2540] rounded-3xl p-6 md:p-8 text-white shadow-lg border border-purple-500/30 my-6 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-start gap-4 max-w-3xl">
          <div className="w-12 h-12 rounded-2xl bg-purple-500/20 text-purple-300 flex items-center justify-center shrink-0 border border-purple-500/30 shadow-md">
            <Quote className="w-6 h-6" />
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={currentQuote.quote}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-xs font-bold uppercase tracking-wider text-purple-300 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>Daily Motivation</span>
                </span>
              </div>
              <p className="text-base sm:text-lg md:text-xl font-extrabold italic leading-relaxed text-white">
                "{currentQuote.quote}"
              </p>
              <p className="text-xs sm:text-sm text-slate-300 font-semibold mt-2">
                — {currentQuote.author}
              </p>
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="flex items-center gap-2.5 self-end md:self-center shrink-0">
          <button
            onClick={() => setIsLiked(!isLiked)}
            className={`p-3 rounded-xl border transition ${
              isLiked 
                ? 'bg-rose-500/20 text-rose-400 border-rose-500/40' 
                : 'bg-white/10 text-slate-300 hover:bg-white/20 border-white/15'
            }`}
            title="Bookmark quote"
          >
            <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-400' : ''}`} />
          </button>

          <button
            onClick={handleNewQuote}
            disabled={isSpinning}
            className="inline-flex items-center gap-2 px-4 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs border border-white/15 transition active:scale-95 disabled:opacity-50"
            title="Get a new quote"
          >
            <RefreshCw className={`w-4 h-4 ${isSpinning ? 'animate-spin' : ''}`} />
            <span>New Quote</span>
          </button>
        </div>
      </div>
    </div>
  );
};
