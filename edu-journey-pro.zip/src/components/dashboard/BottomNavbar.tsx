import React from 'react';
import { LayoutDashboard, BookOpen, Clock, Bot, Menu, Settings } from 'lucide-react';
import { DashboardNavTab } from '../../types.js';

interface BottomNavbarProps {
  activeTab: DashboardNavTab;
  onSelectTab: (tab: DashboardNavTab) => void;
  onOpenChat: () => void;
  onToggleSidebar: () => void;
}

export const BottomNavbar: React.FC<BottomNavbarProps> = ({
  activeTab,
  onSelectTab,
  onOpenChat,
  onToggleSidebar
}) => {
  const navItems = [
    { id: 'dashboard' as DashboardNavTab, label: 'Home', icon: LayoutDashboard, action: () => onSelectTab('dashboard') },
    { id: 'assignments' as DashboardNavTab, label: 'Tasks', icon: BookOpen, action: () => onSelectTab('assignments') },
    { id: 'buddy' as DashboardNavTab, label: 'Edu Buddy', icon: Bot, action: () => onSelectTab('buddy'), isAi: true },
    { id: 'planner' as DashboardNavTab, label: 'Planner', icon: Clock, action: () => onSelectTab('planner') },
    { id: 'menu', label: 'Menu', icon: Menu, action: onToggleSidebar },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 lg:hidden shadow-lg">
      <div className="grid grid-cols-5 h-16 max-w-md mx-auto px-2">
        {navItems.map((item, idx) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={idx}
              onClick={item.action}
              className={`flex flex-col items-center justify-center gap-1 transition ${
                isActive && !item.isAi
                  ? 'text-emerald-600 dark:text-emerald-400 font-extrabold'
                  : item.isAi
                  ? 'text-[#0A2540] dark:text-white font-extrabold'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium'
              }`}
            >
              {item.isAi ? (
                <div className="w-10 h-10 -mt-4 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-[#0A2540] flex items-center justify-center shadow-lg shadow-emerald-500/30 transform active:scale-95 transition">
                  <Icon className="w-5 h-5 animate-bounce" style={{ animationDuration: '3s' }} />
                </div>
              ) : (
                <div className="relative">
                  <Icon className={`w-5 h-5 ${isActive ? 'scale-110' : ''} transition-transform`} />
                  {isActive && (
                    <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  )}
                </div>
              )}
              <span className="text-[10px] tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
