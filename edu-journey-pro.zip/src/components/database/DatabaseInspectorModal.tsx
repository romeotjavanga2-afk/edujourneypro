import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { X, Database, Table, ShieldCheck, CheckCircle2, Server, Cpu, RefreshCw, Loader2, Code2 } from 'lucide-react';
import { DatabaseInspectorData, DatabaseTableInfo } from '../../types.js';

export const DatabaseInspectorModal: React.FC = () => {
  const { activeModal, setActiveModal } = useAuth();
  const [data, setData] = useState<DatabaseInspectorData | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedTable, setSelectedTable] = useState<string>('Users');

  const fetchInspectorData = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/database/inspector');
      const json = await res.json();
      if (json.success) {
        setData(json);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (activeModal === 'db-inspector') {
      fetchInspectorData();
    }
  }, [activeModal]);

  if (activeModal !== 'db-inspector') return null;

  const currentTableInfo: DatabaseTableInfo | undefined = data?.tables.find(t => t.tableName === selectedTable) || data?.tables[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col justify-between"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Top Header */}
        <div className="flex items-center justify-between pb-6 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#0A2540] flex items-center justify-center text-emerald-400 shadow-md">
              <Database className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-xl text-[#0A2540] dark:text-white font-sans">Phase 1 Database Architecture</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300">
                  LIVE SQLITE ENGINE
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {data?.projectName || 'Edu Journey Pro'} • {data?.phase || 'Foundation Phase'} • {data?.targetCountry || 'Namibia'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchInspectorData}
              disabled={loading}
              className="p-2 rounded-xl text-slate-500 hover:text-blue-600 dark:hover:text-emerald-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="Refresh Live Data"
            >
              <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={() => setActiveModal(null)}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        {loading && !data ? (
          <div className="py-20 text-center space-y-3">
            <Loader2 className="w-10 h-10 animate-spin text-blue-600 mx-auto" />
            <p className="text-sm text-slate-500">Querying live SQLite foundational tables...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 py-4 overflow-y-auto flex-1 pr-1">
            
            {/* Left Sidebar: Table Selector List */}
            <div className="md:col-span-4 space-y-2 border-r border-slate-100 dark:border-slate-800 pr-0 md:pr-4">
              <div className="text-xs font-extrabold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Table className="w-3.5 h-3.5 text-blue-600" />
                <span>Foundational Tables ({data?.tables.length || 9})</span>
              </div>

              <div className="space-y-1.5 max-h-[50vh] overflow-y-auto pr-1">
                {data?.tables.map(t => {
                  const active = t.tableName === selectedTable;
                  return (
                    <button
                      key={t.tableName}
                      onClick={() => setSelectedTable(t.tableName)}
                      className={`w-full text-left p-3 rounded-2xl text-xs font-bold transition-all flex items-center justify-between border ${
                        active
                          ? 'bg-gradient-to-r from-blue-900 via-blue-800 to-emerald-800 text-white border-transparent shadow-md'
                          : 'bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700/80 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-2 truncate">
                        <Code2 className={`w-3.5 h-3.5 shrink-0 ${active ? 'text-emerald-300' : 'text-slate-400'}`} />
                        <span className="truncate">{t.tableName}</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] ${active ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'}`}>
                        {t.rowCount} {t.rowCount === 1 ? 'row' : 'rows'}
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="p-3 rounded-2xl bg-blue-50 dark:bg-slate-800/80 border border-blue-200 dark:border-slate-700 text-[11px] text-blue-900 dark:text-blue-300 leading-relaxed mt-4">
                <strong>Phase 1 Guarantee:</strong> Only foundational tables are initialized. No unrequested Phase 2 dashboard or analytical tables exist.
              </div>
            </div>

            {/* Right Area: Selected Table Details & Sample Rows */}
            <div className="md:col-span-8 space-y-6">
              
              {currentTableInfo && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  
                  {/* Table Description Card */}
                  <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="text-lg font-extrabold text-slate-900 dark:text-white font-serif flex items-center gap-2">
                        <span>Table:</span>
                        <code className="text-blue-700 dark:text-emerald-400 bg-white dark:bg-slate-900 px-2.5 py-0.5 rounded-lg border border-slate-200 dark:border-slate-700 font-mono text-base">{currentTableInfo.tableName}</code>
                      </h4>
                      <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                        {currentTableInfo.rowCount} Active Records
                      </span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                      {currentTableInfo.description}
                    </p>
                  </div>

                  {/* Sample Rows Table */}
                  <div>
                    <h5 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-2 flex items-center gap-1.5">
                      <Server className="w-3.5 h-3.5 text-blue-600" />
                      <span>Live Sample Data (Top 5 Records)</span>
                    </h5>

                    <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm max-h-60 overflow-y-auto">
                      {currentTableInfo.sampleRows.length > 0 ? (
                        <table className="w-full text-left border-collapse text-xs">
                          <thead>
                            <tr className="bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 font-bold text-slate-700 dark:text-slate-300">
                              {Object.keys(currentTableInfo.sampleRows[0]).map((key) => (
                                <th key={key} className="p-3 whitespace-nowrap">{key}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono text-slate-600 dark:text-slate-400">
                            {currentTableInfo.sampleRows.map((row, idx) => (
                              <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                                {Object.values(row).map((val: any, vIdx) => (
                                  <td key={vIdx} className="p-3 max-w-[150px] truncate">
                                    {typeof val === 'object' ? JSON.stringify(val) : String(val ?? 'NULL')}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      ) : (
                        <div className="p-8 text-center text-slate-400 italic text-xs">
                          No records present in this table yet. Register a new account or student profile to populate!
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Security Compliance Checklist */}
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-300">
                      <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
                      <span>Strict Foreign Key Integrity</span>
                    </div>
                    <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 flex items-center gap-2 text-xs font-semibold text-blue-800 dark:text-blue-300">
                      <ShieldCheck className="w-4 h-4 shrink-0 text-blue-600 dark:text-blue-400" />
                      <span>Scrypt Hash Encryption</span>
                    </div>
                  </div>

                </div>
              )}

            </div>

          </div>
        )}

        {/* Footer info */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0 text-xs text-slate-500">
          <div className="flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-emerald-500" />
            <span>SQLite WebAssembly Engine (sql.js)</span>
          </div>
          <button
            onClick={() => setActiveModal(null)}
            className="px-5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-colors"
          >
            Close Inspector
          </button>
        </div>

      </div>
    </div>
  );
};
