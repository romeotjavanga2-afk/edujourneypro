import React from 'react';
import { GraduationCap, Heart, Globe, Twitter, Facebook, Linkedin, Github, Shield } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-800/80 pt-16 pb-12 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800/80">
          
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#0A2540] border border-emerald-500/30 flex items-center justify-center text-white">
                <span className="text-emerald-400 font-bold text-xl">E</span>
              </div>
              <span className="font-bold text-2xl text-white font-sans tracking-tight">
                Edu <span className="text-emerald-400">Journey</span> Pro
              </span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed max-w-sm font-normal">
              An AI-powered educational ecosystem built specifically for African schools, empowering students, teachers, and parents to learn together. Beginning our pilot across Namibia.
            </p>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-900/80 px-3 py-1.5 rounded-lg w-fit">
              <Shield className="w-3.5 h-3.5" />
              <span>Phase 1 Foundation & Auth Live</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm uppercase tracking-wider">Navigation</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li><a href="#home" className="hover:text-emerald-400 transition-colors">Home</a></li>
              <li><a href="#features" className="hover:text-emerald-400 transition-colors">Features Preview</a></li>
              <li><a href="#about" className="hover:text-emerald-400 transition-colors">About Our Vision</a></li>
              <li><a href="#contact" className="hover:text-emerald-400 transition-colors">Contact Pilot Team</a></li>
            </ul>
          </div>

          {/* Legal */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm uppercase tracking-wider">Legal & Security</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <a 
                  href="#privacy" 
                  onClick={(e) => { e.preventDefault(); alert("Privacy Policy: Edu Journey Pro strictly protects African student data. COPPA & Namibian Data Protection compliant. No data is shared with advertisers."); }}
                  className="hover:text-emerald-400 transition-colors cursor-pointer"
                >
                  Privacy Policy
                </a>
              </li>
              <li>
                <a 
                  href="#terms" 
                  onClick={(e) => { e.preventDefault(); alert("Terms of Service: Phase 1 Foundation Evaluation Build. All user passwords are encrypted using scrypt KDF."); }}
                  className="hover:text-emerald-400 transition-colors cursor-pointer"
                >
                  Terms of Service
                </a>
              </li>
              <li><a href="#security" onClick={(e) => { e.preventDefault(); alert("Security Standards: Strict rate limiting, HTTPOnly cookies, CSRF protection, and age gating enabled."); }} className="hover:text-emerald-400 transition-colors cursor-pointer">Security Standards</a></li>
              <li><a href="#accessibility" onClick={(e) => { e.preventDefault(); alert("Accessibility: WCAG 2.1 AA Compliant with high contrast themes and screen reader optimization."); }} className="hover:text-emerald-400 transition-colors cursor-pointer">Accessibility Statement</a></li>
            </ul>
          </div>

          {/* Namibian Pilot & Social Links */}
          <div className="space-y-4">
            <h4 className="text-white font-bold text-sm uppercase tracking-wider">Connect With Us</h4>
            <div className="flex items-center gap-3">
              <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter" className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-emerald-600 flex items-center justify-center text-slate-300 hover:text-white transition-all">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="https://facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook" className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-emerald-600 flex items-center justify-center text-slate-300 hover:text-white transition-all">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn" className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-emerald-600 flex items-center justify-center text-slate-300 hover:text-white transition-all">
                <Linkedin className="w-4 h-4" />
              </a>
              <a href="https://github.com" target="_blank" rel="noreferrer" aria-label="GitHub" className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-emerald-600 flex items-center justify-center text-slate-300 hover:text-white transition-all">
                <Github className="w-4 h-4" />
              </a>
            </div>
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs text-slate-400">
              <div className="font-bold text-white mb-0.5">Namibia Launchpad</div>
              <div>Supported by regional educational technologists & AI systems architects.</div>
            </div>
          </div>

        </div>

        {/* Copyright & Disclaimer */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} Edu Journey Pro. All rights reserved. Built for African Schools, beginning in Namibia.
          </div>
          <div className="flex items-center gap-1">
            <span>Crafted with</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
            <span>for African Excellence</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
