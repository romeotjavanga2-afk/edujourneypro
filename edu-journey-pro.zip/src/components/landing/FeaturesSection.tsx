import React from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { 
  Bot, 
  Scan, 
  Share2, 
  MessageSquare, 
  Library, 
  Compass, 
  Layout, 
  Sparkles, 
  ArrowRight,
  ShieldCheck,
  Lock
} from 'lucide-react';

export const FeaturesSection: React.FC = () => {
  const { setSelectedFeatureForPreview } = useAuth();

  const features = [
    {
      id: 'edu-buddy-ai',
      title: 'Edu Buddy AI',
      icon: Bot,
      color: 'from-blue-600 to-indigo-600',
      bgColor: 'bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400',
      description: '24/7 AI learning companion trained on Namibian and African curricula to guide students through complex topics step-by-step.',
      tag: 'AI Core'
    },
    {
      id: 'ai-scanner',
      title: 'AI Scanner',
      icon: Scan,
      color: 'from-emerald-600 to-teal-600',
      bgColor: 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400',
      description: 'Instant textbook and handwritten note scanner that analyzes diagrams to generate interactive practice quizzes and summaries.',
      tag: 'Smart Tool'
    },
    {
      id: 'edu-feed',
      title: 'Edu Feed',
      icon: Share2,
      color: 'from-purple-600 to-pink-600',
      bgColor: 'bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400',
      description: 'Collaborative educational feed where students, teachers, and experts share study guides, regional achievements, and insights.',
      tag: 'Community'
    },
    {
      id: 'edu-chat',
      title: 'Edu Chat',
      icon: MessageSquare,
      color: 'from-amber-600 to-orange-600',
      bgColor: 'bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400',
      description: 'Secure, moderated peer-to-peer and student-to-teacher messaging channels for group study and instant mentorship.',
      tag: 'Communication'
    },
    {
      id: 'edu-library',
      title: 'Edu Library',
      icon: Library,
      color: 'from-cyan-600 to-blue-600',
      bgColor: 'bg-cyan-50 dark:bg-cyan-950/50 text-cyan-600 dark:text-cyan-400',
      description: 'Comprehensive digital library packed with past exam papers (NSSCO/NSSCAS), interactive textbooks, and localized study guides.',
      tag: 'Resources'
    },
    {
      id: 'career-hub',
      title: 'Career Hub',
      icon: Compass,
      color: 'from-rose-600 to-red-600',
      bgColor: 'bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400',
      description: 'AI-guided career exploration linking school subjects to in-demand African industries, scholarships, and university pathways.',
      tag: 'Future Prep'
    },
    {
      id: 'study-workspace',
      title: 'Study Workspace',
      icon: Layout,
      color: 'from-violet-600 to-purple-600',
      bgColor: 'bg-violet-50 dark:bg-violet-950/50 text-violet-600 dark:text-violet-400',
      description: 'Distraction-free digital desk featuring pomodoro timers, AI flashcards, goal trackers, and real-time progress analytics.',
      tag: 'Productivity'
    }
  ];

  return (
    <section id="features" className="py-20 lg:py-32 bg-slate-100/60 dark:bg-slate-900/60 border-y border-slate-200/80 dark:border-slate-800 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Next-Generation Educational Features</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#0A2540] dark:text-white font-sans tracking-tight">
            An Ecosystem Built for African Excellence
          </h2>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed">
            Edu Journey Pro brings together seven powerful AI-enhanced modules designed to empower students and support educators across Namibia and beyond.
          </p>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <div
                key={feature.id}
                onClick={() => setSelectedFeatureForPreview(feature.title)}
                className="group relative bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-lg hover:shadow-2xl hover:border-blue-400 dark:hover:border-emerald-500/50 transition-all duration-300 flex flex-col justify-between cursor-pointer transform hover:-translate-y-1.5"
              >
                {/* Top Content */}
                <div className="space-y-5">
                  <div className="flex items-center justify-between">
                    <div className={`w-14 h-14 rounded-2xl ${feature.bgColor} flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform duration-300`}>
                      <Icon className="w-7 h-7" />
                    </div>
                    <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                      {feature.tag}
                    </span>
                  </div>

                  <h3 className="text-2xl font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-emerald-400 transition-colors">
                    {feature.title}
                  </h3>

                  <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed font-normal">
                    {feature.description}
                  </p>
                </div>

                {/* Bottom Action / Phase 2 Status Notice */}
                <div className="pt-6 mt-6 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                  <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
                    <Lock className="w-3.5 h-3.5 text-amber-500" />
                    <span>Phase 2 Release</span>
                  </span>
                  <span className="inline-flex items-center text-xs font-bold text-blue-600 dark:text-emerald-400 group-hover:translate-x-1 transition-transform">
                    <span>Preview Roadmap</span>
                    <ArrowRight className="w-3.5 h-3.5 ml-1" />
                  </span>
                </div>
              </div>
            );
          })}

          {/* 8th Card: Foundation Architecture Highlight (Phase 1 Live) */}
          <div className="md:col-span-2 lg:col-span-2 bg-[#0A2540] rounded-3xl p-8 text-white shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-6 border border-emerald-500/20">
            <div className="space-y-3 text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-300 text-xs font-bold uppercase tracking-widest border border-emerald-500/30">
                <ShieldCheck className="w-4 h-4" />
                <span>Phase 1 Deliverable Active</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-black font-sans tracking-tight">
                Secure Foundation & Namibian Registry
              </h3>
              <p className="text-sm sm:text-base text-slate-300 max-w-xl leading-relaxed">
                We have built the production-grade authentication engine, SQLite database schema, session security, and Namibian secondary school directory. Test student registration now!
              </p>
            </div>
            
            <div className="shrink-0">
              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-6 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-xl transition-all block text-center"
              >
                Partner With Us
              </a>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
