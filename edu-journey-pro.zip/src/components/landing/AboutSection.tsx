import React from 'react';
import { 
  Target, 
  HeartHandshake, 
  Lightbulb, 
  ShieldCheck, 
  MapPin, 
  Users, 
  BookOpen, 
  Award,
  CheckCircle2
} from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 lg:py-32 bg-white dark:bg-slate-950 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Vision & Mission Statement */}
          <div className="lg:col-span-7 space-y-8">
            
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-xs font-bold uppercase tracking-wider">
              <Target className="w-3.5 h-3.5" />
              <span>Our Core Mission & Vision</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#0A2540] dark:text-white font-sans tracking-tight leading-tight">
              Empower African Education Through Modern Technology
            </h2>

            {/* Mission Quote Banner */}
            <div className="p-6 sm:p-8 rounded-3xl bg-[#0A2540] text-white shadow-xl relative overflow-hidden border border-emerald-500/20">
              <div className="absolute top-0 right-0 -mr-8 -mt-8 w-40 h-40 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none"></div>
              <div className="flex items-start gap-4">
                <HeartHandshake className="w-10 h-10 text-emerald-400 shrink-0 mt-1" />
                <div>
                  <h3 className="text-xl sm:text-2xl font-black font-sans mb-2">Our Guiding Principle</h3>
                  <p className="text-slate-300 text-base sm:text-lg leading-relaxed font-medium italic">
                    "We build AI that supports—not replaces—teachers and parents. Our mission is to bridge educational disparities across Africa by equipping classrooms with culturally tailored, world-class intelligent tools."
                  </p>
                </div>
              </div>
            </div>

            <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed font-normal">
              Beginning our pilot program across <strong className="text-slate-900 dark:text-white font-semibold">Namibia’s 14 geographical regions</strong>, Edu Journey Pro addresses real-world classroom challenges: student-to-teacher ratios, access to past exam papers, and career guidance tailored to evolving African economies.
            </p>

            {/* Pillars Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4">
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-700 dark:text-emerald-400 shrink-0">
                  <Lightbulb className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-base text-slate-900 dark:text-white">Culturally Aligned AI</h4>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">Trained to understand local contexts, languages, and curriculum standards like NSSCO & NSSCAS.</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950 flex items-center justify-center text-blue-700 dark:text-blue-400 shrink-0">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-base text-slate-900 dark:text-white">Teacher & Parent Enablement</h4>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">Empowering educators with automated grading assistance and giving parents transparent insight into student progress.</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-950 flex items-center justify-center text-purple-700 dark:text-purple-400 shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-base text-slate-900 dark:text-white">Enterprise-Grade Security</h4>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">Strict age verification (10+ years), rate limiting, and encrypted session handling protect African youth.</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950 flex items-center justify-center text-amber-700 dark:text-amber-400 shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-base text-slate-900 dark:text-white">Namibia-First Rollout</h4>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">Pre-populated with secondary schools across Khomas, Erongo, Oshana, ||Kharas, and more.</p>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Namibian Impact & Rollout Visual Card */}
          <div className="lg:col-span-5">
            <div className="bg-slate-50 dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6">
              
              <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">🇳🇦</span>
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white text-base">Namibia Pilot Rollout</h3>
                    <p className="text-xs text-slate-500">Ministry of Education Aligned</p>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                  PHASE 1 ACTIVE
                </span>
              </div>

              {/* Stats Counters */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm text-center">
                  <div className="text-3xl font-black text-[#0A2540] dark:text-emerald-400 font-sans">14</div>
                  <div className="text-xs font-bold text-slate-600 dark:text-slate-300 uppercase mt-1">Namibian Regions</div>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm text-center">
                  <div className="text-3xl font-black text-emerald-600 dark:text-emerald-400 font-sans">100+</div>
                  <div className="text-xs font-bold text-slate-600 dark:text-slate-300 uppercase mt-1">Pre-Seeded Schools</div>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm text-center">
                  <div className="text-3xl font-black text-[#0A2540] dark:text-emerald-400 font-sans">9</div>
                  <div className="text-xs font-bold text-slate-600 dark:text-slate-300 uppercase mt-1">Core SQL Tables</div>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm text-center">
                  <div className="text-3xl font-black text-emerald-600 dark:text-emerald-400 font-sans">22</div>
                  <div className="text-xs font-bold text-slate-600 dark:text-slate-300 uppercase mt-1">NSSCO Subjects</div>
                </div>
              </div>

              {/* Regional Spotlight List */}
              <div className="space-y-3 pt-2">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Spotlight Regional Secondary Schools</h4>
                
                <div className="space-y-2">
                  {[
                    { school: "Windhoek High School", region: "Khomas Region", town: "Windhoek" },
                    { school: "Swakopmund Secondary School", region: "Erongo Region", town: "Swakopmund" },
                    { school: "Oshakati Secondary School", region: "Oshana Region", town: "Oshakati" },
                    { school: "Etosha Secondary School", region: "Oshikoto Region", town: "Tsumeb" }
                  ].map((s, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-100 dark:border-slate-700/60 text-xs">
                      <div className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                        <span>{s.school}</span>
                      </div>
                      <span className="text-slate-400 dark:text-slate-400">{s.town} ({s.region})</span>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
