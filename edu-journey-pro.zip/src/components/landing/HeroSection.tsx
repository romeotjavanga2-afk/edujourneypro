import React from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { 
  Sparkles, 
  BookOpen, 
  Laptop, 
  Bot, 
  Users, 
  ArrowRight, 
  CheckCircle, 
  MapPin, 
  Award, 
  Globe, 
  Cpu,
  Zap,
  GraduationCap
} from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { user, setActiveModal } = useAuth();

  return (
    <section id="home" className="relative overflow-hidden pt-8 sm:pt-16 pb-20 lg:pb-32 bg-gradient-to-b from-slate-50 via-white to-blue-50/40 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 transition-colors duration-300">
      
      {/* Background Decorative African & Modern AI Patterns */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-gradient-to-br from-emerald-500/10 to-blue-600/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-1/2 -left-32 w-[30rem] h-[30rem] bg-gradient-to-tr from-blue-700/10 via-emerald-500/10 to-amber-500/5 rounded-full blur-3xl"></div>
        
        {/* Subtle geometric grid */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Headline & Call to Actions */}
          <div className="lg:col-span-7 text-left space-y-6 sm:space-y-8">
            
            {/* Namibia Launch Badge */}
            <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-emerald-50 dark:bg-slate-900 border border-emerald-200 dark:border-emerald-900/60 text-emerald-800 dark:text-emerald-300 text-xs sm:text-sm font-bold uppercase tracking-wider shadow-sm">
              <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-500 animate-ping"></span>
              <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-500 absolute"></span>
              <span className="font-extrabold">Namibia Pilot</span>
              <span className="text-slate-400 dark:text-slate-600">|</span>
              <span className="text-slate-700 dark:text-slate-300">AI-Powered Educational Ecosystem</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-[#0A2540] dark:text-white font-sans leading-[1.1] mb-4">
              Empowering Every <br className="hidden sm:block" />
              <span className="text-emerald-600 dark:text-emerald-400">
                African Student
              </span>{" "}
              Through AI
            </h1>

            {/* Subheading */}
            <p className="text-lg sm:text-xl text-slate-600 dark:text-slate-300 font-normal leading-relaxed max-w-2xl">
              Edu Journey Pro transforms learning by connecting <strong className="text-slate-900 dark:text-white font-semibold">students, teachers, parents, and educational experts</strong>. Experience personalized, culturally grounded AI guidance built specifically for African classrooms, starting across Namibia’s 14 regions.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              {user ? (
                <button
                  onClick={() => setActiveModal('profile')}
                  className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-[#0A2540] hover:bg-emerald-700 text-white font-bold text-base shadow-xl hover:translate-y-[-2px] transition-all"
                >
                  <GraduationCap className="w-5 h-5 text-emerald-400" />
                  <span>My Student Profile</span>
                  <ArrowRight className="w-5 h-5 ml-1" />
                </button>
              ) : (
                <button
                  onClick={() => setActiveModal('register')}
                  className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-[#0A2540] hover:bg-emerald-700 text-white font-bold text-base shadow-xl hover:translate-y-[-2px] transition-all"
                >
                  <Sparkles className="w-5 h-5 text-emerald-400" />
                  <span>Get Started</span>
                  <ArrowRight className="w-5 h-5 ml-1" />
                </button>
              )}

              <a
                href="#about"
                onClick={(e) => {
                  e.preventDefault();
                  document.querySelector('#about')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-bold text-base hover:bg-slate-50 dark:hover:bg-slate-800/80 transition-all shadow-sm"
              >
                <span>Learn More</span>
              </a>
            </div>

            {/* Quick Pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4">
              <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-2.5 font-bold text-xs sm:text-sm text-[#0A2540] dark:text-slate-200">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>14 Namibian Regions</span>
              </div>
              <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-2.5 font-bold text-xs sm:text-sm text-[#0A2540] dark:text-slate-200">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>NSSCO / NSSCAS Ready</span>
              </div>
              <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-2.5 font-bold text-xs sm:text-sm text-[#0A2540] dark:text-slate-200">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Phase 1 Verified Auth</span>
              </div>
            </div>

          </div>

          {/* Right Column: Modern Illustration showing Students, Books, Laptop, AI Assistant & African Environment */}
          <div className="lg:col-span-5 relative">
            
            {/* Background glowing frame */}
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-emerald-500 rounded-3xl blur-xl opacity-30 dark:opacity-40 animate-pulse"></div>

            {/* Main Interactive Visual Card */}
            <div className="relative rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden p-6 sm:p-8">
              
              {/* Top Bar / Classroom Status */}
              <div className="flex items-center justify-between pb-6 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#0A2540] flex items-center justify-center text-emerald-400">
                    <Laptop className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-[#0A2540] dark:text-white flex items-center gap-1.5 font-sans">
                      <span>Namibia Study Hub</span>
                      <span className="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">AI Study Workspace Active</p>
                  </div>
                </div>
                <div className="flex -space-x-2">
                  <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100" alt="Student" className="w-8 h-8 rounded-full border-2 border-white dark:border-slate-900 object-cover" />
                  <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=100" alt="Teacher" className="w-8 h-8 rounded-full border-2 border-white dark:border-slate-900 object-cover" />
                  <div className="w-8 h-8 rounded-full bg-[#0A2540] text-emerald-400 font-bold text-xs flex items-center justify-center border-2 border-white dark:border-slate-900">+4</div>
                </div>
              </div>

              {/* Center Scene: AI Assistant interacting with Student & Books */}
              <div className="py-6 space-y-4">
                
                {/* Student Query Box */}
                <div className="flex gap-3 items-start">
                  <div className="w-8 h-8 rounded-full bg-amber-100 dark:bg-amber-950/80 flex items-center justify-center text-amber-700 dark:text-amber-400 shrink-0 mt-1">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div className="flex-1 bg-slate-50 dark:bg-slate-800/80 p-3.5 rounded-2xl rounded-tl-none border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-800 dark:text-slate-200">
                    <p className="font-semibold text-blue-900 dark:text-blue-300 text-xs mb-1 flex items-center justify-between">
                      <span>Tangi (Grade 11, Windhoek High)</span>
                      <span className="text-[10px] text-slate-400 font-normal">Physical Science</span>
                    </p>
                    <p>"How do I calculate projectile motion for our NSSCO physics experiment?"</p>
                  </div>
                </div>

                {/* AI Assistant Response */}
                <div className="flex gap-3 items-start pl-6 sm:pl-8">
                  <div className="w-9 h-9 rounded-full bg-[#0A2540] flex items-center justify-center text-emerald-400 shrink-0 mt-1 shadow-md shadow-slate-900/20">
                    <Bot className="w-5 h-5 animate-bounce" />
                  </div>
                  <div className="flex-1 bg-white dark:bg-slate-800 p-4 rounded-2xl rounded-tl-none border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-800 dark:text-slate-200 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-bold text-[#0A2540] dark:text-emerald-400 flex items-center gap-1.5 font-sans">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                        <span>Edu Buddy AI</span>
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                        Step 1 of 3
                      </span>
                    </div>
                    <p className="leading-relaxed mb-3 font-normal text-slate-600 dark:text-slate-300">
                      Let's break down your projectile motion! In our Namibian syllabus, we separate horizontal velocity ($v_x$) and vertical acceleration ($g = 9.8\,m/s^2$).
                    </p>
                    <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-700 text-xs font-semibold text-emerald-700 dark:text-emerald-400">
                      <Award className="w-3.5 h-3.5 text-amber-500" />
                      <span>Verified by Namibian Science Curriculum</span>
                    </div>
                  </div>
                </div>

              </div>

              {/* Bottom Interactive Badges */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-700 dark:text-emerald-400 shrink-0">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500 uppercase font-bold">Community</div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white">Teachers & Parents</div>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-950 flex items-center justify-center text-blue-700 dark:text-blue-400 shrink-0">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500 uppercase font-bold">Coverage</div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white">All 14 Regions</div>
                  </div>
                </div>
              </div>

            </div>

            {/* Floating Decorative African Elements */}
            <div className="absolute -bottom-6 -left-6 bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 flex items-center gap-3 hidden sm:flex">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-emerald-600 flex items-center justify-center text-white font-bold text-lg shadow-md">
                🇳🇦
              </div>
              <div>
                <div className="text-xs font-extrabold text-slate-900 dark:text-white">Namibia First</div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold">Tailored African Education</div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
