import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { X, Mail, CheckCircle2, RefreshCw, ArrowRight, ShieldCheck, Loader2 } from 'lucide-react';

export const VerifyEmailModal: React.FC = () => {
  const { activeModal, setActiveModal, user, refreshUser } = useAuth();
  const [resending, setResending] = useState(false);
  const [resendSuccess, setResendSuccess] = useState(false);
  const [verifying, setVerifying] = useState(false);

  if (activeModal !== 'verify-email') return null;

  const handleResend = () => {
    setResending(true);
    setResendSuccess(false);
    setTimeout(() => {
      setResending(false);
      setResendSuccess(true);
    }, 1500);
  };

  const handleManualVerify = async () => {
    setVerifying(true);
    try {
      // In sandbox mode, auto-verify current logged-in user email!
      if (user?.email) {
        await fetch('/api/auth/verify-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: user.email })
        });
        await refreshUser();
        alert("🎉 Email verification confirmed! Welcome to your verified Phase 1 Student Profile!");
        setActiveModal('profile');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setVerifying(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden text-center space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Close button */}
        <button
          onClick={() => setActiveModal(null)}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Icon */}
        <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-blue-700 via-blue-600 to-emerald-500 flex items-center justify-center text-white mx-auto shadow-lg shadow-blue-900/20">
          <Mail className="w-8 h-8 text-emerald-300 animate-pulse" />
        </div>

        {/* Title & Info */}
        <div className="space-y-2">
          <h3 className="text-2xl font-extrabold text-slate-900 dark:text-white font-serif">
            Verification Sent
          </h3>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            We have dispatched a secure verification link to{" "}
            <strong className="text-slate-900 dark:text-white underline">{user?.email || 'your email address'}</strong>. Please click the link to activate your full Namibian student benefits.
          </p>
        </div>

        {/* Status Box */}
        <div className="p-4 rounded-2xl bg-blue-50 dark:bg-slate-800/80 border border-blue-200 dark:border-slate-700 text-left space-y-2 text-xs">
          <div className="font-bold text-blue-900 dark:text-blue-300 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>Why verify your email?</span>
          </div>
          <ul className="list-disc list-inside text-slate-600 dark:text-slate-300 space-y-1">
            <li>Protects your student identity and school records</li>
            <li>Enables NSSCO / NSSCAS exam paper downloads</li>
            <li>Restores account access if you forget your password</li>
          </ul>
        </div>

        {resendSuccess && (
          <div className="p-2.5 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 text-xs font-bold flex items-center justify-center gap-1.5">
            <CheckCircle2 className="w-4 h-4" />
            <span>Verification email resent successfully!</span>
          </div>
        )}

        {/* Buttons */}
        <div className="space-y-3 pt-2">
          <button
            type="button"
            onClick={handleManualVerify}
            disabled={verifying}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-blue-800 via-blue-700 to-emerald-600 hover:from-blue-900 hover:to-emerald-700 text-white font-bold text-sm shadow-lg transition-all flex items-center justify-center gap-2"
          >
            {verifying ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Verifying Status...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                <span>Continue After Verification</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleResend}
            disabled={resending}
            className="w-full py-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs hover:bg-slate-200 transition-colors flex items-center justify-center gap-1.5 disabled:opacity-50"
          >
            {resending ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Resending Email...</span>
              </>
            ) : (
              <>
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Resend Email</span>
              </>
            )}
          </button>
        </div>

        <div className="text-[11px] text-slate-400">
          Check your spam folder if the email does not appear within 2 minutes.
        </div>

      </div>
    </div>
  );
};
