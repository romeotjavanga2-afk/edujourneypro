import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { 
  X, 
  User, 
  Mail, 
  Lock, 
  MapPin, 
  GraduationCap, 
  BookOpen, 
  Sparkles, 
  ArrowRight, 
  ArrowLeft, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  Calendar,
  Image as ImageIcon
} from 'lucide-react';

export const RegisterModal: React.FC = () => {
  const { activeModal, setActiveModal, initData, login } = useAuth();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [verificationResult, setVerificationResult] = useState<any | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    gender: 'Female',
    dateOfBirth: '2009-06-15', // Default ~17 yo
    region: 'Khomas',
    town: 'Windhoek',
    school: 'Windhoek High School',
    customSchool: '',
    grade: 'Grade 10',
    subjects: ['Mathematics', 'Physical Science', 'English First Language'],
    interests: ['Artificial Intelligence & Robotics', 'Software Development & Coding'],
    profilePicture: ''
  });

  if (activeModal !== 'register') return null;

  const handleNextStep = () => {
    setError(null);
    if (step === 1) {
      if (!formData.fullName || !formData.email || !formData.password || !formData.confirmPassword) {
        return setError('Please fill in all identity fields.');
      }
      if (formData.password !== formData.confirmPassword) {
        return setError('Passwords do not match.');
      }
      if (formData.password.length < 8) {
        return setError('Password must be at least 8 characters long.');
      }
      // Calculate age
      const dob = new Date(formData.dateOfBirth);
      const today = new Date();
      let age = today.getFullYear() - dob.getFullYear();
      if (age < 10) {
        return setError(`Student must be at least 10 years old according to project safety guidelines. Current calculated age: ${age}.`);
      }
    }

    if (step === 2) {
      const selectedSchool = formData.school === 'Other / Custom School' ? formData.customSchool : formData.school;
      if (!selectedSchool || !formData.region || !formData.town || !formData.grade) {
        return setError('Please select your Region, Town, School, and Grade.');
      }
    }

    setStep(prev => prev + 1);
  };

  const toggleSubject = (subj: string) => {
    setFormData(prev => {
      const current = prev.subjects;
      if (current.includes(subj)) {
        return { ...prev, subjects: current.filter(s => s !== subj) };
      }
      if (current.length >= 6) {
        setError('You can select a maximum of 6 core subjects.');
        return prev;
      }
      setError(null);
      return { ...prev, subjects: [...current, subj] };
    });
  };

  const toggleInterest = (intr: string) => {
    setFormData(prev => {
      const current = prev.interests;
      if (current.includes(intr)) {
        return { ...prev, interests: current.filter(i => i !== intr) };
      }
      if (current.length >= 5) {
        setError('You can select up to 5 interest areas.');
        return prev;
      }
      setError(null);
      return { ...prev, interests: [...current, intr] };
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const finalSchool = formData.school === 'Other / Custom School' ? formData.customSchool || 'Namibian Student School' : formData.school;
      
      const payload = {
        ...formData,
        school: finalSchool
      };

      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setError(data.error || 'Registration failed.');
      } else {
        setVerificationResult(data);
        login(data.token, data.user);
      }
    } catch (err) {
      setError('A network error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleInstantVerify = async () => {
    if (!verificationResult?.verificationToken) return;
    setLoading(true);
    try {
      const res = await fetch('/api/auth/verify-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: verificationResult.verificationToken })
      });
      const data = await res.json();
      if (data.success) {
        alert("🎉 Email Address Verified! Welcome to Edu Journey Pro!");
        setActiveModal('profile');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  // Filter schools by region if initData is present
  const availableSchools = initData?.schools.filter(s => s.region === formData.region) || [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col justify-between"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Top Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#0A2540] flex items-center justify-center text-emerald-400 shadow-sm">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-[#0A2540] dark:text-white font-sans">
                {verificationResult ? "Registration Successful" : `Student Registration (Step ${step} of 3)`}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Edu Journey Pro • Namibia Phase 1 Pilot</p>
            </div>
          </div>
          <button
            onClick={() => setActiveModal(null)}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Bar */}
        {!verificationResult && (
          <div className="grid grid-cols-3 gap-2 my-3 shrink-0">
            {[1, 2, 3].map((s) => (
              <div
                key={s}
                className={`h-1.5 rounded-full transition-colors ${
                  s <= step ? 'bg-gradient-to-r from-blue-600 to-emerald-500' : 'bg-slate-200 dark:bg-slate-800'
                }`}
              ></div>
            ))}
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="my-2 p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs flex items-center gap-2 shrink-0">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
            <span className="font-semibold">{error}</span>
          </div>
        )}

        {/* Form Body - Scrollable */}
        <div className="overflow-y-auto py-3 pr-1 space-y-4 flex-1">
          
          {/* STEP 1: Personal Identity & Age */}
          {step === 1 && !verificationResult && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Full Name *
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      placeholder="e.g. Tangi Amukwaya"
                      className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-sm focus:ring-2 focus:ring-blue-600 outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Email Address *
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="tangi@school.na"
                      className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-sm focus:ring-2 focus:ring-blue-600 outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Password *
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                    <input
                      type="password"
                      required
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      placeholder="Min 8 characters"
                      className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-sm focus:ring-2 focus:ring-blue-600 outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Confirm Password *
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                    <input
                      type="password"
                      required
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                      placeholder="Repeat password"
                      className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-sm focus:ring-2 focus:ring-blue-600 outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Date of Birth * (Min Age 10)
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                    <input
                      type="date"
                      required
                      value={formData.dateOfBirth}
                      onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-sm focus:ring-2 focus:ring-blue-600 outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Gender *
                  </label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-sm focus:ring-2 focus:ring-blue-600 outline-none"
                  >
                    <option value="Female">Female</option>
                    <option value="Male">Male</option>
                    <option value="Other">Other / Prefer not to say</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                  Optional Profile Picture URL
                </label>
                <div className="relative">
                  <ImageIcon className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                  <input
                    type="url"
                    value={formData.profilePicture}
                    onChange={(e) => setFormData({ ...formData, profilePicture: e.target.value })}
                    placeholder="https://images.unsplash.com/..."
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-sm focus:ring-2 focus:ring-blue-600 outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: Namibian School & Academic Level */}
          {step === 2 && !verificationResult && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Namibian Region *
                  </label>
                  <select
                    value={formData.region}
                    onChange={(e) => {
                      const newReg = e.target.value;
                      const schoolsInReg = initData?.schools.filter(s => s.region === newReg) || [];
                      const defaultSch = schoolsInReg[0]?.name || 'Other / Custom School';
                      setFormData({ ...formData, region: newReg, school: defaultSch });
                    }}
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-sm focus:ring-2 focus:ring-blue-600 outline-none"
                  >
                    {initData?.regions.map(r => (
                      <option key={r.id} value={r.name}>{r.name} Region</option>
                    )) || <option value="Khomas">Khomas Region</option>}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Town / City *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.town}
                    onChange={(e) => setFormData({ ...formData, town: e.target.value })}
                    placeholder="e.g. Windhoek, Swakopmund, Oshakati"
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-sm focus:ring-2 focus:ring-blue-600 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                  School *
                </label>
                <select
                  value={formData.school}
                  onChange={(e) => setFormData({ ...formData, school: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-sm focus:ring-2 focus:ring-blue-600 outline-none"
                >
                  {availableSchools.map(s => (
                    <option key={s.id} value={s.name}>{s.name} ({s.town})</option>
                  ))}
                  <option value="Other / Custom School">Other / Custom School</option>
                </select>
              </div>

              {formData.school === 'Other / Custom School' && (
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-emerald-400 mb-1.5">
                    Enter School Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.customSchool}
                    onChange={(e) => setFormData({ ...formData, customSchool: e.target.value })}
                    placeholder="Enter your school name..."
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-blue-400 text-slate-900 dark:text-white text-sm focus:ring-2 focus:ring-blue-600 outline-none"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                  Current Grade / Level *
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {['Grade 8', 'Grade 9', 'Grade 10', 'Grade 11', 'Grade 12', 'AS Level'].map((g) => (
                    <button
                      key={g}
                      type="button"
                      onClick={() => setFormData({ ...formData, grade: g })}
                      className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all ${
                        formData.grade === g 
                          ? 'bg-blue-600 text-white border-blue-600 shadow-sm' 
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-blue-400'
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: Subjects & Career Interests */}
          {step === 3 && !verificationResult && (
            <div className="space-y-5 animate-in fade-in duration-200">
              
              {/* Subjects */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    Select Your NSSCO Subjects (Max 6)
                  </label>
                  <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                    {formData.subjects.length} / 6 selected
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-40 overflow-y-auto p-1 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-800">
                  {(initData?.subjects || [
                    { id: 1, name: 'Mathematics', category: 'STEM' },
                    { id: 2, name: 'Physical Science', category: 'STEM' },
                    { id: 3, name: 'Biology', category: 'STEM' },
                    { id: 4, name: 'Computer Studies', category: 'STEM' },
                    { id: 5, name: 'English First Language', category: 'Languages' },
                    { id: 6, name: 'Geography', category: 'Humanities' },
                    { id: 7, name: 'Accounting', category: 'Commerce' },
                    { id: 8, name: 'Economics', category: 'Commerce' }
                  ]).map(sub => {
                    const selected = formData.subjects.includes(sub.name);
                    return (
                      <button
                        key={sub.id || sub.name}
                        type="button"
                        onClick={() => toggleSubject(sub.name)}
                        className={`text-left p-2.5 rounded-xl text-xs font-semibold border transition-all flex items-center justify-between ${
                          selected 
                            ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-900 dark:text-emerald-200 border-emerald-400 shadow-sm' 
                            : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-emerald-300'
                        }`}
                      >
                        <span className="truncate">{sub.name}</span>
                        {selected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0 ml-1" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Interests */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    Select Career Aspirations & Interests (Max 5)
                  </label>
                  <span className="text-xs font-bold text-blue-600 dark:text-blue-400">
                    {formData.interests.length} / 5 selected
                  </span>
                </div>
                <div className="flex flex-wrap gap-2 max-h-36 overflow-y-auto p-1">
                  {(initData?.interests || [
                    { id: 1, name: 'Artificial Intelligence & Robotics', category: 'Tech' },
                    { id: 2, name: 'Software Development & Coding', category: 'Tech' },
                    { id: 3, name: 'Medicine & Healthcare Innovation', category: 'Health' },
                    { id: 4, name: 'Renewable Energy & Sustainability', category: 'Engineering' },
                    { id: 5, name: 'Financial Literacy & Fintech', category: 'Finance' },
                    { id: 6, name: 'Law, Human Rights & Governance', category: 'Law' },
                    { id: 7, name: 'AgriTech & Modern Farming', category: 'Agri' }
                  ]).map(intr => {
                    const selected = formData.interests.includes(intr.name);
                    return (
                      <button
                        key={intr.id || intr.name}
                        type="button"
                        onClick={() => toggleInterest(intr.name)}
                        className={`px-3 py-1.5 rounded-full text-xs font-bold border transition-all ${
                          selected
                            ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700 hover:border-blue-400'
                        }`}
                      >
                        {intr.name}
                      </button>
                    );
                  })}
                </div>
              </div>

            </div>
          )}

          {/* VERIFICATION SUCCESS SCREEN */}
          {verificationResult && (
            <div className="py-6 text-center space-y-6 animate-in zoom-in-95 duration-300">
              <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 dark:text-emerald-400 mx-auto shadow-md">
                <CheckCircle2 className="w-10 h-10 animate-bounce" />
              </div>
              
              <div className="space-y-2">
                <h3 className="text-2xl font-black text-[#0A2540] dark:text-white font-sans">
                  Registration Complete!
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-300 max-w-md mx-auto">
                  We have created your student profile for <strong className="text-slate-900 dark:text-white">{formData.fullName}</strong> at <strong className="text-emerald-600 dark:text-emerald-400">{formData.school}</strong>.
                </p>
              </div>

              {/* Simulation verification box */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-left space-y-2">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  🔐 Email Verification Simulation (Phase 1 Sandbox)
                </div>
                <div className="text-xs text-slate-700 dark:text-slate-300">
                  In production, an email is sent to <strong>{formData.email}</strong>. For evaluation, click below to verify immediately:
                </div>
                <div className="font-mono text-xs bg-slate-200 dark:bg-slate-900 p-2 rounded-lg text-blue-700 dark:text-emerald-400 truncate">
                  Token: {verificationResult.verificationToken}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                <button
                  type="button"
                  onClick={handleInstantVerify}
                  disabled={loading}
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-sm shadow-lg flex items-center justify-center gap-2"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                  <span>Verify Email Address Now</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveModal('profile')}
                  className="px-6 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold text-sm hover:bg-slate-200 transition-colors"
                >
                  Continue to Profile
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Bottom Navigation Buttons */}
        {!verificationResult && (
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0">
            {step > 1 ? (
              <button
                type="button"
                onClick={() => setStep(prev => prev - 1)}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setActiveModal('login')}
                className="text-xs font-bold text-blue-600 dark:text-emerald-400 hover:underline"
              >
                Already have an account? Login
              </button>
            )}

            {step < 3 ? (
              <button
                type="button"
                onClick={handleNextStep}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#0A2540] hover:bg-emerald-700 text-white font-bold text-sm shadow-md transition-all"
              >
                <span>Continue</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSubmit}
                disabled={loading}
                className="inline-flex items-center gap-2 px-8 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-lg shadow-emerald-600/20 hover:shadow-xl transition-all disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Registering Account...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-white" />
                    <span>Complete Registration</span>
                  </>
                )}
              </button>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
