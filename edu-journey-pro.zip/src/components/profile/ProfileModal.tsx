import React from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { useAccessibility } from '../../context/AccessibilityContext.js';
import { 
  X, 
  User, 
  Mail, 
  MapPin, 
  GraduationCap, 
  BookOpen, 
  Sparkles, 
  CheckCircle2, 
  LogOut, 
  Database, 
  ShieldCheck, 
  Clock, 
  AlertTriangle,
  Award,
  Eye,
  Glasses
} from 'lucide-react';

export const ProfileModal: React.FC = () => {
  const { activeModal, setActiveModal, user, logout } = useAuth();
  const { isHighContrast, contrastPreset, toggleHighContrast } = useAccessibility();

  if (activeModal !== 'profile' || !user) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col justify-between"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Top Header */}
        <div className="flex items-center justify-between pb-6 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <img
              src={user.profilePicture || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(user.fullName)}`}
              alt={user.fullName}
              className="w-12 h-12 rounded-full object-cover border-2 border-emerald-500 shadow-sm"
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-xl text-[#0A2540] dark:text-white font-sans">{user.fullName}</h3>
                {user.isEmailVerified ? (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300">
                    <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                    <span>Verified Identity</span>
                  </span>
                ) : (
                  <button
                    onClick={() => setActiveModal('verify-email')}
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border border-amber-300 hover:bg-amber-200 transition-colors"
                  >
                    <AlertTriangle className="w-3 h-3 text-amber-500" />
                    <span>Verify Email Now</span>
                  </button>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">{user.email}</p>
            </div>
          </div>

          <button
            onClick={() => setActiveModal(null)}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Profile Content Body */}
        <div className="overflow-y-auto py-4 space-y-6 flex-1 pr-1">
          
          {/* Phase 1 Scope Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-900 via-blue-800 to-emerald-800 text-white shadow-md flex items-start gap-3">
            <Award className="w-6 h-6 text-emerald-300 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="font-bold text-sm">Phase 1 Foundation Authenticated</h4>
              <p className="text-xs text-blue-100 leading-relaxed">
                You are securely logged into your student session! Your account identity and academic preferences are stored in our SQLite database. The interactive AI Dashboard and educational tools will launch in Phase 2.
              </p>
            </div>
          </div>

          {/* Academic Profile Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-2">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>Namibian School & Grade</span>
              </div>
              <div className="font-bold text-slate-900 dark:text-white text-base">
                {user.school || 'Windhoek High School'}
              </div>
              <div className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                {user.grade || 'Grade 10'} • NSSCO Aligned
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-2">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>Region & Location</span>
              </div>
              <div className="font-bold text-slate-900 dark:text-white text-base">
                {user.town || 'Windhoek'}
              </div>
              <div className="text-xs font-semibold text-blue-600 dark:text-blue-400">
                {user.region || 'Khomas'} Region, Namibia
              </div>
            </div>

          </div>

          {/* Subjects & Interests */}
          <div className="space-y-4">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                <span>Enrolled Subjects ({user.subjects?.length || 0})</span>
              </h4>
              <div className="flex flex-wrap gap-2">
                {user.subjects && user.subjects.length > 0 ? (
                  user.subjects.map((sub, i) => (
                    <span key={i} className="px-3 py-1 rounded-xl text-xs font-bold bg-blue-50 dark:bg-blue-950/80 text-blue-800 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                      {sub}
                    </span>
                  ))
                ) : (
                  <span className="text-xs text-slate-400 italic">No specific subjects selected.</span>
                )}
              </div>
            </div>

            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>Career Interests ({user.interests?.length || 0})</span>
              </h4>
              <div className="flex flex-wrap gap-2">
                {user.interests && user.interests.length > 0 ? (
                  user.interests.map((intr, i) => (
                    <span key={i} className="px-3 py-1 rounded-xl text-xs font-bold bg-emerald-50 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                      {intr}
                    </span>
                  ))
                ) : (
                  <span className="text-xs text-slate-400 italic">No specific interests selected.</span>
                )}
              </div>
            </div>
          </div>

          {/* High Contrast Accessibility Quick Setting */}
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Eye className="w-5 h-5 text-amber-500 shrink-0" />
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white">High Contrast Accessibility Mode</h4>
                  <span className="text-[10px] font-black px-2 py-0.5 rounded bg-amber-400 text-slate-950 uppercase">
                    {isHighContrast ? contrastPreset : 'Off'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-400">
                  Enhanced reading contrast and WCAG AAA compliance for low-vision students.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={toggleHighContrast}
              className={`px-4 py-2 rounded-xl text-xs font-black transition shrink-0 shadow-sm ${
                isHighContrast
                  ? 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-300'
              }`}
            >
              {isHighContrast ? 'Disable Contrast' : 'Enable High Contrast'}
            </button>
          </div>

          {/* Security & Session Info */}
          <div className="p-4 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
              <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>Session Security: <strong>Encrypted JWT Bearer Token</strong></span>
            </div>
            <div className="flex items-center gap-2 text-slate-500 font-mono">
              <Clock className="w-3.5 h-3.5" />
              <span>Status: Active</span>
            </div>
          </div>

        </div>

        {/* Bottom Actions */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2 shrink-0">
          <div className="flex flex-col sm:flex-row items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => setActiveModal('onboarding')}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-[#0A2540] to-emerald-600 text-white shadow-md hover:from-emerald-600 hover:to-[#0A2540] transition-all"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Launch Phase 2 Onboarding</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveModal('db-inspector')}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-emerald-400 hover:bg-slate-200 transition-colors"
            >
              <Database className="w-4 h-4" />
              <span>Inspect DB</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => { logout(); setActiveModal(null); }}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold bg-red-50 dark:bg-red-950/40 text-red-600 hover:bg-red-100 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>

      </div>
    </div>
  );
};
