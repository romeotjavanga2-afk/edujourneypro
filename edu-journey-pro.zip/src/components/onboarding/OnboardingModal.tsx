/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Sparkles, Check, ArrowRight, ArrowLeft, Save, BookOpen, 
  GraduationCap, Heart, Target, Bell, Shield, Bot, User, 
  Smile, Award, CheckCircle2, Palette, MessageSquare, 
  Clock, Calendar, MapPin, School, AlertCircle, RefreshCw,
  Zap, Compass, Star, Trophy, ThumbsUp, HelpCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { OnboardingState, EduBuddyProfile } from '../../types.js';

const NAMIBIAN_REGIONS = [
  "Khomas", "Erongo", "Oshana", "Ohangwena", "Oshikoto", "Omusati",
  "||Kharas", "Hardap", "Otjozondjupa", "Omaheke", "Kunene", "Kavango East",
  "Kavango West", "Zambezi"
];

const STANDARD_SUBJECTS = [
  "Mathematics", "Physical Science", "Life Science", "Chemistry", "Biology",
  "Physics", "Accounting", "Business Studies", "Economics", "Geography",
  "History", "English First Language", "English Second Language",
  "Oshindonga", "Otjiherero", "Oshikwanyama", "Silozi", "Khoekhoegowab",
  "Afrikaans", "Computer Studies", "Agricultural Science", "Design & Technology",
  "Art & Design"
];

const STANDARD_GOALS = [
  "Improve Mathematics score", "Pass Grade 10 / Grade 11 with Honors",
  "Prepare for NSSCO / NSSCAS final exams", "Improve English communication & essay writing",
  "Achieve Top 10 rank in my class", "Master coding and software skills",
  "Build a consistent daily study habit", "Get accepted into University of Namibia (UNAM)"
];

const LEARNING_STYLES_OPTIONS = [
  { id: "Videos & Visuals", label: "Videos & Visuals", desc: "Watching animated lessons, diagrams, and video tutorials." },
  { id: "Reading & Textbooks", label: "Reading & Textbooks", desc: "Reading structured notes, PDF guides, and textbook chapters." },
  { id: "Listening & Audio", label: "Listening & Audio", desc: "Listening to podcasts, audio summaries, and spoken explanations." },
  { id: "Practice Questions", label: "Practice Questions", desc: "Solving past exam papers, quizzes, and practice exercises." },
  { id: "Flashcards", label: "Flashcards & Memory Aids", desc: "Using quick flashcards and active recall techniques." },
  { id: "Interactive Activities", label: "Interactive Games & Activities", desc: "Learning through simulations, educational games, and puzzles." },
  { id: "Mixed Learning", label: "Mixed & Adaptive Learning", desc: "Combining all methods depending on the topic being studied." }
];

const INTEREST_CATEGORIES = [
  { category: "STEM & Tech", items: ["Artificial Intelligence & Robotics", "Software Development & Coding", "Renewable Energy & Sustainability", "Mathematics & Physics", "Space Science & Astronomy", "Biotechnology & Medicine"] },
  { category: "Business & Society", items: ["Entrepreneurship & Startups", "Economics & Finance", "International Law & Diplomacy", "Agricultural Tech & Farming", "Architecture & Urban Planning", "Environmental Conservation"] },
  { category: "Arts & Humanities", items: ["African History & Cultural Heritage", "Languages & Linguistics", "Digital Art & Graphic Design", "Music & Sound Engineering", "Journalism & Creative Writing", "Sports & Athletics Science"] }
];

const CAREER_OPTIONS = [
  { id: "Doctor / Surgeon", icon: "🏥" }, { id: "Software Developer / AI Engineer", icon: "💻" },
  { id: "Civil / Mechanical Engineer", icon: "⚙️" }, { id: "Teacher / Professor", icon: "📚" },
  { id: "Scientist / Researcher", icon: "🔬" }, { id: "Architect / Urban Designer", icon: "🏛️" },
  { id: "Commercial Pilot / Aviation", icon: "✈️" }, { id: "Entrepreneur / Business Leader", icon: "💼" },
  { id: "Lawyer / Judge", icon: "⚖️" }, { id: "Agricultural Specialist / AgriTech", icon: "🌱" },
  { id: "Accountant / Financial Analyst", icon: "📊" }, { id: "Digital Artist / Media Creator", icon: "🎨" },
  { id: "Electrician / Power Engineer", icon: "⚡" }, { id: "Marine Biologist / Conservationist", icon: "🐬" },
  { id: "Veterinarian / Animal Care", icon: "🐾" }, { id: "Data Scientist / Statistician", icon: "📈" }
];

const AVATAR_PRESETS = [
  { id: "robot-emerald", name: "Emerald Spark", emoji: "🤖", desc: "Friendly high-tech learning bot", color: "emerald" },
  { id: "cyber-owl", name: "Wisdom Owl", emoji: "🦉", desc: "Wise guardian of knowledge", color: "blue" },
  { id: "astro-guide", name: "Astro Guide", emoji: "👩‍🚀", desc: "Explorer of infinite subjects", color: "purple" },
  { id: "safari-cheetah", name: "Speed Cheetah", emoji: "🐆", desc: "Fast & sharp revision expert", color: "amber" },
  { id: "quantum-leopard", name: "Zen Leopard", emoji: "🐯", desc: "Patient & focused academic mentor", color: "rose" },
  { id: "digital-mentor", name: "Nova Mentor", emoji: "🌟", desc: "Inspirational study champion", color: "cyan" }
];

const GREETING_PRESETS = [
  "Ready to learn today? Let's unlock your full potential!",
  "Let's conquer today's lessons! Small steps lead to big victories.",
  "I'm here whenever you need help! Ask me anything, anytime.",
  "Hello champion, what subject are we mastering together today?",
  "Welcome back! Let's make progress toward your career dreams."
];

export const OnboardingModal: React.FC = () => {
  const { activeModal, setActiveModal, user, token, refreshUser, initData, setCurrentView } = useAuth();
  
  const [step, setStep] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [customGoal, setCustomGoal] = useState<string>('');
  const [customInterest, setCustomInterest] = useState<string>('');
  const [customCareer, setCustomCareer] = useState<string>('');
  const [formError, setFormError] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState<OnboardingState>({
    currentStep: 1,
    isCompleted: false,
    personalInfo: {
      profilePhoto: user?.profilePicture || '',
      fullName: user?.fullName || '',
      preferredName: '',
      gender: user?.gender || 'Female',
      dateOfBirth: user?.dateOfBirth || '2008-04-15',
      region: user?.region || 'Khomas',
      town: user?.town || 'Windhoek',
      school: user?.school || 'Delta Secondary School Windhoek',
      grade: user?.grade || 'Grade 11'
    },
    academicInfo: {
      subjectsStudying: user?.subjects || ['Mathematics', 'Physical Science', 'English First Language', 'Computer Studies'],
      favouriteSubject: 'Mathematics',
      difficultSubject: 'Physical Science',
      academicGoals: ['Improve Mathematics score', 'Pass Grade 10 / Grade 11 with Honors', 'Prepare for NSSCO / NSSCAS final exams']
    },
    learningPreferences: {
      learningStyles: ['Videos & Visuals', 'Practice Questions', 'Interactive Games & Activities'],
      studyFrequency: 'Daily',
      sessionLength: '45 Minutes',
      reminderTime: 'Evening (18:00)',
      customReminderTime: '19:30'
    },
    interests: user?.interests || ['Artificial Intelligence & Robotics', 'Software Development & Coding', 'Renewable Energy & Sustainability'],
    careerDreams: ['Software Developer / AI Engineer', 'Entrepreneur / Business Leader'],
    eduBuddy: {
      aiName: 'Edu Buddy',
      aiAvatar: 'robot-emerald',
      voicePreference: 'Friendly & Clear',
      conversationStyle: 'Motivational',
      accentColor: 'emerald',
      greetingStyle: "Ready to learn today? Let's unlock your full potential!",
      customGreeting: ''
    },
    notifications: {
      studyReminders: true,
      assignmentReminders: true,
      learningStreaks: true,
      motivationalMessages: true,
      schoolAnnouncements: true
    },
    privacySettings: {
      profileVisibility: 'Friends Only'
    }
  });

  // Load existing onboarding state from backend when modal opens
  useEffect(() => {
    if (activeModal === 'onboarding') {
      setLoading(true);
      fetch('/api/onboarding/state', {
        headers: token ? { 'Authorization': `Bearer ${token}` } : {}
      })
      .then(res => res.json())
      .then(res => {
        if (res.success && res.data) {
          setFormData(prev => ({
            ...prev,
            ...res.data,
            personalInfo: {
              ...prev.personalInfo,
              ...res.data.personalInfo
            },
            academicInfo: {
              ...prev.academicInfo,
              ...res.data.academicInfo
            },
            learningPreferences: {
              ...prev.learningPreferences,
              ...res.data.learningPreferences
            },
            eduBuddy: {
              ...prev.eduBuddy,
              ...res.data.eduBuddy
            },
            notifications: {
              ...prev.notifications,
              ...res.data.notifications
            },
            privacySettings: {
              ...prev.privacySettings,
              ...res.data.privacySettings
            }
          }));
          // If user previously reached a step, restore it (unless completed, start at 1 for evaluation)
          if (res.data.currentStep && res.data.currentStep > 1 && !res.data.isCompleted) {
            setStep(res.data.currentStep);
          } else {
            setStep(1);
          }
        }
      })
      .catch(err => console.error("Error loading onboarding state:", err))
      .finally(() => setLoading(false));
    }
  }, [activeModal, token]);

  if (activeModal !== 'onboarding') return null;

  // Total steps in onboarding
  const TOTAL_STEPS = 11;
  const STEP_TITLES = [
    "Welcome", "Personal Info", "Academic Profile", "Learning Habits",
    "Your Interests", "Career Dreams", "Create Edu Buddy", "Meet Edu Buddy",
    "Notifications", "Privacy Settings", "Celebration!"
  ];

  const handleSaveProgress = async (nextStep?: number) => {
    setSaving(true);
    setSaveMessage(null);
    setFormError(null);
    const targetStep = nextStep || step;

    try {
      const res = await fetch('/api/onboarding/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          step: targetStep,
          personalInfo: formData.personalInfo,
          academicInfo: formData.academicInfo,
          learningPreferences: formData.learningPreferences,
          interests: formData.interests,
          careerDreams: formData.careerDreams,
          eduBuddy: formData.eduBuddy,
          notifications: formData.notifications,
          privacySettings: formData.privacySettings
        })
      });
      const data = await res.json();
      if (data.success) {
        setSaveMessage('Progress saved!');
        setTimeout(() => setSaveMessage(null), 3000);
        if (nextStep) setStep(nextStep);
      } else {
        setFormError(data.error || 'Failed to save progress.');
      }
    } catch (e) {
      setFormError('Network error while saving.');
    } finally {
      setSaving(false);
    }
  };

  const handleCompleteOnboarding = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/onboarding/complete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        }
      });
      const data = await res.json();
      if (data.success) {
        await refreshUser();
        // Stay on step 11 (celebration)
      }
    } catch (e) {
      console.error("Completion error:", e);
    } finally {
      setSaving(false);
    }
  };

  const validateStepAndNext = () => {
    setFormError(null);
    if (step === 2) {
      if (!formData.personalInfo.fullName.trim()) {
        setFormError("Please enter your full name.");
        return;
      }
      if (!formData.personalInfo.school.trim()) {
        setFormError("Please select or enter your school.");
        return;
      }
    }
    if (step === 3) {
      if (formData.academicInfo.subjectsStudying.length === 0) {
        setFormError("Please select at least one subject you are currently studying.");
        return;
      }
    }
    if (step === 4) {
      if (formData.learningPreferences.learningStyles.length === 0) {
        setFormError("Please select at least one preferred learning style.");
        return;
      }
    }
    if (step === 6) {
      if (formData.careerDreams.length === 0) {
        setFormError("Please select at least one career aspiration or dream.");
        return;
      }
    }

    if (step === 10) {
      // Step 10 is Privacy, proceeding to step 11 triggers completion!
      handleSaveProgress(11);
      handleCompleteOnboarding();
    } else {
      handleSaveProgress(step + 1);
    }
  };

  const toggleSubject = (sub: string) => {
    const list = formData.academicInfo.subjectsStudying;
    const exists = list.includes(sub);
    const updated = exists ? list.filter(s => s !== sub) : [...list, sub];
    setFormData({
      ...formData,
      academicInfo: { ...formData.academicInfo, subjectsStudying: updated }
    });
  };

  const toggleGoal = (goal: string) => {
    const list = formData.academicInfo.academicGoals;
    const exists = list.includes(goal);
    const updated = exists ? list.filter(g => g !== goal) : [...list, goal];
    setFormData({
      ...formData,
      academicInfo: { ...formData.academicInfo, academicGoals: updated }
    });
  };

  const addCustomGoal = () => {
    if (!customGoal.trim()) return;
    if (!formData.academicInfo.academicGoals.includes(customGoal.trim())) {
      setFormData({
        ...formData,
        academicInfo: {
          ...formData.academicInfo,
          academicGoals: [...formData.academicInfo.academicGoals, customGoal.trim()]
        }
      });
    }
    setCustomGoal('');
  };

  const toggleStyle = (styleId: string) => {
    const list = formData.learningPreferences.learningStyles;
    const exists = list.includes(styleId);
    const updated = exists ? list.filter(s => s !== styleId) : [...list, styleId];
    setFormData({
      ...formData,
      learningPreferences: { ...formData.learningPreferences, learningStyles: updated }
    });
  };

  const toggleInterest = (interest: string) => {
    const list = formData.interests;
    const exists = list.includes(interest);
    const updated = exists ? list.filter(i => i !== interest) : [...list, interest];
    setFormData({ ...formData, interests: updated });
  };

  const addCustomInterest = () => {
    if (!customInterest.trim()) return;
    if (!formData.interests.includes(customInterest.trim())) {
      setFormData({ ...formData, interests: [...formData.interests, customInterest.trim()] });
    }
    setCustomInterest('');
  };

  const toggleCareer = (career: string) => {
    const list = formData.careerDreams;
    const exists = list.includes(career);
    const updated = exists ? list.filter(c => c !== career) : [...list, career];
    setFormData({ ...formData, careerDreams: updated });
  };

  const addCustomCareer = () => {
    if (!customCareer.trim()) return;
    if (!formData.careerDreams.includes(customCareer.trim())) {
      setFormData({ ...formData, careerDreams: [...formData.careerDreams, customCareer.trim()] });
    }
    setCustomCareer('');
  };

  const regenerateAvatar = () => {
    const randomSeed = Math.random().toString(36).substring(2, 8);
    setFormData({
      ...formData,
      personalInfo: {
        ...formData.personalInfo,
        profilePhoto: `https://api.dicebear.com/7.x/avataaars/svg?seed=${randomSeed}`
      }
    });
  };

  const getSelectedAvatarObj = () => {
    return AVATAR_PRESETS.find(a => a.id === formData.eduBuddy.aiAvatar) || AVATAR_PRESETS[0];
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        transition={{ duration: 0.3 }}
        className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Top Header & Progress Indicator */}
        <div className="bg-[#0A2540] text-white px-6 py-4 flex flex-col gap-3 border-b border-slate-800 shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm border border-emerald-500/30">
                {step}
              </span>
              <div>
                <h3 className="text-sm font-bold tracking-wide uppercase text-emerald-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  Phase 2: Student Onboarding
                </h3>
                <p className="text-xs text-slate-300">
                  Step {step} of {TOTAL_STEPS}: <span className="text-white font-medium">{STEP_TITLES[step - 1]}</span>
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {saveMessage && (
                <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2.5 py-1 rounded-full border border-emerald-500/30 flex items-center gap-1 animate-pulse">
                  <Check className="w-3 h-3" /> {saveMessage}
                </span>
              )}
              <button
                type="button"
                onClick={() => handleSaveProgress()}
                disabled={saving || loading}
                className="text-xs bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-lg transition font-medium flex items-center gap-1.5"
                title="Save progress and continue later"
              >
                <Save className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{saving ? 'Saving...' : 'Save Later'}</span>
              </button>
              <button 
                type="button" 
                onClick={() => setActiveModal(null)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition ml-1"
                title="Close Onboarding"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Segmented Progress Bar */}
          <div className="grid grid-cols-11 gap-1.5 w-full pt-1">
            {Array.from({ length: TOTAL_STEPS }).map((_, idx) => {
              const stepNum = idx + 1;
              const isDone = stepNum < step;
              const isCurr = stepNum === step;
              return (
                <button
                  key={stepNum}
                  type="button"
                  onClick={() => { if (isDone || stepNum <= (formData.currentStep || 1)) setStep(stepNum); }}
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    isDone 
                      ? 'bg-emerald-500 hover:bg-emerald-400' 
                      : isCurr 
                        ? 'bg-emerald-400 ring-2 ring-emerald-400/30 ring-offset-2 ring-offset-[#0A2540]' 
                        : 'bg-slate-700/60 hover:bg-slate-600'
                  }`}
                  title={`Step ${stepNum}: ${STEP_TITLES[idx]}`}
                />
              );
            })}
          </div>
        </div>

        {/* Modal Body (Scrollable) */}
        <div className="p-6 sm:p-8 overflow-y-auto flex-grow text-slate-800 dark:text-slate-200">
          {loading ? (
            <div className="py-20 flex flex-col items-center justify-center gap-4">
              <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
              <p className="text-sm font-medium text-slate-500">Loading your onboarding profile...</p>
            </div>
          ) : (
            <AnimatePresence mode="wait">
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 15 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -15 }}
                transition={{ duration: 0.25 }}
                className="flex flex-col gap-6 max-w-3xl mx-auto"
              >
                {/* STEP 1: WELCOME SCREEN */}
                {step === 1 && (
                  <div className="text-center py-6 flex flex-col items-center gap-6">
                    <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-[#0A2540] to-emerald-600 flex items-center justify-center shadow-xl shadow-emerald-500/20 text-white transform -rotate-3 hover:rotate-0 transition duration-300">
                      <GraduationCap className="w-10 h-10" />
                    </div>
                    <div>
                      <span className="inline-block px-3 py-1 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 rounded-full text-xs font-bold uppercase tracking-wider mb-2">
                        Welcome to the Future of Namibian Learning
                      </span>
                      <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
                        Welcome to Edu Journey Pro!
                      </h2>
                      <p className="text-slate-600 dark:text-slate-400 max-w-lg mx-auto mt-2 text-sm sm:text-base leading-relaxed">
                        We are thrilled to have you here! Before you dive into your studies, let's take a few minutes to personalize your educational ecosystem.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full text-left my-2">
                      <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 flex flex-col gap-2">
                        <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
                          1
                        </div>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white">Tailored Subjects</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Select your exact Grade and NSSCO/NSSCAS subjects for custom revision.</p>
                      </div>
                      <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 flex flex-col gap-2">
                        <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                          2
                        </div>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white">Edu Buddy AI</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Design your personal 24/7 AI tutor with your preferred personality & avatar.</p>
                      </div>
                      <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 flex flex-col gap-2">
                        <div className="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-900/40 text-purple-600 dark:text-purple-400 flex items-center justify-center font-bold">
                          3
                        </div>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white">Career Mapping</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Align daily study goals with your dream profession and university aspirations.</p>
                      </div>
                    </div>

                    <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 rounded-xl p-3.5 flex items-center gap-3 text-left w-full">
                      <Clock className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
                      <p className="text-xs text-amber-900 dark:text-amber-200">
                        <strong>Takes ~3 minutes.</strong> You can save your progress at any step and finish later!
                      </p>
                    </div>
                  </div>
                )}

                {/* STEP 2: PERSONAL INFORMATION */}
                {step === 2 && (
                  <div className="flex flex-col gap-5">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <User className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                        Personal Information
                      </h3>
                      <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                        Review and edit your profile details from registration. This helps us connect you with classmates and teachers in your region.
                      </p>
                    </div>

                    <div className="flex flex-col sm:flex-row items-center gap-6 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800">
                      <div className="relative group">
                        <img 
                          src={formData.personalInfo.profilePhoto || `https://api.dicebear.com/7.x/avataaars/svg?seed=student`} 
                          alt="Profile Avatar" 
                          className="w-20 h-20 rounded-full border-2 border-emerald-500 object-cover bg-white shadow-md"
                        />
                        <button
                          type="button"
                          onClick={regenerateAvatar}
                          className="absolute -bottom-1 -right-1 p-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full shadow transition"
                          title="Generate new avatar"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <div className="flex-grow text-center sm:text-left">
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white">Profile Photo & Avatar</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                          Click the refresh icon to generate an animated avatar, or paste a direct image URL below.
                        </p>
                        <input
                          type="text"
                          placeholder="Or paste photo URL..."
                          value={formData.personalInfo.profilePhoto || ''}
                          onChange={e => setFormData({ ...formData, personalInfo: { ...formData.personalInfo, profilePhoto: e.target.value } })}
                          className="mt-2 w-full text-xs px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:ring-1 focus:ring-emerald-500 outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                          Full Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.personalInfo.fullName}
                          onChange={e => setFormData({ ...formData, personalInfo: { ...formData.personalInfo, fullName: e.target.value } })}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                          placeholder="e.g. Tangi Amukwaya"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                          Preferred Name (Optional)
                        </label>
                        <input
                          type="text"
                          value={formData.personalInfo.preferredName || ''}
                          onChange={e => setFormData({ ...formData, personalInfo: { ...formData.personalInfo, preferredName: e.target.value } })}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                          placeholder="e.g. Tangi"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                          Gender
                        </label>
                        <select
                          value={formData.personalInfo.gender}
                          onChange={e => setFormData({ ...formData, personalInfo: { ...formData.personalInfo, gender: e.target.value } })}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                        >
                          <option value="Female">Female</option>
                          <option value="Male">Male</option>
                          <option value="Prefer not to say">Prefer not to say</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                          Date of Birth
                        </label>
                        <input
                          type="date"
                          value={formData.personalInfo.dateOfBirth}
                          onChange={e => setFormData({ ...formData, personalInfo: { ...formData.personalInfo, dateOfBirth: e.target.value } })}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                          Namibian Region *
                        </label>
                        <select
                          value={formData.personalInfo.region}
                          onChange={e => setFormData({ ...formData, personalInfo: { ...formData.personalInfo, region: e.target.value } })}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                        >
                          {NAMIBIAN_REGIONS.map(reg => (
                            <option key={reg} value={reg}>{reg} Region</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                          Town / City
                        </label>
                        <input
                          type="text"
                          value={formData.personalInfo.town}
                          onChange={e => setFormData({ ...formData, personalInfo: { ...formData.personalInfo, town: e.target.value } })}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                          placeholder="e.g. Windhoek, Swakopmund, Oshakati"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                          School Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.personalInfo.school}
                          onChange={e => setFormData({ ...formData, personalInfo: { ...formData.personalInfo, school: e.target.value } })}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                          placeholder="e.g. Delta Secondary School Windhoek"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                          Current Grade Level *
                        </label>
                        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                          {["Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12", "AS Level"].map(grd => (
                            <button
                              key={grd}
                              type="button"
                              onClick={() => setFormData({ ...formData, personalInfo: { ...formData.personalInfo, grade: grd } })}
                              className={`py-2 px-3 rounded-xl text-xs font-bold transition border ${
                                formData.personalInfo.grade === grd
                                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700 hover:border-emerald-500'
                              }`}
                            >
                              {grd}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* STEP 3: ACADEMIC INFORMATION */}
                {step === 3 && (
                  <div className="flex flex-col gap-5">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <BookOpen className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                        Academic Profile & Subjects
                      </h3>
                      <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                        Select the subjects you are currently studying. Edu Buddy AI will customize quiz questions and lesson notes to match your curriculum.
                      </p>
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-2">
                        Subjects You Are Currently Studying (Select all that apply)
                      </label>
                      <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto p-3 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-800">
                        {STANDARD_SUBJECTS.map(sub => {
                          const isSel = formData.academicInfo.subjectsStudying.includes(sub);
                          return (
                            <button
                              key={sub}
                              type="button"
                              onClick={() => toggleSubject(sub)}
                              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition flex items-center gap-1.5 border ${
                                isSel
                                  ? 'bg-[#0A2540] text-white border-[#0A2540] shadow-sm'
                                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700 hover:border-emerald-500'
                              }`}
                            >
                              {isSel && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                              {sub}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1 flex items-center gap-1">
                          <Star className="w-3.5 h-3.5 text-amber-500" />
                          Favourite Subject
                        </label>
                        <select
                          value={formData.academicInfo.favouriteSubject}
                          onChange={e => setFormData({ ...formData, academicInfo: { ...formData.academicInfo, favouriteSubject: e.target.value } })}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                        >
                          {formData.academicInfo.subjectsStudying.length > 0 ? (
                            formData.academicInfo.subjectsStudying.map(sub => (
                              <option key={sub} value={sub}>{sub}</option>
                            ))
                          ) : (
                            STANDARD_SUBJECTS.slice(0, 5).map(sub => (
                              <option key={sub} value={sub}>{sub}</option>
                            ))
                          )}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1 flex items-center gap-1">
                          <Target className="w-3.5 h-3.5 text-rose-500" />
                          Most Difficult Subject (Needs Focus)
                        </label>
                        <select
                          value={formData.academicInfo.difficultSubject}
                          onChange={e => setFormData({ ...formData, academicInfo: { ...formData.academicInfo, difficultSubject: e.target.value } })}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                        >
                          {formData.academicInfo.subjectsStudying.length > 0 ? (
                            formData.academicInfo.subjectsStudying.map(sub => (
                              <option key={sub} value={sub}>{sub}</option>
                            ))
                          ) : (
                            STANDARD_SUBJECTS.slice(0, 5).map(sub => (
                              <option key={sub} value={sub}>{sub}</option>
                            ))
                          )}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-2">
                        Your Academic Goals This Term (Select or add your own)
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {STANDARD_GOALS.map(goal => {
                          const isSel = formData.academicInfo.academicGoals.includes(goal);
                          return (
                            <button
                              key={goal}
                              type="button"
                              onClick={() => toggleGoal(goal)}
                              className={`p-3 rounded-xl text-xs font-medium text-left transition flex items-center justify-between border ${
                                isSel
                                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-300 border-emerald-500'
                                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                              }`}
                            >
                              <span>{goal}</span>
                              {isSel ? <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" /> : <div className="w-4 h-4 rounded-full border border-slate-300 dark:border-slate-600 shrink-0" />}
                            </button>
                          );
                        })}
                      </div>

                      {/* Custom Goal Input */}
                      <div className="flex gap-2 mt-3">
                        <input
                          type="text"
                          value={customGoal}
                          onChange={e => setCustomGoal(e.target.value)}
                          onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addCustomGoal())}
                          placeholder="Write a custom academic goal..."
                          className="flex-grow px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-xs"
                        />
                        <button
                          type="button"
                          onClick={addCustomGoal}
                          className="px-4 py-2 bg-[#0A2540] hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition whitespace-nowrap"
                        >
                          + Add Goal
                        </button>
                      </div>

                      {/* Selected Custom Goals display */}
                      {formData.academicInfo.academicGoals.filter(g => !STANDARD_GOALS.includes(g)).length > 0 && (
                        <div className="flex flex-wrap gap-1.5 mt-2.5">
                          {formData.academicInfo.academicGoals.filter(g => !STANDARD_GOALS.includes(g)).map(g => (
                            <span key={g} className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 rounded-lg text-xs font-medium">
                              {g}
                              <button type="button" onClick={() => toggleGoal(g)} className="hover:text-red-500">
                                <X className="w-3 h-3" />
                              </button>
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* STEP 4: LEARNING PREFERENCES */}
                {step === 4 && (
                  <div className="flex flex-col gap-5">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <Zap className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                        Learning Habits & Preferences
                      </h3>
                      <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                        How do you learn best? We will adapt our explanations, study reminders, and quizzes to match your natural learning rhythm.
                      </p>
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-2">
                        Preferred Learning Styles (Select all that apply)
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {LEARNING_STYLES_OPTIONS.map(st => {
                          const isSel = formData.learningPreferences.learningStyles.includes(st.id);
                          return (
                            <button
                              key={st.id}
                              type="button"
                              onClick={() => toggleStyle(st.id)}
                              className={`p-3.5 rounded-2xl text-left transition border flex flex-col gap-1 ${
                                isSel
                                  ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 shadow-sm'
                                  : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-sm text-slate-900 dark:text-white">{st.label}</span>
                                {isSel ? <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /> : <div className="w-4 h-4 rounded-full border border-slate-300 dark:border-slate-600" />}
                              </div>
                              <p className="text-xs text-slate-500 dark:text-slate-400 leading-snug">{st.desc}</p>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                          Study Frequency
                        </label>
                        <select
                          value={formData.learningPreferences.studyFrequency}
                          onChange={e => setFormData({ ...formData, learningPreferences: { ...formData.learningPreferences, studyFrequency: e.target.value } })}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                        >
                          <option value="Daily">Daily (7 days a week)</option>
                          <option value="Weekdays">Weekdays only (Mon - Fri)</option>
                          <option value="Weekends">Weekends only (Sat - Sun)</option>
                          <option value="Occasionally">Occasionally / Before exams</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                          Typical Session Length
                        </label>
                        <select
                          value={formData.learningPreferences.sessionLength}
                          onChange={e => setFormData({ ...formData, learningPreferences: { ...formData.learningPreferences, sessionLength: e.target.value } })}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                        >
                          <option value="15 Minutes">15 Minutes (Quick Sprint)</option>
                          <option value="30 Minutes">30 Minutes (Standard)</option>
                          <option value="45 Minutes">45 Minutes (Deep Focus)</option>
                          <option value="1 Hour">1 Hour (Intensive)</option>
                          <option value="2 Hours">2 Hours (Exam Marathon)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                          Study Reminder Time
                        </label>
                        <select
                          value={formData.learningPreferences.reminderTime}
                          onChange={e => setFormData({ ...formData, learningPreferences: { ...formData.learningPreferences, reminderTime: e.target.value } })}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                        >
                          <option value="Morning (07:00)">Morning (07:00 AM)</option>
                          <option value="Afternoon (15:00)">Afternoon (03:00 PM)</option>
                          <option value="Evening (18:00)">Evening (06:00 PM)</option>
                          <option value="Custom Time">Custom Time</option>
                        </select>
                      </div>
                    </div>

                    {formData.learningPreferences.reminderTime === 'Custom Time' && (
                      <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                        <span className="text-xs font-medium text-slate-700 dark:text-slate-300">Set your exact preferred daily reminder time:</span>
                        <input
                          type="time"
                          value={formData.learningPreferences.customReminderTime || '19:00'}
                          onChange={e => setFormData({ ...formData, learningPreferences: { ...formData.learningPreferences, customReminderTime: e.target.value } })}
                          className="px-3 py-1 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm font-bold"
                        />
                      </div>
                    )}
                  </div>
                )}

                {/* STEP 5: INTERESTS */}
                {step === 5 && (
                  <div className="flex flex-col gap-5">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <Compass className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                        Educational & Extracurricular Interests
                      </h3>
                      <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                        What topics fascinate you outside the standard classroom? Edu Buddy will include real-world examples from your favorite interests.
                      </p>
                    </div>

                    <div className="flex flex-col gap-4">
                      {INTEREST_CATEGORIES.map(cat => (
                        <div key={cat.category} className="flex flex-col gap-2">
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                            {cat.category}
                          </h4>
                          <div className="flex flex-wrap gap-2">
                            {cat.items.map(item => {
                              const isSel = formData.interests.includes(item);
                              return (
                                <button
                                  key={item}
                                  type="button"
                                  onClick={() => toggleInterest(item)}
                                  className={`px-3.5 py-2 rounded-xl text-xs font-medium transition flex items-center gap-1.5 border ${
                                    isSel
                                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-emerald-500'
                                  }`}
                                >
                                  {isSel && <Check className="w-3.5 h-3.5" />}
                                  {item}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Custom Interest */}
                    <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
                      <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1.5">
                        Have another unique interest? Add it here:
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={customInterest}
                          onChange={e => setCustomInterest(e.target.value)}
                          onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addCustomInterest())}
                          placeholder="e.g. Marine Robotics, Creative Photography, Namibian Folklore..."
                          className="flex-grow px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-xs"
                        />
                        <button
                          type="button"
                          onClick={addCustomInterest}
                          className="px-4 py-2 bg-[#0A2540] hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition whitespace-nowrap"
                        >
                          + Add Interest
                        </button>
                      </div>

                      {/* Display custom interests */}
                      {formData.interests.filter(i => !INTEREST_CATEGORIES.flatMap(c => c.items).includes(i)).length > 0 && (
                        <div className="flex flex-wrap gap-1.5 mt-2.5">
                          {formData.interests.filter(i => !INTEREST_CATEGORIES.flatMap(c => c.items).includes(i)).map(i => (
                            <span key={i} className="inline-flex items-center gap-1.5 px-3 py-1 bg-purple-100 dark:bg-purple-900/50 text-purple-800 dark:text-purple-200 rounded-lg text-xs font-medium">
                              {i}
                              <button type="button" onClick={() => toggleInterest(i)} className="hover:text-red-500">
                                <X className="w-3 h-3" />
                              </button>
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* STEP 6: CAREER DREAMS */}
                {step === 6 && (
                  <div className="flex flex-col gap-5">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <Trophy className="w-5 h-5 text-amber-500" />
                        Your Career Dreams & Aspirations
                      </h3>
                      <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                        What would you like to become in the future? You can select multiple dreams! We will link your school subjects directly to career pathways.
                      </p>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-h-72 overflow-y-auto p-1">
                      {CAREER_OPTIONS.map(car => {
                        const isSel = formData.careerDreams.includes(car.id);
                        return (
                          <button
                            key={car.id}
                            type="button"
                            onClick={() => toggleCareer(car.id)}
                            className={`p-3 rounded-2xl text-left transition border flex flex-col items-center text-center justify-center gap-2 ${
                              isSel
                                ? 'bg-[#0A2540] text-white border-[#0A2540] shadow-md ring-2 ring-emerald-500'
                                : 'bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-emerald-500'
                            }`}
                          >
                            <span className="text-2xl">{car.icon}</span>
                            <span className="font-bold text-xs leading-tight">{car.id}</span>
                            {isSel && <span className="w-2 h-2 rounded-full bg-emerald-400 mt-0.5" />}
                          </button>
                        );
                      })}
                    </div>

                    {/* Custom Career */}
                    <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row gap-2">
                      <input
                        type="text"
                        value={customCareer}
                        onChange={e => setCustomCareer(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addCustomCareer())}
                        placeholder="Or write your custom career dream..."
                        className="flex-grow px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-xs"
                      />
                      <button
                        type="button"
                        onClick={addCustomCareer}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition whitespace-nowrap"
                      >
                        + Add Custom Dream
                      </button>
                    </div>

                    {/* Selected custom career tags */}
                    {formData.careerDreams.filter(c => !CAREER_OPTIONS.map(o => o.id).includes(c)).length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {formData.careerDreams.filter(c => !CAREER_OPTIONS.map(o => o.id).includes(c)).map(c => (
                          <span key={c} className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-100 dark:bg-amber-900/50 text-amber-800 dark:text-amber-200 rounded-lg text-xs font-bold">
                            ✨ {c}
                            <button type="button" onClick={() => toggleCareer(c)} className="hover:text-red-500">
                              <X className="w-3 h-3" />
                            </button>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* STEP 7: CREATE EDU BUDDY AI */}
                {step === 7 && (
                  <div className="flex flex-col gap-5">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <Bot className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                        Create Your Edu Buddy AI
                      </h3>
                      <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                        Design your personal 24/7 AI tutor! Choose their name, avatar appearance, conversation tone, and greeting style.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      {/* Left: Name & Avatar selection */}
                      <div className="flex flex-col gap-4">
                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                            AI Companion Name
                          </label>
                          <input
                            type="text"
                            value={formData.eduBuddy.aiName}
                            onChange={e => setFormData({ ...formData, eduBuddy: { ...formData.eduBuddy, aiName: e.target.value } })}
                            className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm font-bold"
                            placeholder="e.g. Edu Buddy, Sparky, Professor Nova"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-2">
                            Choose AI Avatar Style
                          </label>
                          <div className="grid grid-cols-3 gap-2">
                            {AVATAR_PRESETS.map(av => {
                              const isSel = formData.eduBuddy.aiAvatar === av.id;
                              return (
                                <button
                                  key={av.id}
                                  type="button"
                                  onClick={() => setFormData({ ...formData, eduBuddy: { ...formData.eduBuddy, aiAvatar: av.id, accentColor: av.color } })}
                                  className={`p-2.5 rounded-2xl text-center transition border flex flex-col items-center gap-1 ${
                                    isSel
                                      ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 ring-2 ring-emerald-500/30'
                                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                                  }`}
                                >
                                  <span className="text-2xl">{av.emoji}</span>
                                  <span className="font-bold text-[11px] text-slate-800 dark:text-slate-200 leading-tight">{av.name}</span>
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                            Voice Preference <span className="text-[10px] text-emerald-600 font-normal">(Audio speech coming soon in Phase 3!)</span>
                          </label>
                          <select
                            value={formData.eduBuddy.voicePreference}
                            onChange={e => setFormData({ ...formData, eduBuddy: { ...formData.eduBuddy, voicePreference: e.target.value } })}
                            className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
                          >
                            <option value="Friendly & Clear">Friendly & Clear (Default)</option>
                            <option value="Calm & Encouraging">Calm & Encouraging</option>
                            <option value="Energetic & Fast">Energetic & Fast</option>
                            <option value="Professional & Scholarly">Professional & Scholarly</option>
                          </select>
                        </div>
                      </div>

                      {/* Right: Tone & Greeting */}
                      <div className="flex flex-col gap-4">
                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                            Conversation Tone & Style
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            {["Friendly", "Professional", "Funny", "Motivational", "Patient", "Balanced"].map(tone => {
                              const isSel = formData.eduBuddy.conversationStyle === tone;
                              return (
                                <button
                                  key={tone}
                                  type="button"
                                  onClick={() => setFormData({ ...formData, eduBuddy: { ...formData.eduBuddy, conversationStyle: tone as any } })}
                                  className={`py-2 px-3 rounded-xl text-xs font-bold transition border text-center ${
                                    isSel
                                      ? 'bg-[#0A2540] text-white border-[#0A2540]'
                                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-emerald-500'
                                  }`}
                                >
                                  {tone}
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1">
                            Choose First Greeting Style
                          </label>
                          <select
                            value={formData.eduBuddy.greetingStyle}
                            onChange={e => setFormData({ ...formData, eduBuddy: { ...formData.eduBuddy, greetingStyle: e.target.value } })}
                            className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none text-xs"
                          >
                            {GREETING_PRESETS.map(grt => (
                              <option key={grt} value={grt}>{grt}</option>
                            ))}
                          </select>
                        </div>

                        {/* Live Buddy Card Preview */}
                        <div className="p-4 rounded-2xl bg-gradient-to-br from-[#0A2540] to-slate-900 text-white border border-slate-700 shadow-md flex items-center gap-3 mt-1">
                          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-3xl shrink-0 border border-emerald-500/30">
                            {getSelectedAvatarObj().emoji}
                          </div>
                          <div className="flex-grow">
                            <div className="flex items-center gap-2">
                              <span className="font-extrabold text-sm text-emerald-400">{formData.eduBuddy.aiName}</span>
                              <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded-full">{formData.eduBuddy.conversationStyle}</span>
                            </div>
                            <p className="text-xs text-slate-300 mt-1 italic">
                              "{formData.eduBuddy.greetingStyle}"
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* STEP 8: EDU BUDDY INTRODUCTION SCREEN */}
                {step === 8 && (
                  <div className="text-center py-6 flex flex-col items-center gap-6">
                    <motion.div 
                      initial={{ scale: 0.8, rotate: -10 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ type: "spring", stiffness: 200, damping: 15 }}
                      className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-[#0A2540] via-emerald-600 to-teal-400 flex items-center justify-center shadow-2xl shadow-emerald-500/30 text-5xl border-2 border-white/20"
                    >
                      {getSelectedAvatarObj().emoji}
                    </motion.div>

                    <div className="max-w-md mx-auto">
                      <span className="inline-block px-3 py-1 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 rounded-full text-xs font-bold uppercase tracking-wider mb-2">
                        Meet Your Learning Companion
                      </span>
                      <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
                        Hi {formData.personalInfo.preferredName || formData.personalInfo.fullName.split(' ')[0] || 'there'}! I'm {formData.eduBuddy.aiName}.
                      </h2>
                    </div>

                    <div className="p-6 rounded-3xl bg-gradient-to-br from-slate-50 to-emerald-50/50 dark:from-slate-800/80 dark:to-emerald-950/30 border border-emerald-500/30 text-left relative shadow-lg max-w-xl mx-auto">
                      <div className="absolute -top-3 left-6 px-3 py-0.5 bg-emerald-600 text-white text-[10px] font-bold uppercase rounded-full tracking-wider shadow">
                        {formData.eduBuddy.aiName}'s Pledge
                      </div>
                      <p className="text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed pt-2">
                        "I'm here to help you learn, revise, understand difficult topics, prepare for NSSCO/NSSCAS tests, stay motivated, and achieve your goal of becoming a <strong>{formData.careerDreams[0] || 'successful champion'}</strong>.
                        <br /><br />
                        <span className="text-slate-900 dark:text-white font-semibold">Remember: I will never replace your teachers or parents.</span> I'm your personal 24/7 learning companion, ready whenever you need study assistance or encouragement!"
                      </p>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full max-w-xl text-left">
                      <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                        <span className="text-xs text-slate-400 block">Tone</span>
                        <span className="font-bold text-sm text-slate-900 dark:text-white">{formData.eduBuddy.conversationStyle}</span>
                      </div>
                      <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                        <span className="text-xs text-slate-400 block">Avatar</span>
                        <span className="font-bold text-sm text-slate-900 dark:text-white">{getSelectedAvatarObj().name}</span>
                      </div>
                      <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                        <span className="text-xs text-slate-400 block">Focus</span>
                        <span className="font-bold text-sm text-slate-900 dark:text-white">{formData.academicInfo.difficultSubject || 'Science'} Help</span>
                      </div>
                      <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                        <span className="text-xs text-slate-400 block">Availability</span>
                        <span className="font-bold text-sm text-emerald-600 dark:text-emerald-400">24/7 Always Ready</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* STEP 9: NOTIFICATIONS */}
                {step === 9 && (
                  <div className="flex flex-col gap-5">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <Bell className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                        Notification Preferences
                      </h3>
                      <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                        Choose what alerts you would like to receive. You can enable all now and change them anytime in your Profile Settings.
                      </p>
                    </div>

                    <div className="flex flex-col gap-3">
                      {[
                        { key: 'studyReminders', title: "Study Reminders", desc: `Daily reminder at ${formData.learningPreferences.reminderTime || 'Evening'} to start your revision session.` },
                        { key: 'assignmentReminders', title: "Assignment & Test Alerts", desc: "Timely alerts 24 hours before school homework deadlines and NSSCO tests." },
                        { key: 'learningStreaks', title: "Learning Streaks & Badges", desc: "Celebrate milestones when you maintain a 3-day, 7-day, or 30-day streak." },
                        { key: 'motivationalMessages', title: "Motivational Boosts from Edu Buddy", desc: "Short encouraging quotes and tips from your AI companion during study breaks." },
                        { key: 'schoolAnnouncements', title: "School & Namibian Curriculum News", desc: "Important updates from Ministry of Education and your school teachers." }
                      ].map(notif => {
                        const isChecked = (formData.notifications as any)[notif.key];
                        return (
                          <label
                            key={notif.key}
                            className={`p-4 rounded-2xl border transition flex items-start justify-between cursor-pointer ${
                              isChecked
                                ? 'bg-emerald-50/50 dark:bg-emerald-950/30 border-emerald-500/50'
                                : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700'
                            }`}
                          >
                            <div className="pr-4">
                              <h4 className="font-bold text-sm text-slate-900 dark:text-white">{notif.title}</h4>
                              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{notif.desc}</p>
                            </div>
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={e => setFormData({
                                ...formData,
                                notifications: { ...formData.notifications, [notif.key]: e.target.checked }
                              })}
                              className="w-5 h-5 rounded text-emerald-600 focus:ring-emerald-500 mt-1 cursor-pointer"
                            />
                          </label>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* STEP 10: PRIVACY SETTINGS */}
                {step === 10 && (
                  <div className="flex flex-col gap-5">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <Shield className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                        Privacy & Profile Visibility
                      </h3>
                      <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                        We value your digital security! Choose who can see your academic achievements, study badges, and learning leaderboard ranking.
                      </p>
                    </div>

                    <div className="flex flex-col gap-3.5">
                      {[
                        {
                          id: 'Public Profile',
                          title: "Public Profile (Recommended for Community Leaderboards)",
                          desc: "Visible to fellow Namibian students. Participate in nationwide study challenges, regional subject leaderboards, and peer study groups."
                        },
                        {
                          id: 'Friends Only',
                          title: "Friends & Classmates Only",
                          desc: "Only approved classmates from your school and trusted friends can view your study badges and active revision streaks."
                        },
                        {
                          id: 'Private Profile',
                          title: "Private Profile",
                          desc: "Only you and your verified school teachers can see your academic analytics and study history. Your profile is hidden from leaderboards."
                        }
                      ].map(opt => {
                        const isSel = formData.privacySettings.profileVisibility === opt.id;
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => setFormData({ ...formData, privacySettings: { profileVisibility: opt.id as any } })}
                            className={`p-4 rounded-2xl text-left transition border flex items-start gap-3.5 ${
                              isSel
                                ? 'bg-[#0A2540] text-white border-[#0A2540] shadow-md ring-2 ring-emerald-500'
                                : 'bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                            }`}
                          >
                            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center mt-0.5 shrink-0 ${
                              isSel ? 'border-emerald-400 bg-emerald-500' : 'border-slate-400 dark:border-slate-600'
                            }`}>
                              {isSel && <div className="w-2 h-2 rounded-full bg-white" />}
                            </div>
                            <div>
                              <h4 className="font-bold text-sm">{opt.title}</h4>
                              <p className={`text-xs mt-1 leading-relaxed ${isSel ? 'text-slate-300' : 'text-slate-500 dark:text-slate-400'}`}>
                                {opt.desc}
                              </p>
                            </div>
                          </button>
                        );
                      })}
                    </div>

                    <div className="bg-slate-100 dark:bg-slate-800/80 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-400 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Note: You can update your privacy settings and download your data anytime in your account settings.</span>
                    </div>
                  </div>
                )}

                {/* STEP 11: CELEBRATION SCREEN */}
                {step === 11 && (
                  <div className="text-center py-6 flex flex-col items-center gap-6 relative">
                    {/* Confetti simulation header */}
                    <div className="flex items-center gap-3 text-2xl animate-bounce">
                      <span>🎉</span><span>✨</span><span>🏆</span><span>✨</span><span>🎉</span>
                    </div>

                    <div>
                      <span className="inline-block px-3 py-1 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 rounded-full text-xs font-bold uppercase tracking-wider mb-2">
                        Onboarding Complete!
                      </span>
                      <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
                        Congratulations, {formData.personalInfo.preferredName || formData.personalInfo.fullName.split(' ')[0]}!
                      </h2>
                      <p className="text-slate-600 dark:text-slate-400 max-w-lg mx-auto mt-2 text-sm sm:text-base leading-relaxed">
                        Your personalized learning ecosystem is fully configured and ready for action! Here is your official Edu Journey Pro setup summary:
                      </p>
                    </div>

                    {/* AI Personalization Summary Card */}
                    <div className="w-full max-w-2xl bg-gradient-to-br from-[#0A2540] to-slate-900 text-white rounded-3xl p-6 border border-slate-700 shadow-xl text-left grid grid-cols-1 sm:grid-cols-2 gap-5 relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
                      
                      <div className="flex items-center gap-3.5 border-b sm:border-b-0 sm:border-r border-slate-700/80 pb-4 sm:pb-0 sm:pr-4">
                        <img 
                          src={formData.personalInfo.profilePhoto || `https://api.dicebear.com/7.x/avataaars/svg?seed=student`} 
                          alt="Student" 
                          className="w-16 h-16 rounded-2xl border-2 border-emerald-400 object-cover bg-white shrink-0"
                        />
                        <div>
                          <h4 className="font-extrabold text-base text-white">{formData.personalInfo.fullName}</h4>
                          <p className="text-xs text-emerald-400 font-medium">{formData.personalInfo.school}</p>
                          <span className="inline-block mt-1 px-2 py-0.5 bg-white/10 rounded text-[10px] font-bold uppercase tracking-wide">
                            {formData.personalInfo.grade} • {formData.personalInfo.region}
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-col justify-center gap-2 text-xs">
                        <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                          <span className="text-slate-400">Edu Buddy AI:</span>
                          <span className="font-bold text-emerald-400 flex items-center gap-1">
                            {getSelectedAvatarObj().emoji} {formData.eduBuddy.aiName} ({formData.eduBuddy.conversationStyle})
                          </span>
                        </div>
                        <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                          <span className="text-slate-400">Career Dream:</span>
                          <span className="font-bold text-white truncate max-w-[180px]" title={formData.careerDreams[0]}>
                            {formData.careerDreams[0] || 'Future Champion'}
                          </span>
                        </div>
                        <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                          <span className="text-slate-400">Focus Subject:</span>
                          <span className="font-bold text-rose-300">{formData.academicInfo.difficultSubject || 'Science'}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Study Habits:</span>
                          <span className="font-bold text-teal-300">{formData.learningPreferences.studyFrequency} ({formData.learningPreferences.sessionLength})</span>
                        </div>
                      </div>
                    </div>

                    {/* Phase 3 Notice Badge */}
                    <div className="bg-emerald-50 dark:bg-emerald-950/50 border-2 border-emerald-500/60 rounded-2xl p-4 w-full max-w-xl text-center shadow-lg animate-pulse">
                      <div className="flex items-center justify-center gap-2 text-emerald-800 dark:text-emerald-300 font-bold text-sm">
                        <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                        Phase 2 Onboarding Complete!
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                        <strong>Note for Evaluators:</strong> The Student Dashboard and interactive learning modules will be built in <strong>Phase 3</strong>. You have successfully verified the Phase 2 onboarding and Edu Buddy AI setup!
                      </p>
                    </div>

                    <div className="flex flex-col sm:flex-row items-center gap-3 w-full max-w-sm pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setActiveModal('profile');
                        }}
                        className="w-full py-3.5 px-6 bg-[#0A2540] hover:bg-slate-800 text-white font-extrabold rounded-2xl shadow-xl transition flex items-center justify-center gap-2 text-sm"
                      >
                        <span>View My Student Profile</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                      
                      <button
                        type="button"
                        onClick={() => {
                          setActiveModal(null);
                          setCurrentView('dashboard');
                        }}
                        className="w-full py-3.5 px-6 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-2xl shadow-xl shadow-emerald-600/20 transition flex items-center justify-center gap-2 text-sm"
                      >
                        <span>Continue to Dashboard</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}

                {/* Form Error Display */}
                {formError && (
                  <div className="p-3.5 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-xs font-medium flex items-center gap-2 animate-shake">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{formError}</span>
                  </div>
                )}

                {/* Footer Navigation Buttons */}
                {step < 11 && (
                  <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800 mt-2">
                    <div>
                      {step > 1 ? (
                        <button
                          type="button"
                          onClick={() => setStep(step - 1)}
                          className="py-2.5 px-4 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs flex items-center gap-1.5 transition"
                        >
                          <ArrowLeft className="w-4 h-4" />
                          <span>Back</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setActiveModal(null)}
                          className="py-2.5 px-4 rounded-xl text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 font-medium text-xs transition"
                        >
                          Cancel / Sign Out
                        </button>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleSaveProgress()}
                        disabled={saving}
                        className="py-2.5 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs flex items-center gap-1.5 transition"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Save</span>
                      </button>

                      <button
                        type="button"
                        onClick={validateStepAndNext}
                        disabled={saving}
                        className="py-2.5 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs shadow-lg shadow-emerald-600/20 flex items-center gap-1.5 transition transform active:scale-95"
                      >
                        <span>{step === 10 ? 'Finish Onboarding' : step === 1 ? 'Start Onboarding' : 'Continue'}</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          )}
        </div>
      </motion.div>
    </div>
  );
};
