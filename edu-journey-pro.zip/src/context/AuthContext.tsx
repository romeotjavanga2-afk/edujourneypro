import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, InitData, AuthModalType, AppViewType, DashboardNavTab } from '../types.js';

interface AuthContextType {
  user: User | null;
  token: string | null;
  loading: boolean;
  initData: InitData | null;
  activeModal: AuthModalType;
  selectedFeatureForPreview: string | null;
  isDarkMode: boolean;
  currentView: AppViewType;
  activeDashboardTab: DashboardNavTab;
  setActiveModal: (modal: AuthModalType) => void;
  setSelectedFeatureForPreview: (feature: string | null) => void;
  toggleDarkMode: () => void;
  setCurrentView: (view: AppViewType) => void;
  setActiveDashboardTab: (tab: DashboardNavTab) => void;
  login: (token: string, userData: User) => void;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('edujourney_token'));
  const [loading, setLoading] = useState<boolean>(true);
  const [initData, setInitData] = useState<InitData | null>(null);
  const [activeModal, setActiveModal] = useState<AuthModalType>(null);
  const [selectedFeatureForPreview, setSelectedFeatureForPreview] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<AppViewType>(() => {
    return (localStorage.getItem('edujourney_view') as AppViewType) || 'landing';
  });
  const [activeDashboardTab, setActiveDashboardTab] = useState<DashboardNavTab>('dashboard');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('edujourney_theme');
    if (saved) return saved === 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  useEffect(() => {
    localStorage.setItem('edujourney_view', currentView);
  }, [currentView]);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('edujourney_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('edujourney_theme', 'light');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode(prev => !prev);

  // Load Initialization Data (Regions, Schools, etc.)
  useEffect(() => {
    fetch('/api/init-data')
      .then(res => res.json())
      .then(res => {
        if (res.success) {
          setInitData(res.data);
        }
      })
      .catch(err => console.error('Failed to load init data:', err));
  }, []);

  // Verify active session on mount
  const refreshUser = async () => {
    const storedToken = localStorage.getItem('edujourney_token');
    if (!storedToken) {
      setLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${storedToken}` }
      });
      const data = await res.json();
      if (data.success && data.user) {
        setUser(data.user);
        setToken(storedToken);
      } else {
        localStorage.removeItem('edujourney_token');
        setUser(null);
        setToken(null);
      }
    } catch (e) {
      console.error('Session verification error:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshUser();
  }, []);

  const login = (newToken: string, userData: User) => {
    localStorage.setItem('edujourney_token', newToken);
    setToken(newToken);
    setUser(userData);
    if (!userData.isOnboardingCompleted) {
      setActiveModal('onboarding'); // Launch Phase 2 Onboarding flow!
    } else {
      setCurrentView('dashboard');
      setActiveModal(null);
    }
  };

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: token ? { 'Authorization': `Bearer ${token}` } : {}
      });
    } catch (e) {
      console.error('Logout error:', e);
    } finally {
      localStorage.removeItem('edujourney_token');
      setToken(null);
      setUser(null);
      setActiveModal(null);
      setCurrentView('landing');
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      token,
      loading,
      initData,
      activeModal,
      selectedFeatureForPreview,
      isDarkMode,
      currentView,
      activeDashboardTab,
      setActiveModal,
      setSelectedFeatureForPreview,
      toggleDarkMode,
      setCurrentView,
      setActiveDashboardTab,
      login,
      logout,
      refreshUser
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
