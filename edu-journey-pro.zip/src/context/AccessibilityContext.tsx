import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type ContrastPreset = 'standard' | 'high-contrast-dark' | 'yellow-on-black' | 'high-contrast-light';
export type TextScaling = 'normal' | 'large' | 'xlarge';

interface AccessibilityContextType {
  isHighContrast: boolean;
  contrastPreset: ContrastPreset;
  textSize: TextScaling;
  isDyslexicFont: boolean;
  reduceMotion: boolean;
  toggleHighContrast: () => void;
  setContrastPreset: (preset: ContrastPreset) => void;
  setTextSize: (size: TextScaling) => void;
  setIsDyslexicFont: (enabled: boolean) => void;
  setReduceMotion: (enabled: boolean) => void;
  resetAccessibilitySettings: () => void;
}

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

export const AccessibilityProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [contrastPreset, setContrastPresetState] = useState<ContrastPreset>(() => {
    return (localStorage.getItem('edujourney_contrast_preset') as ContrastPreset) || 'standard';
  });

  const [textSize, setTextSizeState] = useState<TextScaling>(() => {
    return (localStorage.getItem('edujourney_text_scaling') as TextScaling) || 'normal';
  });

  const [isDyslexicFont, setIsDyslexicFontState] = useState<boolean>(() => {
    return localStorage.getItem('edujourney_dyslexic_font') === 'true';
  });

  const [reduceMotion, setReduceMotionState] = useState<boolean>(() => {
    return localStorage.getItem('edujourney_reduce_motion') === 'true';
  });

  const isHighContrast = contrastPreset !== 'standard';

  // Apply High Contrast and Accessibility Classes to Document Element
  useEffect(() => {
    const root = document.documentElement;

    // Reset accessibility classes
    root.classList.remove('high-contrast', 'hc-dark', 'hc-yellow-black', 'hc-light', 'dyslexic-font', 'reduce-motion');
    root.removeAttribute('data-high-contrast');

    if (contrastPreset !== 'standard') {
      root.classList.add('high-contrast');
      root.setAttribute('data-high-contrast', contrastPreset);

      if (contrastPreset === 'high-contrast-dark') {
        root.classList.add('hc-dark');
      } else if (contrastPreset === 'yellow-on-black') {
        root.classList.add('hc-yellow-black');
      } else if (contrastPreset === 'high-contrast-light') {
        root.classList.add('hc-light');
      }
    }

    // Dyslexic font
    if (isDyslexicFont) {
      root.classList.add('dyslexic-font');
    }

    // Motion reduction
    if (reduceMotion) {
      root.classList.add('reduce-motion');
    }

    // Text scaling
    if (textSize === 'large') {
      root.style.fontSize = '112.5%'; // ~18px base
    } else if (textSize === 'xlarge') {
      root.style.fontSize = '125%'; // ~20px base
    } else {
      root.style.fontSize = '100%';
    }

    // Persist in localStorage
    localStorage.setItem('edujourney_contrast_preset', contrastPreset);
    localStorage.setItem('edujourney_text_scaling', textSize);
    localStorage.setItem('edujourney_dyslexic_font', String(isDyslexicFont));
    localStorage.setItem('edujourney_reduce_motion', String(reduceMotion));
  }, [contrastPreset, textSize, isDyslexicFont, reduceMotion]);

  const toggleHighContrast = () => {
    setContrastPresetState((prev) => (prev === 'standard' ? 'yellow-on-black' : 'standard'));
  };

  const setContrastPreset = (preset: ContrastPreset) => {
    setContrastPresetState(preset);
  };

  const setTextSize = (size: TextScaling) => {
    setTextSizeState(size);
  };

  const setIsDyslexicFont = (enabled: boolean) => {
    setIsDyslexicFontState(enabled);
  };

  const setReduceMotion = (enabled: boolean) => {
    setReduceMotionState(enabled);
  };

  const resetAccessibilitySettings = () => {
    setContrastPresetState('standard');
    setTextSizeState('normal');
    setIsDyslexicFontState(false);
    setReduceMotionState(false);
  };

  return (
    <AccessibilityContext.Provider
      value={{
        isHighContrast,
        contrastPreset,
        textSize,
        isDyslexicFont,
        reduceMotion,
        toggleHighContrast,
        setContrastPreset,
        setTextSize,
        setIsDyslexicFont,
        setReduceMotion,
        resetAccessibilitySettings,
      }}
    >
      {children}
    </AccessibilityContext.Provider>
  );
};

export const useAccessibility = () => {
  const context = useContext(AccessibilityContext);
  if (!context) {
    throw new Error('useAccessibility must be used within an AccessibilityProvider');
  }
  return context;
};
