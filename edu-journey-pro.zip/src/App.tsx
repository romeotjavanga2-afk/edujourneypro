/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { AccessibilityProvider } from './context/AccessibilityContext.js';
import { Phase1StatusBanner } from './components/common/Phase1StatusBanner.js';
import { Navbar } from './components/layout/Navbar.js';
import { HeroSection } from './components/landing/HeroSection.js';
import { FeaturesSection } from './components/landing/FeaturesSection.js';
import { AboutSection } from './components/landing/AboutSection.js';
import { ContactSection } from './components/landing/ContactSection.js';
import { Footer } from './components/layout/Footer.js';
import { DashboardLayout } from './components/dashboard/DashboardLayout.js';

// Modals
import { LoginModal } from './components/auth/LoginModal.js';
import { RegisterModal } from './components/auth/RegisterModal.js';
import { ForgotPasswordModal } from './components/auth/ForgotPasswordModal.js';
import { VerifyEmailModal } from './components/auth/VerifyEmailModal.js';
import { ProfileModal } from './components/profile/ProfileModal.js';
import { DatabaseInspectorModal } from './components/database/DatabaseInspectorModal.js';
import { FeaturePreviewModal } from './components/common/FeaturePreviewModal.js';
import { OnboardingModal } from './components/onboarding/OnboardingModal.js';

const AppContent: React.FC = () => {
  const { currentView } = useAuth();

  if (currentView === 'dashboard') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-sans antialiased">
        <DashboardLayout />
        {/* Global System Modals available from Dashboard */}
        <ProfileModal />
        <DatabaseInspectorModal />
        <FeaturePreviewModal />
        <OnboardingModal />
        <VerifyEmailModal />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans antialiased selection:bg-emerald-600 selection:text-white transition-colors duration-300">
      {/* Top Phase 1 Notice Banner */}
      <Phase1StatusBanner />

      {/* Sticky Navbar */}
      <Navbar />

      {/* Main Landing Page Content */}
      <main className="flex-grow">
        <HeroSection />
        <FeaturesSection />
        <AboutSection />
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Auth & System Modals */}
      <LoginModal />
      <RegisterModal />
      <ForgotPasswordModal />
      <VerifyEmailModal />
      <ProfileModal />
      <DatabaseInspectorModal />
      <FeaturePreviewModal />
      <OnboardingModal />
    </div>
  );
};

export default function App() {
  return (
    <AccessibilityProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </AccessibilityProvider>
  );
}

