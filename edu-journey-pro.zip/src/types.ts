export interface User {
  id: number;
  email: string;
  role: 'student' | 'teacher' | 'admin' | 'parent';
  status: string;
  createdAt: string;
  fullName: string;
  gender?: string;
  dateOfBirth?: string;
  region?: string;
  town?: string;
  school?: string;
  grade?: string;
  subjects?: string[];
  interests?: string[];
  profilePicture?: string;
  isEmailVerified: boolean;
  isOnboardingCompleted?: boolean;
  onboardingStep?: number;
  onboardingData?: OnboardingState;
  settings?: {
    theme: string;
    notificationsEmail: boolean;
    notificationsSms: boolean;
    language: string;
  };
}

export interface EduBuddyProfile {
  aiName: string;
  aiAvatar: string;
  voicePreference: string;
  conversationStyle: 'Friendly' | 'Professional' | 'Funny' | 'Motivational' | 'Patient' | 'Balanced';
  accentColor: string;
  greetingStyle: string;
  customGreeting?: string;
}

export interface OnboardingState {
  currentStep: number;
  isCompleted: boolean;
  personalInfo: {
    profilePhoto?: string;
    fullName: string;
    preferredName?: string;
    gender: string;
    dateOfBirth: string;
    region: string;
    town: string;
    school: string;
    grade: string;
  };
  academicInfo: {
    subjectsStudying: string[];
    favouriteSubject: string;
    difficultSubject: string;
    academicGoals: string[];
  };
  learningPreferences: {
    learningStyles: string[];
    studyFrequency: 'Daily' | 'Weekdays' | 'Weekends' | 'Occasionally' | string;
    sessionLength: '15 Minutes' | '30 Minutes' | '45 Minutes' | '1 Hour' | '2 Hours' | string;
    reminderTime: 'Morning' | 'Afternoon' | 'Evening' | 'Custom Time' | string;
    customReminderTime?: string;
  };
  interests: string[];
  careerDreams: string[];
  eduBuddy: EduBuddyProfile;
  notifications: {
    studyReminders: boolean;
    assignmentReminders: boolean;
    learningStreaks: boolean;
    motivationalMessages: boolean;
    schoolAnnouncements: boolean;
  };
  privacySettings: {
    profileVisibility: 'Public Profile' | 'Friends Only' | 'Private Profile';
  };
}

export interface Region {
  id: number;
  name: string;
  country: string;
}

export interface School {
  id: number;
  name: string;
  region: string;
  town: string;
  type: string;
}

export interface Subject {
  id: number;
  name: string;
  category: string;
}

export interface Interest {
  id: number;
  name: string;
  category: string;
}

export interface InitData {
  regions: Region[];
  schools: School[];
  subjects: Subject[];
  interests: Interest[];
}

export interface DatabaseTableInfo {
  tableName: string;
  description: string;
  rowCount: number;
  sampleRows: any[];
}

export interface DatabaseInspectorData {
  phase: string;
  projectName: string;
  targetCountry: string;
  databaseEngine: string;
  tables: DatabaseTableInfo[];
}

export type AuthModalType = 'login' | 'register' | 'forgot-password' | 'verify-email' | 'profile' | 'db-inspector' | 'feature-preview' | 'onboarding' | null;

export type AppViewType = 'landing' | 'dashboard';

export type DashboardNavTab = 
  | 'dashboard' 
  | 'buddy'
  | 'assignments' 
  | 'planner' 
  | 'calendar' 
  | 'feed' 
  | 'chat' 
  | 'library' 
  | 'market' 
  | 'workspace' 
  | 'career' 
  | 'scanner' 
  | 'settings';

export interface AIChatConversation {
  id: number;
  user_id?: number;
  title: string;
  subject: string;
  explanation_mode: string;
  is_pinned: number;
  is_bookmarked: number;
  updated_at?: string;
  created_at?: string;
}

export interface AIChatMessage {
  id: number;
  conversation_id: number;
  sender: 'user' | 'ai';
  content: string;
  explanation_mode?: string;
  is_bookmarked?: number;
  created_at?: string;
}

export interface AIFlashcard {
  id: number;
  user_id?: number;
  subject: string;
  topic: string;
  question: string;
  answer: string;
  status: 'Mastered' | 'Needs Practice' | 'Review later' | string;
  is_bookmarked: number;
}

export interface AIQuizQuestion {
  id: number;
  question: string;
  options?: string[];
  answer: number;
  explanation: string;
}

export interface AIQuiz {
  id: number;
  user_id?: number;
  title: string;
  subject: string;
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Exam Level' | string;
  question_type: string;
  questions_json: string;
  score: number;
  total_questions: number;
  created_at?: string;
  completed_at?: string;
}

export interface StudyRecommendationItem {
  id: number;
  user_id?: number;
  title: string;
  description: string;
  subject: string;
  priority: number;
  action_type: string;
  action_payload?: string;
  is_completed: number;
}

export interface DashboardWidget {
  id: number;
  widgetId: string;
  title: string;
  isEnabled: boolean;
  position: number;
  settings?: any;
}

export interface NotificationItem {
  id: number;
  title: string;
  message: string;
  type: 'welcome' | 'profile' | 'edubuddy' | 'reminder' | 'announcement' | 'achievement';
  isRead: boolean;
  link?: string;
  createdAt: string;
}

export interface LearningStreak {
  currentStreak: number;
  longestStreak: number;
  lastActivityDate: string;
  xpTotal: number;
  badges: string[];
}

export interface RecentActivityItem {
  id: number;
  activityType: 'quiz' | 'profile' | 'session' | 'school' | 'edubuddy' | 'assignment' | 'general';
  title: string;
  subtitle: string;
  xpEarned: number;
  timestamp: string;
}

export interface LearningProgressItem {
  id: number;
  subject: string;
  progress: number;
  trend: string;
  color: string;
  icon?: string;
}

export interface OverviewStats {
  todaysAssignments: number;
  studySessions: number;
  upcomingEvents: number;
  learningTimeMinutes: number;
  completedTasks: number;
  currentStreak: number;
}

export interface UpcomingEventItem {
  id: number;
  title: string;
  type: 'Homework' | 'School Event' | 'Test' | 'Exam' | 'Deadline';
  subject: string;
  date: string;
  time: string;
  badgeColor: string;
}

export interface AchievementItem {
  id: number;
  title: string;
  description: string;
  icon: string;
  isLocked: boolean;
  progress: number;
  maxProgress: number;
  xp: number;
}

export interface StudyPlannerPreviewData {
  todaysGoal: string;
  timeTargetMinutes: number;
  timeCompletedMinutes: number;
  nextReminder: string;
  weeklyGoalHours: number;
  weeklyCompletedHours: number;
}

export interface DashboardData {
  user: User;
  eduBuddy: {
    aiName: string;
    aiAvatar: string;
    greetingStyle?: string;
  };
  streak: LearningStreak;
  overview: OverviewStats;
  progress: LearningProgressItem[];
  recentActivity: RecentActivityItem[];
  upcomingEvents: UpcomingEventItem[];
  plannerPreview: StudyPlannerPreviewData;
  achievements: AchievementItem[];
  widgets: DashboardWidget[];
  notifications: NotificationItem[];
  motivationalQuote: {
    quote: string;
    author: string;
  };
}

// ==========================================
// Phase 4: Assignment System, Calendar, & AI Study Planner Types
// ==========================================

export type AssignmentStatus = 'Not Started' | 'In Progress' | 'Ready to Submit' | 'Submitted' | 'Reviewed' | 'Completed' | 'Late' | 'Draft';
export type AssignmentPriority = 'High' | 'Medium' | 'Low';
export type AssignmentDifficulty = 'Easy' | 'Medium' | 'Hard';

export interface AssignmentAttachment {
  id: string;
  title: string;
  url: string;
  size?: string;
  type?: string;
}

export interface AssignmentResource {
  title: string;
  url: string;
  type?: string;
}

export interface AssignmentNote {
  id: number;
  assignment_id: number;
  user_id: number;
  content: string;
  note_type: 'student' | 'voice' | 'teacher';
  is_pinned: boolean;
  is_bookmarked: boolean;
  created_at: string;
}

export interface AssignmentChecklistItem {
  id: number;
  assignment_id: number;
  user_id: number;
  title: string;
  is_completed: boolean;
  item_order: number;
  checklist_type: 'todo' | 'research' | 'reading' | 'practice';
  created_at: string;
}

export interface Assignment {
  id: number;
  user_id: number;
  title: string;
  subject: string;
  teacher: string;
  due_date: string;
  priority: AssignmentPriority;
  status: AssignmentStatus;
  progress: number;
  estimated_time: number; // in minutes
  difficulty: AssignmentDifficulty;
  instructions: string;
  teacher_notes: string;
  resources: AssignmentResource[];
  attachments: AssignmentAttachment[];
  notes?: AssignmentNote[];
  checklist?: AssignmentChecklistItem[];
  created_at: string;
  updated_at?: string;
}

export type CalendarEventType = 'Assignment' | 'Homework' | 'Test' | 'Exam' | 'School Event' | 'Study Session' | 'Deadline';

export interface CalendarEvent {
  id: number;
  user_id: number;
  title: string;
  event_type: CalendarEventType;
  subject: string;
  event_date: string; // YYYY-MM-DD
  start_time: string; // HH:mm
  end_time: string;   // HH:mm
  description: string;
  color: string;
  assignment_id?: number;
  created_at?: string;
}

export type StudyPlanType = 'Daily Study Plan' | 'Weekly Study Plan' | 'Exam Preparation Plan' | 'Holiday Study Plan' | 'Revision Schedule' | 'Balanced Study Timetable';

export interface StudyPlanScheduleTask {
  id?: string;
  subject: string;
  topic: string;
  duration: string;
  completed: boolean;
  timeSlot?: string;
}

export interface StudyPlanScheduleDay {
  day: string;
  date?: string;
  tasks: StudyPlanScheduleTask[];
}

export interface StudyPlan {
  id: number;
  user_id: number;
  title: string;
  plan_type: StudyPlanType;
  target_date: string;
  subjects_included: string[];
  daily_hours: number;
  schedule_json: StudyPlanScheduleDay[];
  ai_generated: boolean;
  created_at: string;
}

export interface StudySession {
  id: number;
  user_id: number;
  assignment_id?: number;
  title: string;
  subject: string;
  duration_minutes: number;
  time_spent_seconds: number;
  mode: 'pomodoro' | 'custom' | 'free';
  status: 'active' | 'paused' | 'completed' | 'ended_early';
  started_at: string;
  completed_at?: string;
  xp_earned: number;
}

export type StudentGoalType = 'Daily Goal' | 'Weekly Goal' | 'Monthly Goal';

export interface StudentGoal {
  id: number;
  user_id: number;
  title: string;
  goal_type: StudentGoalType;
  target_value: number;
  current_value: number;
  is_completed: boolean;
  target_date: string;
  created_at: string;
}

export interface ReminderSettings {
  id?: number;
  user_id: number;
  upcoming_assignment: boolean;
  tomorrow_deadline: boolean;
  today_study_plan: boolean;
  study_reminder: boolean;
  goal_reminder: boolean;
  exam_reminder: boolean;
  reminder_time: string;
}

export interface Phase4Stats {
  consecutiveDays: number;
  assignmentsCompleted: number;
  hoursStudied: number;
  goalsAchieved: number;
  xpTotal: number;
}

