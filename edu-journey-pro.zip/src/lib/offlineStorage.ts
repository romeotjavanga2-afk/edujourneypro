// Offline Storage & Service Worker Cache Utility for Essential Namibian Curriculum Content

export interface CurriculumTopic {
  id: string;
  title: string;
  summary: string;
  keyConcepts: string[];
  sampleQuestions: { question: string; answer: string }[];
  fileSizeKB: number;
}

export interface CurriculumSubjectPackage {
  id: string;
  subjectName: string;
  grade: 'Grade 10' | 'Grade 11' | 'Grade 12 NSSCO' | 'Grade 12 NSSCH';
  code: string;
  category: 'Sciences' | 'Mathematics' | 'Languages' | 'Humanities' | 'Commercials';
  description: string;
  totalSizeMB: number;
  lastUpdated: string;
  isEssential: boolean;
  topics: CurriculumTopic[];
  downloadedAt?: string;
}

export interface OfflineNote {
  id: string;
  subjectId: string;
  title: string;
  content: string;
  createdAt: string;
  synced: boolean;
}

export interface SearchResultItem {
  id: string;
  packageId: string;
  subjectName: string;
  topicId: string;
  topicTitle: string;
  type: 'topic' | 'keyConcept' | 'sampleQuestion' | 'note';
  title: string;
  content: string;
  snippet: string;
  matchedField: string;
  relevanceScore: number;
  isDownloaded: boolean;
  sampleQuestion?: { question: string; answer: string };
  note?: OfflineNote;
}

// Essential Namibian Curriculum Pre-packaged Materials
export const ESSENTIAL_CURRICULUM_PACKAGES: CurriculumSubjectPackage[] = [
  {
    id: 'math-g11-nssco',
    subjectName: 'Mathematics',
    grade: 'Grade 11',
    code: 'NSSCO-4004',
    category: 'Mathematics',
    description: 'NSSCO Grade 11 Core Algebra, Trigonometry, Mensuration & Statistics Revision Package.',
    totalSizeMB: 4.8,
    lastUpdated: '2026-06-15',
    isEssential: true,
    topics: [
      {
        id: 'math-alg-1',
        title: 'Algebraic Expressions & Quadratic Equations',
        summary: 'Master factorisation, completing the square, quadratic formula x = (-b ± √(b²-4ac))/2a, and simultaneous equations.',
        keyConcepts: [
          'Difference of two squares: a² - b² = (a - b)(a + b)',
          'Completing the square method for minimum/maximum turning points',
          'Solving linear and quadratic simultaneous equations by substitution',
        ],
        sampleQuestions: [
          {
            question: 'Solve for x: 2x² - 5x + 2 = 0',
            answer: 'Using quadratic formula or factoring: (2x - 1)(x - 2) = 0 => x = 0.5 or x = 2.',
          },
          {
            question: 'Express x² - 6x + 13 in the form (x - a)² + b.',
            answer: '(x - 3)² - 9 + 13 = (x - 3)² + 4. Minimum value is 4 at x = 3.',
          },
        ],
        fileSizeKB: 1200,
      },
      {
        id: 'math-trig-1',
        title: 'Sine & Cosine Rules in Non-Right Angled Triangles',
        summary: 'Apply a/sin(A) = b/sin(B) = c/sin(C) and c² = a² + b² - 2ab cos(C) for bearings and distances.',
        keyConcepts: [
          'Sine Rule used when given 2 angles and 1 side, or 2 sides and non-included angle',
          'Cosine Rule used when given 3 sides or 2 sides and included angle',
          'Area of triangle = 1/2 * a * b * sin(C)',
        ],
        sampleQuestions: [
          {
            question: 'In △ABC, a = 7cm, b = 9cm, angle C = 60°. Find length c.',
            answer: 'c² = 7² + 9² - 2(7)(9)cos(60°) = 49 + 81 - 63 = 67. c = √67 ≈ 8.19 cm.',
          },
        ],
        fileSizeKB: 1400,
      },
    ],
  },
  {
    id: 'physci-g11-nssco',
    subjectName: 'Physical Science',
    grade: 'Grade 11',
    code: 'NSSCO-4023',
    category: 'Sciences',
    description: 'Mechanics, Newton\'s Laws, Stoichiometry, Electricity and Chemical Bonding.',
    totalSizeMB: 5.4,
    lastUpdated: '2026-06-20',
    isEssential: true,
    topics: [
      {
        id: 'phys-mechanics',
        title: 'Newtonian Dynamics & Equations of Motion',
        summary: 'Core equations v = u + at, s = ut + 0.5at², v² = u² + 2as. Force F = ma and momentum p = mv.',
        keyConcepts: [
          'Newton\'s 1st Law: Inertia and balanced forces',
          'Newton\'s 2nd Law: Resultant force equals mass times acceleration',
          'Newton\'s 3rd Law: Action and reaction forces are equal and opposite',
        ],
        sampleQuestions: [
          {
            question: 'A 1200kg car accelerates uniformly from rest to 20 m/s in 8 seconds. Find the force.',
            answer: 'a = (20 - 0)/8 = 2.5 m/s². F = ma = 1200 * 2.5 = 3000 N.',
          },
        ],
        fileSizeKB: 1800,
      },
    ],
  },
  {
    id: 'bio-g11-nssco',
    subjectName: 'Biology',
    grade: 'Grade 11',
    code: 'NSSCO-4021',
    category: 'Sciences',
    description: 'Cell structure, Photosynthesis, Human Nutrition, Circulation & Genetics in Namibian ecosystems.',
    totalSizeMB: 4.2,
    lastUpdated: '2026-07-01',
    isEssential: true,
    topics: [
      {
        id: 'bio-photosynthesis',
        title: 'Photosynthesis & Leaf Anatomy',
        summary: 'Equation 6CO₂ + 6H₂O -> C₆H₁₂O₆ + 6O₂ driven by chlorophyll and sunlight. Adaptations of stomata.',
        keyConcepts: [
          'Light-dependent and light-independent reactions',
          'Xylem transports water up; Phloem transports sucrose and amino acids (translocation)',
          'Factors limiting photosynthesis: Light intensity, CO₂ concentration, temperature',
        ],
        sampleQuestions: [
          {
            question: 'Explain why leaves appear green under white light.',
            answer: 'Chlorophyll reflects green light while absorbing red and blue wavelengths for photosynthesis.',
          },
        ],
        fileSizeKB: 1350,
      },
    ],
  },
  {
    id: 'eng-g11-nssco',
    subjectName: 'English Second Language',
    grade: 'Grade 11',
    code: 'NSSCO-4116',
    category: 'Languages',
    description: 'Summary writing techniques, Formal letter & report composition, Reading comprehension strategies.',
    totalSizeMB: 3.1,
    lastUpdated: '2026-05-10',
    isEssential: false,
    topics: [
      {
        id: 'eng-summary-writing',
        title: 'High-Score Summary Writing (100 words rule)',
        summary: 'Extract key points without repetition, use own words where appropriate, connect ideas logically.',
        keyConcepts: [
          'Underline core bullet points matching the prompt directive',
          'Avoid examples, statistical quotes, and unnecessary adjectives in final text',
          'Maintain concise word count strictly within 90-110 words',
        ],
        sampleQuestions: [
          {
            question: 'What are three essential rules for Namibian NSSCO summary writing?',
            answer: '1. Stay strictly on topic. 2. Do not include personal opinions or extra facts. 3. Respect word limits.',
          },
        ],
        fileSizeKB: 900,
      },
    ],
  },
  {
    id: 'hist-g11-nssco',
    subjectName: 'History & Namibian Heritage',
    grade: 'Grade 11',
    code: 'NSSCO-4125',
    category: 'Humanities',
    description: 'Namibian Liberation Struggle, UN Resolution 435, Constitutional Principles, World History 1919-1990.',
    totalSizeMB: 3.9,
    lastUpdated: '2026-06-28',
    isEssential: true,
    topics: [
      {
        id: 'hist-nam-independence',
        title: 'Namibia\'s Journey to Independence (1966 - 1990)',
        summary: 'Role of SWAPO, diplomatic negotiations, Resolution 435 adoption, UNTAG implementation, and March 21, 1990.',
        keyConcepts: [
          'UN Resolution 435 passed in 1978 setting free election framework',
          'UNTAG supervised the November 1989 Constituent Assembly elections',
          'Constitution of Republic of Namibia drafted in 80 days with democratic bill of rights',
        ],
        sampleQuestions: [
          {
            question: 'Why was UN Resolution 435 significant for Namibian independence?',
            answer: 'It established the official international framework for a ceasefire and UN-supervised democratic elections.',
          },
        ],
        fileSizeKB: 1100,
      },
    ],
  },
];

const LOCAL_STORAGE_KEY_OFFLINE_PACKAGES = 'edujourney_offline_packages';
const LOCAL_STORAGE_KEY_OFFLINE_NOTES = 'edujourney_offline_notes';

// Register Service Worker gracefully
export const registerServiceWorker = () => {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker
        .register('/sw.js')
        .then((reg) => {
          console.log('[SW] Service worker registered successfully:', reg.scope);
        })
        .catch((err) => {
          console.warn('[SW] Service worker registration failed:', err);
        });
    });
  }
};

// Get list of downloaded offline package IDs
export const getDownloadedPackageIds = (): string[] => {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY_OFFLINE_PACKAGES);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error('Failed to read offline package list', e);
    return [];
  }
};

// Save downloaded package ID
export const cacheSubjectPackage = async (packageId: string): Promise<boolean> => {
  try {
    const pkg = ESSENTIAL_CURRICULUM_PACKAGES.find((p) => p.id === packageId);
    if (!pkg) return false;

    // 1. Store in localStorage metadata
    const downloadedIds = getDownloadedPackageIds();
    if (!downloadedIds.includes(packageId)) {
      downloadedIds.push(packageId);
      localStorage.setItem(LOCAL_STORAGE_KEY_OFFLINE_PACKAGES, JSON.stringify(downloadedIds));
    }

    // 2. Cache content payload in localStorage / Cache API
    const cachePayload = { ...pkg, downloadedAt: new Date().toISOString() };
    localStorage.setItem(`edujourney_pkg_content_${packageId}`, JSON.stringify(cachePayload));

    // 3. Post message to Service Worker if active
    if (navigator.serviceWorker?.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'CACHE_CURRICULUM',
        url: `/api/curriculum/packages/${packageId}`,
        data: cachePayload,
      });
    }

    return true;
  } catch (e) {
    console.error('Error caching subject package:', e);
    return false;
  }
};

// Remove cached subject
export const removeCachedSubjectPackage = (packageId: string): boolean => {
  try {
    const downloadedIds = getDownloadedPackageIds().filter((id) => id !== packageId);
    localStorage.setItem(LOCAL_STORAGE_KEY_OFFLINE_PACKAGES, JSON.stringify(downloadedIds));
    localStorage.removeItem(`edujourney_pkg_content_${packageId}`);
    return true;
  } catch (e) {
    console.error('Error removing cached package:', e);
    return false;
  }
};

// Get cached content for a specific package
export const getCachedPackageContent = (packageId: string): CurriculumSubjectPackage | null => {
  try {
    const raw = localStorage.getItem(`edujourney_pkg_content_${packageId}`);
    if (raw) return JSON.parse(raw);
    return null;
  } catch (e) {
    return null;
  }
};

// Get calculate total offline storage used in MB
export const getOfflineStorageStatsMB = () => {
  const downloadedIds = getDownloadedPackageIds();
  let totalMB = 0;
  downloadedIds.forEach((id) => {
    const pkg = ESSENTIAL_CURRICULUM_PACKAGES.find((p) => p.id === id);
    if (pkg) {
      totalMB += pkg.totalSizeMB;
    }
  });

  // Calculate approximate localStorage size
  let rawLength = 0;
  for (let key in localStorage) {
    if (localStorage.hasOwnProperty(key)) {
      rawLength += (localStorage[key] || '').length * 2; // UTF-16
    }
  }
  const localStorageMB = parseFloat((rawLength / (1024 * 1024)).toFixed(2));

  return {
    downloadedCount: downloadedIds.length,
    totalContentMB: parseFloat(totalMB.toFixed(2)),
    localStorageMB,
  };
};

// Clear all offline cache
export const clearAllOfflineCache = (): boolean => {
  try {
    const downloadedIds = getDownloadedPackageIds();
    downloadedIds.forEach((id) => {
      localStorage.removeItem(`edujourney_pkg_content_${id}`);
    });
    localStorage.removeItem(LOCAL_STORAGE_KEY_OFFLINE_PACKAGES);

    if (navigator.serviceWorker?.controller) {
      navigator.serviceWorker.controller.postMessage({ type: 'CLEAR_CACHE' });
    }
    return true;
  } catch (e) {
    return false;
  }
};

// Save offline note
export const saveOfflineNote = (note: Omit<OfflineNote, 'id' | 'createdAt' | 'synced'>): OfflineNote => {
  const notes = getOfflineNotes();
  const newNote: OfflineNote = {
    ...note,
    id: `note-${Date.now()}`,
    createdAt: new Date().toISOString(),
    synced: navigator.onLine,
  };
  notes.unshift(newNote);
  localStorage.setItem(LOCAL_STORAGE_KEY_OFFLINE_NOTES, JSON.stringify(notes));
  return newNote;
};

// Get offline notes
export const getOfflineNotes = (): OfflineNote[] => {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY_OFFLINE_NOTES);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
};

/**
 * Local offline search across cached curriculum packages, topics, key concepts, sample past paper questions, and student notes.
 */
export const searchOfflineCurriculum = (
  rawQuery: string,
  options?: {
    onlyDownloaded?: boolean;
    categoryFilter?: string;
  }
): SearchResultItem[] => {
  const query = rawQuery.trim().toLowerCase();
  if (!query) return [];

  const downloadedIds = getDownloadedPackageIds();
  const results: SearchResultItem[] = [];
  const terms = query.split(/\s+/).filter(Boolean);

  const calculateScore = (text: string): number => {
    const lower = text.toLowerCase();
    let score = 0;
    if (lower === query) score += 100;
    else if (lower.includes(query)) score += 50;

    terms.forEach((term) => {
      if (lower.includes(term)) score += 15;
    });
    return score;
  };

  const createSnippet = (text: string): string => {
    const lower = text.toLowerCase();
    const idx = lower.indexOf(terms[0] || query);
    if (idx === -1) return text.slice(0, 140) + (text.length > 140 ? '...' : '');
    const start = Math.max(0, idx - 40);
    const end = Math.min(text.length, idx + 100);
    return (start > 0 ? '...' : '') + text.slice(start, end) + (end < text.length ? '...' : '');
  };

  // 1. Search Curriculum Packages and Topics
  ESSENTIAL_CURRICULUM_PACKAGES.forEach((pkg) => {
    const isDownloaded = downloadedIds.includes(pkg.id);

    if (options?.onlyDownloaded && !isDownloaded) return;
    if (
      options?.categoryFilter &&
      options.categoryFilter !== 'All' &&
      pkg.category.toLowerCase() !== options.categoryFilter.toLowerCase() &&
      pkg.subjectName.toLowerCase() !== options.categoryFilter.toLowerCase()
    ) {
      return;
    }

    pkg.topics.forEach((topic) => {
      // Check Topic Title & Summary
      const topicTitleScore = calculateScore(topic.title);
      const summaryScore = calculateScore(topic.summary);

      if (topicTitleScore > 0 || summaryScore > 0) {
        results.push({
          id: `sr-topic-${topic.id}`,
          packageId: pkg.id,
          subjectName: pkg.subjectName,
          topicId: topic.id,
          topicTitle: topic.title,
          type: 'topic',
          title: topic.title,
          content: topic.summary,
          snippet: createSnippet(topic.summary),
          matchedField: topicTitleScore > summaryScore ? 'Topic Title' : 'Topic Summary',
          relevanceScore: Math.max(topicTitleScore, summaryScore) + 20,
          isDownloaded,
        });
      }

      // Check Key Concepts
      topic.keyConcepts.forEach((concept, conceptIdx) => {
        const conceptScore = calculateScore(concept);
        if (conceptScore > 0) {
          results.push({
            id: `sr-concept-${topic.id}-${conceptIdx}`,
            packageId: pkg.id,
            subjectName: pkg.subjectName,
            topicId: topic.id,
            topicTitle: topic.title,
            type: 'keyConcept',
            title: `Concept: ${topic.title}`,
            content: concept,
            snippet: createSnippet(concept),
            matchedField: 'Key Concept Note',
            relevanceScore: conceptScore + 15,
            isDownloaded,
          });
        }
      });

      // Check Sample Past Paper Questions & Answers
      topic.sampleQuestions.forEach((sq, sqIdx) => {
        const qScore = calculateScore(sq.question);
        const aScore = calculateScore(sq.answer);
        if (qScore > 0 || aScore > 0) {
          results.push({
            id: `sr-question-${topic.id}-${sqIdx}`,
            packageId: pkg.id,
            subjectName: pkg.subjectName,
            topicId: topic.id,
            topicTitle: topic.title,
            type: 'sampleQuestion',
            title: `Q: ${sq.question}`,
            content: sq.answer,
            snippet: createSnippet(`Question: ${sq.question} Solution: ${sq.answer}`),
            matchedField: qScore > aScore ? 'Sample Question' : 'Answer Solution',
            relevanceScore: Math.max(qScore, aScore) + 10,
            isDownloaded,
            sampleQuestion: sq,
          });
        }
      });
    });
  });

  // 2. Search Offline Student Notes
  const notes = getOfflineNotes();
  notes.forEach((note) => {
    const titleScore = calculateScore(note.title);
    const contentScore = calculateScore(note.content);

    if (titleScore > 0 || contentScore > 0) {
      results.push({
        id: `sr-note-${note.id}`,
        packageId: note.subjectId,
        subjectName: 'Personal Offline Notes',
        topicId: note.id,
        topicTitle: note.title,
        type: 'note',
        title: note.title,
        content: note.content,
        snippet: createSnippet(note.content),
        matchedField: titleScore > contentScore ? 'Note Title' : 'Note Content',
        relevanceScore: Math.max(titleScore, contentScore) + 25,
        isDownloaded: true,
        note,
      });
    }
  });

  // Sort by highest relevance score first
  return results.sort((a, b) => b.relevanceScore - a.relevanceScore);
};

